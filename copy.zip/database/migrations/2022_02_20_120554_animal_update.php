<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AnimalUpdate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->foreignId("animal_car_section")->constrained("sections")->references("id")->nullable();
            $table->foreignId("animal_car_brand")->constrained("car_brands")->references("id")->nullable();
            $table->foreignId("animal_car_kilometers")->constrained("kilometers")->references("id")->nullable();
            $table->foreignId("animal_car_status")->constrained("car_status")->references("id")->nullable();
            $table->foreignId("animal_car_engine_capacities")->constrained("engine_capacities")->references("id")->nullable();
            $table->foreignId("animal_car_motion_vectors")->constrained("motion_vectors")->references("id")->nullable();
            $table->foreignId("animal_car_payment_methods")->constrained("payment_methods")->references("id")->nullable();
            $table->foreignId("animal_car_fuel_types")->constrained("fuel_types")->references("id")->nullable();
            $table->foreignId("animal_car_color")->constrained("colors")->references("id")->nullable();
            $table->foreignId("animal_car_body_types")->constrained("body_types")->references("id")->nullable();
            $table->foreignId("animal_car_connection_types")->constrained("connection_types")->references("id")->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->dropColumn('animal_car_section');
            $table->dropColumn('animal_car_brand');
            $table->dropColumn('animal_car_kilometers');
            $table->dropColumn('animal_car_status');
            $table->dropColumn('animal_car_engine_capacities');
            $table->dropColumn('animal_car_motion_vectors');
            $table->dropColumn('animal_car_payment_methods');
            $table->dropColumn('animal_car_fuel_types');
            $table->dropColumn('animal_car_color');
            $table->dropColumn('animal_car_body_types');
            $table->dropColumn('animal_car_connection_types');

        });
    }
}
