<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddImageToBorders extends Migration
{

    public function up()
    {
        Schema::table('borders', function (Blueprint $table) {
            $table->string('border_image')->default('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('borders', function (Blueprint $table) {
            $table->dropColumn('border_image');
        });
    }
}
