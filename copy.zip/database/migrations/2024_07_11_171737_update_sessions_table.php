<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateSessionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sessions', function (Blueprint $table) {
            $table->integer("compitetion_number")->nullable();
            $table->integer("compitetion_id")->nullable();
            $table->date("compitetion_start_date")->nullable();
            $table->date("compitetion_end_date")->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sessions', function (Blueprint $table) {
            $table->dropColumn('compitetion_number');
            $table->dropColumn('compitetion_id');
            $table->dropColumn('compitetion_start_date');
            $table->dropColumn('compitetion_end_date');
        });
    }
}
