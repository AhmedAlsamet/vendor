<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('xp_points')->default(0);
            $table->date('last_task')->nullable();
            $table->date('roll_date')->nullable();
            $table->integer('roll_count')->default(0);
            $table->integer('win_points')->default(0);
            $table->double('wallet')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('xp_points');
            $table->dropColumn('win_points');
            $table->dropColumn('roll_date');
            $table->dropColumn('roll_count');
            $table->dropColumn('last_task');
            $table->dropColumn('wallet');
        });
    }
}
