<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateUserForShopRequirement extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('border_id')->default(0);
            $table->integer('color_id') ->default(0);
            $table->integer('font_id')->default(0);
            $table->string('wisdom_count')->default("");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('border_id');
            $table->dropColumn('color_id');
            $table->dropColumn('font_id');
            $table->dropColumn('wisdom_count');
        });
    }
}
