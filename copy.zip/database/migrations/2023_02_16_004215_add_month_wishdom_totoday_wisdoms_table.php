<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMonthWishdomTotodayWisdomsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('today_wisdoms', function (Blueprint $table) {
           $table->integer('month_wisdom')->default(0)->comment('0=>user not show this wisdom 1=> this wisdom added in this month 2=>add in arshef');
            $table->date('start_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('today_wisdoms', function (Blueprint $table) {
            //
        });
    }
}
