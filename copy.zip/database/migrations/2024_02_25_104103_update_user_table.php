<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class UpdateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('age')->default(20);
            $table->string('city')->nullable();
            $table->string('job')->nullable();
            $table->integer('gender')->default(1);
            $table->string('device_id')->nullable();
            $table->integer('connection_state')->default(1);
            $table->timestamp('last_connection')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->integer('is_blocked')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('age');
            $table->dropColumn('city');
            $table->dropColumn('job');
            $table->dropColumn('gender');
            $table->dropColumn('device_id');
            $table->dropColumn('connection_state');
            $table->dropColumn('last_connection');
            $table->dropColumn('is_blocked');
        });
    }
}
