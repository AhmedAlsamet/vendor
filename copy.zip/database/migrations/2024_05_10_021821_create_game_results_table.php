<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGameResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('game_results', function (Blueprint $table) {
            $table->id();
            $table->string("type");
            $table->string("state");
            $table->integer("compitetion_id");
            $table->integer("compitetion_number");
            $table->date("compitetion_start_date");
            $table->date("compitetion_end_date");
            $table->integer("session_id");
            $table->integer("user_win1");
            $table->integer("user_loss1");
            $table->integer("user_win2")->nullable();
            $table->integer("user_loss2")->nullable();
            $table->double("winner_result")->nullable();
            $table->double("losser_result")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('game_results');
    }
}
