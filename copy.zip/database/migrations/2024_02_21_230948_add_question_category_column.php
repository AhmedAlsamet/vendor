<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddQuestionCategoryColumn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('questions', function (Blueprint $table) {
            $table->integer('question_category_id')->default(1);
            $table->string('question_name_lat')->nullable();
            $table->string('question_answer1_lat')->nullable();
            $table->string('question_answer2_lat')->nullable();
            $table->string('question_answer3_lat')->nullable();
            $table->string('question_answer4_lat')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('questions', function (Blueprint $table) {
            $table->dropColumn('question_category_id');
            $table->dropColumn('question_name_lat');
            $table->dropColumn('question_answer1_lat');
            $table->dropColumn('question_answer2_lat');
            $table->dropColumn('question_answer3_lat');
            $table->dropColumn('question_answer4_lat');
        });
    }
}
