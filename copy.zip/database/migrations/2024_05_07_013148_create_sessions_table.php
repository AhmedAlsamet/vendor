<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSessionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sessions', function (Blueprint $table) {
            $table->id();
            $table->string("type");
            $table->string("state");
            $table->string("token")->nullable();
            $table->string("token2")->nullable();
            $table->string("link");
            $table->integer("number_of_users");
            $table->string("user1_state")->nullable();
            $table->integer("user1")->nullable();;
            $table->string("user2_state")->nullable();
            $table->integer("user2")->nullable();
            $table->string("user3_state")->nullable();
            $table->integer("user3")->nullable();
            $table->string("user4_state")->nullable();
            $table->integer("user4")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sessions');
    }
}
