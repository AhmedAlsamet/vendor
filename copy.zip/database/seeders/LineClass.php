<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LineClass extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('lines')->insert([
            [
                'title' => '4.1 الخط الكوفي',
            ],
            [
                'title' => '4.2 خط الرقعة او الرقاع',
            ],
            [
                'title' => '4.3 خط النسخ',
            ],
            [
                'title' => '4.4 خط الثلث',
            ],
            [
                'title' => '4.5 الخط الفارسي',
            ],
            [
                'title' => '4.6 خط الإجازة او التوقيع',
            ],
            [
                'title' => '4.7 خط الديواني',
            ],
            [
                'title' => '4.8 خط الصغراء',
            ],

        ]);

    }


}
