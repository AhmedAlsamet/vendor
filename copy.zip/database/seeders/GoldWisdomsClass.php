<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GoldWisdomsClass extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('today_wisdoms')->insert([
            [
                'day' => '1',
                'wisdoms' => 'first',
                'type' =>1,
            ],
            [
                'day' => '2',
                'wisdoms' => 'Second',
                'type' =>1,


            ],
            [
                'day' => '3',
                'wisdoms' => 'third',
                'type' =>1,


            ],
            [
                'day' => '4',
                'wisdoms' => 'fourth',
                'type' =>1,


            ],
            [
                'day' => '5',
                'wisdoms' => 'fifth',
                'type' =>1,


            ],
            [
                'day' => '6',
                'wisdoms' => 'six',
                'type' =>1,


            ],
            [
                'day' => '7',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '8',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '9',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '10',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '11',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '12',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '13',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '14',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '15',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '16',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '17',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '18',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '19',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '20',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '21',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '22',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '23',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '24',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '25',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '26',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '27',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '28',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '29',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            [
                'day' => '30',
                'wisdoms' => 'seven',
                'type' =>1,

            ],
            ]);
            }

}
