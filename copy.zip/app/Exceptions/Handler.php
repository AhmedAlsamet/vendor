<?php
namespace App\Exceptions;

use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use \Illuminate\Validation\ValidationException;

class Handler extends ExceptionHandler {
	/**
	 * A list of the exception types that are not reported.
	 *
	 * @var array
	 */
	protected $dontReport = [
		//
	];

	/**
	 * A list of the inputs that are never flashed for validation exceptions.
	 *
	 * @var array
	 */
	protected $dontFlash = [
		'current_password',
		'password',
		'password_confirmation',
	];


	protected function invalidJson($request, ValidationException $exception) {
		// dd($request);
		if(count($exception->errors()) > 0 ) {
			$erorrs = $exception->errors();
			foreach($erorrs as $item) {
				// dd($item);
			return errorResponseJson(['data' => $erorrs]  ,203 ,$item[0]);	
			}
		}
		return errorResponseJson(['data' => $item]  ,203,"ff" );	

		// return response()->json([
		// 	'status' => false,
		// 	'StatusCode' => $exception->status,
		// 	'StatusType' => 'Unprocessable Entity',
		// 	'explainError' => 'The request was well-formed but was unable to be followed due to semantic errors.',
		// 	'message' => 'The given data is invalid',
		// 	'errors' => $exception->errors(),
		// ], $exception->status);
	}

	protected function unauthenticated($request, AuthenticationException $exception) {
		$data = [];
		if ($request->expectsJson()) {
			
			$data['status'] = false;
			$data['code'] = 203;
			$data['message'] =  trans('admin.Unauthorized');
			$data['data'] = Null;
			return response()->json($data,  203);
		}

		return redirect()->guest('login');
	}

	/**
	 * Register the exception handling callbacks for the application.
	 *
	 * @return void
	 */
	public function register() {
		$this->reportable(function (Throwable $e) {
			//
		});
	}
	public function render($request, Throwable $exception)
    {

        if ($request->expectsJson()){

			if( empty($exception->getMessage())) {
				$data['status'] = false;
				$data['code'] = 404;
				$data['message'] =  trans('admin.notfound');
				$data['data'] = $exception->getMessage() !="" ?  $exception->getMessage() : null ;
				return response()->json($data,  404);
			} else {
				// $data['status'] = false;
				// $data['code'] = 500;
				// $data['message'] =  $exception->getMessage() !="" ?  $exception->getMessage() : null ;
				// $data['data'] = null;
				// return response()->json($data, 500);
			}
			 

        } 


        return parent::render($request, $exception);
        
    }
	
}