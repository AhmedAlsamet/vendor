<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppQuestion extends Model
{
    use HasFactory;
    protected $table    = 'app_questions';
    protected $fillable = [
            'id',
            'title',
            'title_lat',
            'description',
            'description_lat',
            'created_at',
            'updated_at',
        ];
    
    
       protected static function boot() {
          parent::boot();
          // if you disable constraints should by run this static method to Delete children data
             static::deleting(function($jobs) {
             });
       }
            
}
