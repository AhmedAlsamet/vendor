<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Winner extends Model {

protected $table    = 'winners';
protected $fillable = [
		'id',
		'admin_id',
        'user_id',
        'qestion_id',
        'compitetion_id',
        'mark',
        'time',
		'created_at',
		'updated_at',
	];

	/**
    * user_id relation method
    * @param void
    * @return object data
    */
    public function user_id(){
      return $this->hasOne(\App\Models\User::class,'id','user_id');
   }
   public function user_info()
   {
       return $this->belongsTo(User::class,'user_id');
   }


	/**
    * qestion_id relation method
    * @param void
    * @return object data
    */
   public function qestion_id(){
      return $this->hasOne(\App\Models\Question::class,'id','qestion_id');
   }

	/**
    * compitetion_id relation method
    * @param void
    * @return object data
    */
   public function compitetion_id(){
      return $this->hasOne(\App\Models\Compitetion::class,'id','compitetion_id');
   }
   public function getCreatedAtAttribute($date)
   {
      return date("d-m-Y", strtotime($date));
   }

   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($winner) {
			//$winner->user_id()->delete();
			//$winner->user_id()->delete();
			//$winner->user_id()->delete();
         });
   }

}
