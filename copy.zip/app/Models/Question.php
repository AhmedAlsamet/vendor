<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Question extends Model {

protected $table    = 'questions';
protected $fillable = [
		'id',
		'admin_id',
        'question_name',
        'question_answer1',
        'question_answer2',
        'question_answer3',
        'question_answer4',
        'question_category_id',
        'question_name_lat',
        'question_answer1_lat',
        'question_answer2_lat',
        'question_answer3_lat',
        'question_answer4_lat',
        'question_correct_answer',
		'created_at',
		'updated_at',
	];


   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($question) {
         });
   }
		
}
