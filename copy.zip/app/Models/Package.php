<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    use HasFactory;
    protected $table = 'packages';

	protected $fillable = [
		'title',
        'type',
		'type_package',
		'days',
        'for_ever',
	];
    public function border_info()
    {
        return $this->belongsTo(Border::class,'type_package');
    }
    public function line_info()
    {
        return $this->belongsTo(Line::class,'type_package');
    }
    public function goldWisdom_info()
    {
        return $this->belongsTo(TodayWisdom::class,'type_package');
    }
}
