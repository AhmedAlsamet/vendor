<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Notafication extends Model {

protected $table    = 'notafications';
protected $fillable = [
		'id',

        'Notafication_title',
        'Notafication_body',
        'Notafication_type',
        'Notification_for',

		'created_at',
		'updated_at',
	];

	/**
    * user_id relation method
    * @param void
    * @return object data
    */
   public function user_id(){
      return $this->hasOne(\App\Models\User::class,'id','Notification_for');
   }

 	/**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($notafication) {
			//$notafication->user_id()->delete();
         });
   }
		
}
