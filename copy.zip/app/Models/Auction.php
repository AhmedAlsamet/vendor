<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Auction extends Model {

protected $table    = 'auctions';
protected $fillable = [
		'id',
		'admin_id',
        'auction_animal',
        'auction_opening_price',
        'auction_end_price',
        'auction_status',
		'created_at',
		'updated_at',
	];

	/**
    * auction_animal relation method
    * @param void
    * @return object data
    */
   public function auction_animal(){
      
      return $this->hasOne(\App\Models\Animal::class,'id','auction_animal')->with('animal_type','animal_area','animal_city','animal_user_id','animal_catagory','images');
   }

   public function animal(){
      
      return $this->hasOne(\App\Models\Animal::class,'id','auction_animal')->with('animal_type','animal_area','animal_city','animal_user_id','animal_catagory','images');
   }

 	/**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($auction) {
			//$auction->auction_animal()->delete();
         });
   }
		
}
