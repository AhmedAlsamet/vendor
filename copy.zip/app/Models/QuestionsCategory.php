<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionsCategory extends Model
{
    protected $table    = 'questions_categories';
protected $fillable = [
		'id',
        'question_categorie_title',
        'question_categorie_title_lat',
        'question_categorie_is_active',
		'created_at',
		'updated_at',
	];


   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($question) {
         });
   }
		
}
