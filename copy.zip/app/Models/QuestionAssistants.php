<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionAssistants extends Model
{
    use HasFactory;
    
     protected $table    = 'question_assistants';

    protected $fillable = [
        'user_id', 'time_assistant', 'delete_two_answers_assistant', 'skip_assistant', 'question_id'
    ];

    public function user(){
        return $this->belongsTo(\App\Models\User::class);
    }
}
