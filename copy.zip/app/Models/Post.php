<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Post extends Model {

protected $table    = 'posts';
protected $fillable = [
		'id',
		'admin_id',
        'user_id',

        'qestion_id',

        'compitetion_id',
         'mark',
        'time',
		'created_at',
		'updated_at',
	];

   public function getCreatedAtAttribute($date)
   {
      return date("d-m-Y", strtotime($date));
   }
   public function user_id(){
      return $this->hasOne(\App\Models\User::class,'id','user_id');
   }


   public function qestion_id(){
      return $this->hasOne(\App\Models\Question::class,'id','qestion_id');
   }

   public function posts_details()
   {
       return $this->hasMany(PostDetails::class,'post_id');
   }
   public function compitetion_id(){
      return $this->hasOne(\App\Models\Compitetion::class,'id','compitetion_id');
   }

   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($post) {
			//$post->user_id()->delete();
			//$post->user_id()->delete();
			//$post->user_id()->delete();
         });
   }

}
