<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Orders extends Model {

protected $table    = 'orders';
protected $fillable = [
		'id',
		'admin_id',
        'order_user_id',

        'order_address_id',

        'order_time',
        'order_coupon',

        'order_total_price',
        'order_price',
        'order_delivery_price',
        'order_notes',
        'order_payment_type',

		'created_at',
		'updated_at',
	];

	/**
    * order_user_id relation method
    * @param void
    * @return object data
    */
   public function order_user_id(){
      return $this->hasOne(\App\Models\User::class,'id','order_user_id');
   }

	/**
    * order_address_id relation method
    * @param void
    * @return object data
    */
   public function order_address_id(){
      return $this->hasOne(\App\Models\Address::class,'id','order_address_id');
   }

	/**
    * order_coupon relation method
    * @param void
    * @return object data
    */
   public function order_coupon(){
      return $this->hasOne(\App\Models\Coupon::class,'id','order_coupon');
   }

 	/**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($orders) {
			//$orders->order_user_id()->delete();
			//$orders->order_user_id()->delete();
			//$orders->order_user_id()->delete();
         });
   }
		
}
