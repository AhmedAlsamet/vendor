<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    protected $table    = 'cities';
    protected $fillable = [
            'id',
            'city_name',
            'city_name_lat',
            'created_at',
            'updated_at',
        ];
    
    
       protected static function boot() {
          parent::boot();
          // if you disable constraints should by run this static method to Delete children data
             static::deleting(function($cities) {
             });
       }
            
}
