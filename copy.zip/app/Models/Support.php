<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Support extends Model {

protected $table    = 'supports';
protected $fillable = [
		'id',
		'admin_id',
        'support_username',
        'support_email',
        'support_phone',
        'support_msg',
		'created_at',
		'updated_at',
		'state',
	];

 	/**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot() {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
         static::deleting(function($support) {
         });
   }
		
}
