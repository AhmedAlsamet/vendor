<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    protected $table    = 'jobs';
    protected $fillable = [
            'id',
            'job_name',
            'job_name_lat',
            'created_at',
            'updated_at',
        ];
    
    
       protected static function boot() {
          parent::boot();
          // if you disable constraints should by run this static method to Delete children data
             static::deleting(function($jobs) {
             });
       }
            
}
