<?php


use App\Models\PaymentSetting;

function payment_setting(){
    $payment = PaymentSetting::first();

    if($payment == Null){
        $payment = new PaymentSetting();
        $payment->save();
    }
    return $payment;
}
