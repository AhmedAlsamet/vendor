<?php

namespace App\Events;

use App\Models\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class GameSessionEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    private int $type;
    private int $from;
    private int $to;
    private int $userId;
    private int $id;
    private User $user;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(
        int $type,
        int $from,
        int $to,
        int $userId,
        int $id,
        User $user
    ) {
        $this->type = $type;
        $this->from = $from;
        $this->to = $to;
        $this->userId = $userId;
        $this->id = $id;
        $this->user = $user;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PresenceChannel('presence.game'.$this->id);
        // return new PresenceChannel('presence.game.1');
    }

    public function broadcastAs()
    {
        return 'chat-message';
    }

    public function broadcastWith()
    {
        return [
            'type' => $this->type,
            'from' => $this->from,
            'to' => $this->to,
            'user' => $this->user,
            'id' => $this->id,
            'user' => $this->user->only(['name', 'email'])
        ];
    }
}
