<?php
namespace App;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class Sms
{
    public static function send($mobileNumber,$messageContent)
    {
        $phone = ltrim($mobileNumber, 0);

        $curl = curl_init();

            curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.oursms.com/api-a/msgs',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => '0552632951','token' => 'x4qAeoadKU9Y-FYeYD6d','src' => 'winner-ksa','dests' => '966'.$phone,'body' => $messageContent),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
          

    }
}
