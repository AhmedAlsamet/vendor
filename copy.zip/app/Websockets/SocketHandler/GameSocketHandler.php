<?php

namespace App\Websockets\SocketHandler;

use App\Models\Chat;
use App\Models\GameSession;
use App\Models\Question;
use App\Models\QuestionsCategory;
use App\Models\Session;
use App\Models\User;
use App\Models\UserQuestionCategory;
use BeyondCode\LaravelWebSockets\Apps\App;
use BeyondCode\LaravelWebSockets\QueryParameters;
use BeyondCode\LaravelWebSockets\WebSockets\Exceptions\UnknownAppKey;
use BeyondCode\LaravelWebSockets\WebSockets\WebSocketHandler;
use Carbon\Carbon;
use Ratchet\ConnectionInterface;
use Ratchet\RFC6455\Messaging\MessageInterface;
use Ratchet\WebSocket\MessageComponentInterface;
use TomatoPHP\LaravelAgora\Services\Agora;

abstract class GameSocketHandler implements MessageComponentInterface
{

    // protected $clients;
    protected $connections;

    public function __construct()
    {
        // $this->clients = new \SplObjectStorage();
        $this->connections = [];
    }

    protected function verifyAppKey(ConnectionInterface $connection)
    {
        $appKey = QueryParameters::create($connection->httpRequest)->get('appKey');

        if (!$app = App::findByKey($appKey)) {
            throw new UnknownAppKey($appKey);
        }

        $connection->app = $app;

        return $this;
    }

    protected function generateSocketId(ConnectionInterface $connection)
    {
        $socketId = sprintf('%d.%d', random_int(1, 1000000000), random_int(1, 1000000000));
        $id = QueryParameters::create($connection->httpRequest)->get('id');

        $connection->socketId = $id;

        return $this;
    }

    function onOpen(ConnectionInterface $conn)
    {
        $this->verifyAppKey($conn)->generateSocketId($conn);
        $id = QueryParameters::create($conn->httpRequest)->get('id');
        $key = QueryParameters::create($conn->httpRequest)->get('key');
        $type = QueryParameters::create($conn->httpRequest)->get('type');
        $compitetion_number = QueryParameters::create($conn->httpRequest)->get('compitetion_number');
        $compitetion_id = QueryParameters::create($conn->httpRequest)->get('compitetion_id');
        $compitetion_start_date = QueryParameters::create($conn->httpRequest)->get('compitetion_start_date');
        $compitetion_end_date = QueryParameters::create($conn->httpRequest)->get('compitetion_end_date');
        $user = QueryParameters::create($conn->httpRequest)->get('user');
        
        if ($key == null) {
            $session = Session::query()->select("*")
                ->where(function ($query) use ($type){
                    if($type == "game" || $type == "game_room"){
                        $query->where('type','like', "game%");
                    }
                    else{
                        $query->where('type','like', "tow_comp%")
                            ->orWhere("type",'like', "four_comp%");
                    }
                })
                ->where("state", "waiting_for")
                ->where(function($query)  use ($id,$type){
                    if($type == "game" || $type == "game_room"){
                        $query->where("user1", $id)
                            ->orWhere("user2", $id);
                    }else{
                        $query->where("user1", $id)
                            ->orWhere("user2", $id)
                            ->orWhere("user3", $id)
                            ->orWhere("user4", $id);
                    }
                })->first();
            if($session != null && ($session->user1 != null || $session->user2 != null || $session->user3 != null || $session->user4 != null)){
                $user = "";
                if($session->user1 == $id){
                    $user = "user1";
                    $session->user1 = null;
                }
                if($session->user2 == $id){
                    $user = "user2";
                    $session->user2 = null;
                }
                if($session->user3 == $id){
                    $user = "user3";
                    $session->user3 = null;
                }
                if($session->user4 == $id){
                    $user = "user4";
                    $session->user4 = null;
                }
                $session->save();
                $conn->send($this->sendLastSessionKey($session->link,$user));
                $conn->close();
                return;
            }
        }

        $session = Session::query()->select("*")->where("type", $type)->where("state", "waiting")->where("user1", "!=", $id)->where(function ($query) use ($type){
            if($type == "game" || $type == "game_room"){
                $query->where("user2", null);
            }else{
                $query->where("user2", null)
                ->orWhere("user3", null)
                ->orWhere("user4", null);
            }
        })->first();
        if ($key != null) {
            $session = Session::query()->select("*")
            // ->where(function ($query) {
            //     $query->where('type', "game")
            //     ->orWhere("type", "game_room");
            // })
            ->where("link", $key)
            ->where("state", "waiting")
            ->whereNull('user1')->orWhere("user1", "!=", $id)->whereNull('user2')->orWhere("user2", "!=", $id)
            ->whereNull('user3')->orWhere("user3", "!=", $id)->whereNull('user4')->orWhere("user4", "!=", $id)
            ->where(function ($query) use ($type){
                if($type == "game" || $type == "game_room"){
                    $query->where("user2", null)
                    ->orWhere("user1", null);   
                }else{
                    $query->where("user2", null)
                    ->orWhere("user1", null)
                    ->orWhere("user3", null)
                    ->orWhere("user4", null);
                }
            })->first();
            // dump($id);
            // dump($session);
            // dump($key);
        }
        if ($session != null) {
            if($user != null){
                $this->updateOneUserOrMakeNewSession($conn, $session, $id,$user,null,$session->number_of_users+1,true,false);
            }
            else{
                $session = $this->updateSession($conn, $session, $id,false);
            }
            // return successResponseJson(["data"=>$session,"state"=>"update","user"=>$userNumber]);
        } else {
            if ($key == null) {
                $session = $this->newSession($conn, $id,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date,);
                // return successResponseJson(["data"=>$session,"state"=>"new","user"=>"user1"]);
            } else {
                $conn->send($this->sendFullSession());
                $conn->close();
                return;
            }
        }
        // $this->clients->attach($conn);
        $conn->resourceId = $session->id;
        array_push($this->connections, $conn);
        dump("New connection! ({$conn->resourceId}) ($session->number_of_users) ($type)");
        if ($key != null && ($type == "game" || $type = "game_room")) {
            $this->sendAllChat($conn);
            $sessions = GameSession::query()->select("*")->where("session_id",$conn->resourceId)->get();
            if(count($sessions)>0){
                $conn->send($this->sendAllSessionSteps($sessions));
            }
        }
        $this->checkAndSendQuestion($session,$type);
    }

    function sendAllChat($conn){
        $chats = Chat::query()->select("*")->where("session_id",$conn->resourceId)->get();
        if(count($chats)>0){
            $conn->send(json_encode(["event"=>"chat","data"=>$chats]));
        }
    }
    function checkAndSendQuestion($session,$type){
        if($type == "four_comp" && $session->number_of_users == 4){
            $this->sendQuestionsToTeam($session,[is_int( $session->user1) ?  $session->user1 :  $session->user1->id,is_int($session->user2) ? $session->user2 : $session->user2->id],1);
            $this->sendQuestionsToTeam($session,[is_int( $session->user3) ?  $session->user3 :  $session->user3->id,is_int($session->user4) ? $session->user4 : $session->user4->id],2);
        }
        if($type == "tow_comp" && $session->number_of_users == 2){
            $this->sendQuestionsToTeam($session,[is_int($session->user1) ? $session->user1 : $session->user1->id],1);
            $this->sendQuestionsToTeam($session,[is_int($session->user2) ? $session->user2 : $session->user2->id],2);
        }
    }
    function newSession($conn, $id,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date)
    {
        $session = new Session();
        $session->user1 = $id;
        $session->link = $this->v4();
        $session->type = $type;
        $session->state = "waiting";
        $session->number_of_users = 1;
        $session->user1_state = "exist";
        $session->compitetion_number = $compitetion_number;
        $session->compitetion_id = $compitetion_id;
        $session->compitetion_start_date = $compitetion_start_date;
        $session->compitetion_end_date = $compitetion_end_date;
        
        $session->save();
        $session->token = Agora::make(id: $session->id)->uId(0)->channel($type)->token();
        if($type == "four_comp")
        $session->token2 = Agora::make(id: $session->id)->uId(0)->channel($type."2")->token();
        $session->save();
        $conn->send($this->sendUpdateUsersState($session, "user1", "new"));
        return $session;
    }

    function updateSession($conn, $session, $id ,$isBot)
    {
        $session->state = "started";
        if($session->type == "four_comp"){
            if($session->user3 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user3",null,3,false,$isBot);
            }
            if($session->user2 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user2",null,2,false,$isBot);
            }
            if($session->user1 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user1",null,2,true,$isBot);
            }
            if($session->user4 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user4",null,4,true,$isBot);
            }
        }else{
            if($session->user2 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user2","user1",2,true,$isBot);
            }
            if($session->user1 == null){
                $session = $this->updateOneUserOrMakeNewSession($conn, $session, $id,"user1","user2",2,true,$isBot);
            }
        }
        return $session;
    }

    function updateOneUserOrMakeNewSession(ConnectionInterface $conn,Session $session, int $id ,string $user,$anotherUser,int $count,bool $withSendUpdate,bool $isBot){
        $session[$user] = $id;
        $session[$user."_state"] = "exist";
        $session->number_of_users = $count;
        $session->save();
        if($withSendUpdate){
            $conn->send($this->sendUpdateUsersState($session, $isBot ? $anotherUser : $user, "update"));
            $users = $this->getAnotherUser($session->id, $id);
            if(!$isBot){
                if ($users != [])
                    foreach ($users as $u) {
                        $u->send($this->sendUpdateUsersState($session, $anotherUser ?? $user, "update"));
                    }
                else{
                    $compitetion_number = QueryParameters::create($conn->httpRequest)->get('compitetion_number');
                    $compitetion_id = QueryParameters::create($conn->httpRequest)->get('compitetion_id');
                    $compitetion_start_date = QueryParameters::create($conn->httpRequest)->get('compitetion_start_date');
                    $compitetion_end_date = QueryParameters::create($conn->httpRequest)->get('compitetion_end_date');
                    $session = $this->newSession($conn, $id,$session->type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date,);
                }
            }
        }
        return $session;
    }

    function sendQuestionsToTeam($session,$users,$teamNumber){
        $references = UserQuestionCategory::query()->select("question_category_id")->whereIn('user_id', $users)->pluck('question_category_id')->toArray();
        if(count($references) == 0){
            $references = QuestionsCategory::query()->select("id")->pluck('id')->toArray();
        }
        $temp = [];
        foreach ($references as $key => $value) {
            array_push($temp, $value);
        }
        $questions = Question::all()->whereIn("question_category_id",$temp)->random(50);
        $team1 = $this->getTeamUsers($session->id,$teamNumber);
        foreach ($team1 as $u) {
            $u->send($this->sendQuestions($questions));
        }
    }

    function onClose(ConnectionInterface $conn)
    {
        $session = Session::find($conn->resourceId);

        $users = $this->getAnotherUser($conn->resourceId, $conn->socketId);
        if ($users != []) {
            foreach ($users as $u) {
                $u->send($this->sendUserClose($session->number_of_users,$conn->socketId));
            }
        }
        // dump($session);
        // $this->clints->detach($conn);
        if (($key = array_search($conn, $this->connections)) !== false) {
            unset($this->connections[$key]);
        }
        if($session != null){
            $session->state = "waiting_for";
            $session->number_of_users = $session->number_of_users - 1;
            if ($this->getCount($conn->resourceId) == 0 || $this->cureentUsersAreBots($session)) {
                $session->state = "end";
            }
            $session->save();
        }
        dump('closed'.count($this->connections));
    }

    function onError(ConnectionInterface $conn, \Exception $e)
    {
        dump($e);
        dump('onerror');
    }

    function getCount(int $id)
    {
        $result = 0;
        foreach ($this->connections as $value) {
            if ($value->resourceId == $id) {
                $result++;
            }
        }
        return $result;
    }

    function cureentUsersAreBots($session)
    {
        $result = User::query()->where("type","!=","bot")->whereIn("id", [$session->user1,$session->user2,$session->user3,$session->user4])->get();
        return count($result) == 0;
    }
    function getAnotherUser(int $sessionId, int $userId)
    {
        $listOfUsers = [];
        foreach ($this->connections as $value) {
            if ($value->resourceId == $sessionId && $value->socketId != $userId) {
                array_push($listOfUsers, $value);
                // return $value;
            }
        }
        return $listOfUsers;
    }
    
    function getUserById($id){
        $result = null;
        foreach ($this->connections as $value) {
            if ($value->socketId == $id) {
                $result =  $value;
            }
        }
        return $result;
    }

    function getAllUsers(int $sessionId)
    {
        $listOfUsers = [];
        foreach ($this->connections as $value) {
            if ($value->resourceId == $sessionId) {
                array_push($listOfUsers, $value);
                // return $value;
            }
        }
        return $listOfUsers;
    }
    function getTeamUsers(int $sessionId, int $teamNumber)
    {
        $listOfUsers = [];
        $session = Session::find($sessionId);
        if($session->type == "tow_comp"){
            foreach ($this->connections as $value) {
                if ($value->resourceId == $sessionId) {
                    if($teamNumber == 1 && $value->socketId == $session->user1){
                        array_push($listOfUsers, $value);
                    }else if($teamNumber == 2 && $value->socketId == $session->user2){
                        array_push($listOfUsers, $value);
                    }
                }
            }
        }
        else{
            foreach ($this->connections as $value) {
                if ($value->resourceId == $sessionId) {
                    if($teamNumber == 1&& $value->socketId == $session->user1 || $value->socketId == $session->user2){
                        array_push($listOfUsers, $value);
                    }else if($value->socketId == $session->user3 || $value->socketId == $session->user4){
                        array_push($listOfUsers, $value);
                    }
                }
            }
        }
        return $listOfUsers;
    }
    function sendUserClose($number_of_users,$user)
    {
        return json_encode(["event" => "close", "ERROR" => "Nobody in This Session","count"=>$number_of_users,"user"=>$user]);
    }
    function sendFullSession()
    {
        return json_encode(["event" => "full", "ERROR" => "FullSession"]);
    }
    function sendUpdateUsersState(&$session, $userNumber, $state)
    { 
        if($session->user1 != null && (is_int($session->user1)||is_string($session->user1)))
        {
            $user = User::all()->where("id", $session->user1);
            dump("Count Is".count($user));
            if(count($user) > 0){
                dump("User 1".$user->first());
                $session->user1 = $user->first();
            }
            else{
                $session->user1 = User::all()->where("id", 714)->first();
            }
        }
        if($session->user2 != null && (is_int($session->user2)||is_string($session->user2))){
            $user = User::all()->where("id", $session->user2);
            dump("Count Is".count($user));
            if(count($user) > 0){
                dump("User 2".$user->first());
                $session->user2 = $user->first();
            }
            else{
                $session->user2 = User::all()->where("id", 611)->first();
            }
        }
        if($session->user3 != null && (is_int($session->user3)||is_string($session->user3))){
            $user = User::all()->where("id", $session->user3);
            if(count($user) > 0){
                $session->user3 = $user->first();
            }
            else{
                $session->user3 = User::all()->where("id", 500)->first();
            }
        }
        if($session->user4 != null && (is_int($session->user4)||is_string($session->user4))){
            $user = User::all()->where("id", $session->user4);
            if(count($user) > 0){
                $session->user4 = $user->first();
            }
            else{
                $session->user4 = User::all()->where("id", 75)->first();
            }
        }
        return json_encode(["event" => "open", "state" => $state, "user" => $userNumber,"data" => $session]);
    }
    function sendLastSessionKey($key,$user)
    {
        return json_encode(["event" => "exist", "key" => $key,"user" => $user]);
    }
    function sendQuestions($questions)
    {
        return json_encode(["event" => "questions", "data" => $questions]);
    }
    function sendAllSessionSteps($data)
    {
        return json_encode(["event" => "all_steps", "data" => $data]);
    }

    function v4()
    {
        // return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        return sprintf(
            '%04x%04x-%04x-%04x%04x',

            // 32 bits for "time_low"
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),

            // 16 bits for "time_mid"
            mt_rand(0, 0xffff),

            // 16 bits for "time_hi_and_version",
            // four most significant bits holds version number 4
            mt_rand(0, 0x0fff) | 0x4000,

            // 16 bits, 8 bits for "clk_seq_hi_res",
            // 8 bits for "clk_seq_low",
            // two most significant bits holds zero and one for variant DCE1.1
            mt_rand(0, 0x3fff) | 0x8000,

            // 48 bits for "node"
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff)
        );
    }
}
