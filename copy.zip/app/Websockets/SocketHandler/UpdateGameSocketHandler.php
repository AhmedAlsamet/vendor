<?php

namespace App\Websockets\SocketHandler;

use App\Models\Chat;
use App\Models\CompitetionSession;
use App\Models\GameResult;
use App\Models\GameSession;
use App\Models\Level;
use App\Models\Post;
use App\Models\Question;
use App\Models\Session;
use App\Models\User;
use App\Models\UserPoint;
use Exception;
use Ratchet\ConnectionInterface;
use Ratchet\RFC6455\Messaging\MessageInterface;
use Ratchet\WebSocket\MessageComponentInterface;

class UpdateGameSocketHandler extends GameSocketHandler implements MessageComponentInterface
{


    function onMessage(ConnectionInterface $from, MessageInterface $msg)
    {

        
        $body = collect(json_decode($msg->getPayload(), true));

        if($body->get("message_type")=="game_step"){
            $gameStep = new GameSession();
            $gameStep->session_id = $body->get("id");
            $gameStep->from = $body->get("from");
            $gameStep->to = $body->get("to");
            $gameStep->user = $body->get("user");
            $gameStep->type = $body->get("type");
            $gameStep->save();
                
            $user2 = $this->getAnotherUser($from->resourceId,$from->socketId);
            if($user2 != [])
            $user2[0]->send(json_encode(["event"=>"game_step","data"=>$gameStep]));
            // $this->connections[0]->send(count($this->connections));
        }
        else if($body->get("message_type")=="game_result"){
            $gameResult = GameResult::query()->where("session_id",$body->get("session_id"))->first();
            $res = [0,0,0,0];
            if($gameResult == null){
                $res = $this->newResult(
                    $body->get("compitetion_id"),
                    $body->get("compitetion_number"),
                    $body->get("compitetion_start_date"),
                    $body->get("compitetion_end_date"),
                    $body->get("session_id"),
                    $body->get("user_win1"),$body->get("user_win2")??null,
                    $body->get("type"),$body->get("state"),$body->get("user_loss1"),
                    $body->get("user_loss2")??null,$body->get("winner_result"),$body->get("losser_result"),
                );
            }
            // $from->close();
            $from->send(json_encode(["event"=>"end","win_points"=>$res[0],"win_xp"=>$res[1],"loss_points"=>$res[2],"loss_xp"=>$res[3]]));
            $user2 = $this->getAnotherUser($from->resourceId,$from->socketId);
            if($user2 != [])
            $user2[0]->send(json_encode(["event"=>"end","win_points"=>$res[0],"win_xp"=>$res[1],"loss_points"=>$res[2],"loss_xp"=>$res[3]]));
        }
        else if($body->get("message_type")=="chat"){
            $chat = new Chat();
            $chat->user = $from->socketId;
            $chat->session_id = $from->resourceId;
            $chat->type = $body->get("type");
            $chat->title = $body->get("title");
            $chat->save();
            dump("chat");
            if($body->get("team") != null){
                $users = $this->getTeamUsers($from->resourceId,$body->get("team"));
                if($users != [])
                foreach ($users as $u) {
                    if($u != $from) {
                        $u->send(json_encode(["event"=>"chat","data"=>[$chat]]));
                    }
                }
            }else{
                $users = $this->getAnotherUser($from->resourceId,$from->socketId);
                if($users != [])
                foreach ($users as $u) {
                    $u->send(json_encode(["event"=>"chat","data"=>[$chat]]));
                }
            }
        }
        else if($body->get("message_type")=="add_bot"){
            $session = Session::all()->where("id",$from->resourceId)->first();
            $user = User::all()->where("type","bot")->random(1)->first();
            $session = $this->updateSession($from, $session, $user->id,true);
            $this->checkAndSendQuestion($session, $session->type);
        }
        else if($body->get("message_type")=="change_session_type"){
            $session = Session::all()->where("id",$from->resourceId)->first();
            $session->type = "tow_comp";
            $session->save();
            $user = User::all()->where("type","bot")->random(1)->first();
            $session = $this->updateSession($from, $session, $user->id,true);
            $this->checkAndSendQuestion($session, $session->type);
        }
        else if($body->get("message_type")=="compitetion_step"){

            $question = Question::find($body->get("question_id"));
            $scores = ["team1_score"=>$body->get("team1_score"),"team2_score"=>$body->get("team2_score")];
            
            $compitetionStep = new CompitetionSession();
            $compitetionStep->session_id = $body->get("id");
            $compitetionStep->user = $body->get("user");
            $compitetionStep->team = $body->get("team");
            $compitetionStep->type = $body->get("type");
            $compitetionStep->question_id = $body->get("question_id");
            $compitetionStep->answer = $body->get("answer");
            $compitetionStep->correct_answer = $question->question_correct_answer;
            $compitetionStep->save();

            if($body->get("type") == "answer"){
                if($body->get("answer") == $question->question_correct_answer){
                    $scores[$body->get('team')."_score"]++;
                    if($scores[$body->get('team')."_score"] == 10){
                        $teamNumber = (int)substr($body->get('team'), -1);
                        $winners = $this->getTeamUsers($from->resourceId,$teamNumber);
                        $teamNumber = $teamNumber == 1 ? 2 : 1;
                        $losser = $this->getTeamUsers($from->resourceId,$teamNumber);
                        $winner1 = 0;
                        $losser1 = 0;
                        if(count($winners)>0){
                            $winner1 = $winners[0]->socketId;
                        }
                        if(count($losser)>0){
                            $losser1 = $losser[0]->socketId;
                        }
                        $res = $this->newResult(
                            $body->get("compitetion_id"),
                            $body->get("compitetion_number"),
                            $body->get("compitetion_start_date"),
                            $body->get("compitetion_end_date"),
                            $from->resourceId,
                            $winner1,count($winners) > 1 ? $winners[1]->socketId : null,
                            $body->get("session_type"),$body->get('team')."_win",$losser1,
                            count($losser) > 1 ? $losser[1]->socketId : null,
                            10,$scores["team".$teamNumber."_score"]
                        );
                        $users = $this->getAllUsers($from->resourceId,$from->socketId);
                        foreach ($users as $u) {
                            $u->send(json_encode(["event"=>"compitetion_end",
                            "team"=>$body->get('team'),...$scores,
                            "win_points"=>$res[0],"win_xp"=>$res[1],"loss_points"=>$res[2],"loss_xp"=>$res[3]
                        ]));
                        }
                        return;
                    }
                    // else{
                    //     foreach ($users as $u) {
                    //         $u->send(json_encode(["event"=>"compitetion_step","data"=>$compitetionStep,...$scores]));
                    //     }
                    // }
                }
                $teamNumber = (int)substr($body->get('team'), -1);
                $team1 = $this->getTeamUsers($from->resourceId,$teamNumber);
                $teamNumber = $teamNumber == 1 ? 2 : 1;
                $team2 = $this->getTeamUsers($from->resourceId,$teamNumber);
                foreach ($team1 as $u) {
                    $u->send(json_encode(["event"=>"question_answered","data"=>$compitetionStep,...$scores]));
                }
                foreach ($team2 as $u) {
                    $u->send(json_encode(["event"=>"compitetion_step","data"=>$compitetionStep,...$scores]));
                }
            }
            else if($body->get("type") == "confirm"){
                $teamNumber = (int)substr($body->get('team'), -1);
                $users = $this->getTeamUsers($from->resourceId,$teamNumber);
                foreach ($users as $u) {
                    $u->send(json_encode(["event"=>"question_confirmed","data"=>$compitetionStep]));
                }
            }
            else if($body->get("type") == "cancel"){
                $teamNumber = (int)substr($body->get('team'), -1);
                $users = $this->getTeamUsers($from->resourceId,$teamNumber);
                foreach ($users as $u) {
                    $u->send(json_encode(["event"=>"question_canceled","data"=>$compitetionStep]));
                }
            }
        }
        else if($body->get("message_type")=="compitetion_time_end"){

            $scores = ["team1_score"=>$body->get("team1_score"),"team2_score"=>$body->get("team2_score")];

            $users = $this->getAllUsers($from->resourceId,$from->socketId);
            if($users != [])
            {
                $state = $scores["team1_score"] > $scores["team2_score"] ? "team1_win" : ($scores["team1_score"] < $scores["team2_score"] ? "team2_win" : "draw");
                $teamNumber = $state == "team1_win" ? 1 : 2;
                $winners = $this->getTeamUsers($from->resourceId,$teamNumber);
                $teamNumber = $teamNumber == 1 ? 2 : 1;
                $losser = $this->getTeamUsers($from->resourceId,$teamNumber);
                $winner1 = 0;
                $losser1 = 0;
                if(count($winners)>0){
                    $winner1 = $winners[0]->socketId;
                }
                if(count($losser)>0){
                    $losser1 = $losser[0]->socketId;
                }

                $winnerPoints = 0;
                $losserPoints = 0;
                if($state == "team1_win"){
                    $winnerPoints = $scores["team1_score"];
                    $losserPoints = $scores["team2_score"];
                }
                else if($state == "team2_win"){
                    $winnerPoints = $scores["team2_score"];
                    $losserPoints = $scores["team1_score"];
                }else{
                    $winnerPoints = $scores["team2_score"];
                    $losserPoints = $scores["team1_score"];
                }

                $res = $this->newResult(
                    $body->get("compitetion_id"),
                    $body->get("compitetion_number"),
                    $body->get("compitetion_start_date"),
                    $body->get("compitetion_end_date"),
                    $from->resourceId,
                    $winner1,count($winners) > 1 ? $winners[1]->socketId : null,
                    $body->get("session_type"),$state,$losser1,
                    count($losser) > 1 ? $losser[1]->socketId : null,
                    $winnerPoints,
                    $losserPoints
                );
                foreach ($users as $u) {
                    $u->send(json_encode(["event"=>"compitetion_time_end",
                    "result"=>$state,...$scores,
                    "win_points"=>$res[0],"win_xp"=>$res[1],"loss_points"=>$res[2],"loss_xp"=>$res[3]
                ]));
                }
            }
        }
        else if($body->get("message_type")=="cancel"){
            $users = $this->getAllUsers($body->get("id"));
            foreach ($users as $u) {
                if($u->socketId != $from->socketId)
                $u->send($this->sendFullSession());
            }
            $session = Session::find($body->get("id"))->delete();
        }
    }

    function newResult($compitetion_id,$compitetion_number,$compitetion_start_date,$compitetion_end_date,$session_id,$user_win1,$user_win2,$type,$state,$user_loss1,$user_loss2,$winner_result,$losser_result,){
        $win_points = 0;
        $win_xp = 0;
        $loss_points = 0;
        $loss_xp = 0;
        
        $gameResult = new GameResult();
        $gameResult->compitetion_number = $compitetion_number;
        $gameResult->compitetion_id = $compitetion_id;
        $gameResult->compitetion_start_date = $compitetion_start_date;
        $gameResult->compitetion_end_date = $compitetion_end_date;
        $gameResult->session_id = $session_id;
        $gameResult->user_win1 = $user_win1;
        $gameResult->user_win2 = $user_win2;//??null;
        $gameResult->type = $type;
        $gameResult->state = $state;
        $gameResult->user_loss1 = $user_loss1;
        $gameResult->user_loss2 = $user_loss2;//??null;
        $gameResult->winner_result = $winner_result;
        $gameResult->losser_result = $losser_result;
        $gameResult->save();
        if($winner_result > 0){
            if($user_win1 != null && $user_win1 != 0){
                $res = $this->addPointsToUser($user_win1,$winner_result,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date);
                $win_points = $res[0];
                $win_xp = $res[1];
            }
            if($user_win2 != null && $user_win2 != 0){
                $res = $this->addPointsToUser($user_win2,$winner_result,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date);
                $win_points = $res[0];
                $win_xp = $res[1];
            }
        }
        if($losser_result > 0 && $type != "game"){
            if($user_loss1 != null && $user_loss1 != 0){
                $res = $this->addPointsToUser($user_loss1,$losser_result,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date);
                $loss_points = $res[0];
                $loss_xp = $res[1];
            }
            if($user_loss2 != null && $user_loss2 != 0){
                $res = $this->addPointsToUser($user_loss2,$losser_result,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date);
                $loss_points = $res[0];
                $loss_xp = $res[1];
            }
        }
        return [$win_points,$win_xp,$loss_points,$loss_xp];
    }

    function addPointsToUser($id,$winPoints,$type,$compitetion_number,$compitetion_id,$compitetion_start_date,$compitetion_end_date,){
        $xp_points = 0;
        $win_points = 0;
        // if($type == "game"){
            
        // }
        // else 
        if($type == "four_comp"){
            
        }
        else if($type == "tow_comp"){

        }
        $user = User::find($id);
        $last_level = Level::all()->where("points",">=",$user->xp_points)->first()->name;
        $user->xp_points = $xp_points + ($user->xp_points ?? 0);
        $user->win_points = $win_points + ($user->win_points ?? 0);
        $new_level = Level::all()->where("points",">=",$user->xp_points)->first()->name;
        $user->save();
        if($last_level != $new_level){
            $u = $this->getUserById($id);
            if($u != null){
                $u->send(json_encode(["event"=>"change_level","data"=>$new_level]));
            }
        }
        $point = new UserPoint();
        $point->user_id = auth()->user()->id;
        $point->type = $type;
        $point->points = $win_points;
        $point->compitetion_number = $compitetion_number;
        $point->compitetion_id = $compitetion_id;
        $point->compitetion_start_date = $compitetion_start_date;
        $point->compitetion_end_date = $compitetion_end_date;
        $point->save();
        return [$win_points,$xp_points];
    }
}





        // $body = collect(json_decode($msg->getPayload(), true));

        // $payload = $body->get('payload');
        // $id = $body->get('id');

        // dump($payload, $id);

        // $post = Post::query()->findOrFail($id);

        // $repo = new PostRepository();

        // $updated = $repo->update($post, $payload);

        // $response = (new PostResource($updated))->toJson();

        // $from->send($response);
        // $from->send("DONE");