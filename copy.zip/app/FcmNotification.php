<?php

namespace App;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Google\Client as GoogleClient;
use Illuminate\Support\Facades\Http;


class FcmNotification extends Model
{


  public static  function sendNotification($title ,$description,$user)
  {


    // $fcm = "DEVICE_FCM_TOKEN";

    try{
    $credentialsFilePath = "json/file.json";  // local
    // $credentialsFilePath = Http::get(asset('json/file.json')); // in server
    // dd($credentialsFilePath);
    $client = new GoogleClient();
    $client->setAuthConfig($credentialsFilePath);
    $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
    $client->refreshTokenWithAssertion();
    $token = $client->getAccessToken();

    $access_token = $token['access_token'];

    $headers = [
        "Authorization: Bearer $access_token",
        'Content-Type: application/json'
    ];
    $data = [];
    if($user == ""){
        $data = [
            "message" => [
                "topic" => "game",
                "notification" => [
                    "title" => $title,
                    "body" => $description,
                ],
            ]
        ];
    }else{
        $data = [
            "message" => [
                "token" => $user,//"fM41Ur6gR_KWYJrD0mqQJo:APA91bHIOR-QwO7Ork7-Zaen3o8pTru-74-fewzHvZbKf-vTx_ZMTN7bEFWW-0lLLbCCuWrhp7z9jfyRaCwwDyHkjwf6WK6avpQ2u9C4jpUEN5GCI0-i5Epkl61RLNyPj-yzrIyEEujb",//$users[0],
                "notification" => [
                    "title" => $title,
                    "body" => $description,
                ],
            ]
        ];
    }
    
    $payload = json_encode($data);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/v1/projects/who-winner/messages:send');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_VERBOSE, true); // Enable verbose output for debugging
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        return response()->json([
            'message' => 'Curl Error: ' . $err
        ], 500);
    } else {
        return response()->json([
            'message' => 'Notification has been sent',
            'response' => json_decode($response, true)
        ]);
    }
}catch (\Throwable $th) {
       dd($th);
    }
   

    //   $SERVER_API_KEY = "AAAAUzIyArk:APA91bHeKwmMMC-Q9BP_KdTc5jFxsilo5ubkKe77hO1BYkyNz6lRmKIDtiqLGwyR8IyOhMc98uP-jx188NSg-ucVxPhtTFs5fJZOvF2SvDJsEteeyLy_V4qAPW215gzOHeAq-MqSZvSH";

    //   $data = [
    //       "notification" => [
    //           "title" => $title,
    //           "body" => $body,
    //           "content_available" => true,
    //           "priority" => "high",
    //       ],
    //       "data" => [
    //         "title" => $title,
    //         "body" => $body,
    //         "content_available" => true,
    //         "priority" => "high",
    //     ],
    //     "registration_ids"=>[
    //       ...$users
    //     ]
    //   ];
    //   $dataString = json_encode($data);

    //   $headers = [
    //       'Authorization: key=' . $SERVER_API_KEY,
    //       'Content-Type: application/json',
    //   ];
    //   try {

    //   $ch = curl_init();
    //   curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    //   curl_setopt($ch, CURLOPT_POST, true);
    //   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    //   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    //   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //   curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

    //   $response = json_decode(curl_exec($ch) , true);
    //   // dd(curl_exec($ch));

    // } catch (\Throwable $th) {
    //    dd($th);
    // }

  }

  // public static  function sendNotification($title ,$body)
  // {

  //     $SERVER_API_KEY = "AAAAUzIyArk:APA91bHeKwmMMC-Q9BP_KdTc5jFxsilo5ubkKe77hO1BYkyNz6lRmKIDtiqLGwyR8IyOhMc98uP-jx188NSg-ucVxPhtTFs5fJZOvF2SvDJsEteeyLy_V4qAPW215gzOHeAq-MqSZvSH";

  //     $data = [
  //         "notification" => [
  //             "title" => $title,
  //             "body" => $body,
  //             "content_available" => true,
  //             "priority" => "high",
  //         ],
  //         "data" => [
  //           "title" => $title,
  //           "body" => $body,
  //           "content_available" => true,
  //           "priority" => "high",
  //       ],
  //         "to"=> "/topics/all"
  //     ];
  //     $dataString = json_encode($data);

  //     $headers = [
  //         'Authorization: key=' . $SERVER_API_KEY,
  //         'Content-Type: application/json',
  //     ];
  //     try {

  //     $ch = curl_init();
  //     curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
  //     curl_setopt($ch, CURLOPT_POST, true);
  //     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  //     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  //     curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

  //     $response = json_decode(curl_exec($ch) , true);
  //     // dd(curl_exec($ch));

  //   } catch (\Throwable $th) {
  //      dd($th);
  //   }
  // }



    // public static function sendToSingle($token, $title, $body, $click_action=NULL , $file){

    //     $optionBuilder = new OptionsBuilder();
    //     $optionBuilder->setTimeToLive(60*20);

    //     $notificationBuilder = new PayloadNotificationBuilder($title);
    //     $notificationBuilder->setBody($body)
    //             				    ->setSound('default')
    //                         // ->setIcon(NULL)
    //                         ->setClickAction($click_action);

    //       $dataBuilder = new PayloadDataBuilder();
    //       $dataBuilder->addData([
    //         'token' =>  $file,
    //         'title' => $title,
    //         'body' => $body
    //       ]);
    //       $dataBuilde->priority('high');
    //       $option = $optionBuilder->build();
          
    //       $notification = $notificationBuilder->build();
    //       $data = $dataBuilder->build();



    //       // $token = "a_registration_from_your_database";

    //       $downstreamResponse = FCM::sendTo($token, $option, null, $data);

    //       $downstreamResponse->numberSuccess();
    //       $downstreamResponse->numberFailure();
    //       $downstreamResponse->numberModification();

    //       // return Array - you must remove all this tokens in your database
    //       $downstreamResponse->tokensToDelete();

    //       // return Array (key : oldToken, value : new token - you must change the token in your database)
    //       $downstreamResponse->tokensToModify();

    //       // return Array - you should try to resend the message to the tokens in the array
    //       $downstreamResponse->tokensToRetry();

    //       // return Array (key:token, value:error) - in production you should remove from your database the tokens
    //       $downstreamResponse->tokensWithError();

    //       // dd($downstreamResponse);

    // }

    // public static function sendToMultiple($model, $title, $body, $click_action=NULL ){
    //   $optionBuilder = new OptionsBuilder();
    //   $optionBuilder->setPriority("high");

    //   $optionBuilder->setTimeToLive(60*20);

    //   $notificationBuilder = new PayloadNotificationBuilder($title['title']);
    //   $notificationBuilder->setBody($body)
    //                       ->setSound('default')
    //                       // ->setIcon(NULL)
    //                       ->setClickAction($click_action);

    //   // dd($title['file']);
    //   // file

    //   $dataBuilder = new PayloadDataBuilder();

    //   $date = array(
    //     "file" =>   $title['file'],
    //     "title" =>  $title['title'],
    //     "body" =>  $body
    //   );
    //   $dataBuilder->addData($date);
    //   // $dataBuilder->priority('high');
      
    //   // dd($dataBuilder);

    //   $option = $optionBuilder->build();

    //   $notification = $notificationBuilder->build();
    //   $data = $dataBuilder->build();

    //   // You must change it to get your tokens
    //   $tokens = $model->pluck('fcm_token')->toArray();


    //   $downstreamResponse = FCM::sendTo($tokens, $option, null, $data);

    //   $downstreamResponse->numberSuccess();
    //   $downstreamResponse->numberFailure();
    //   $downstreamResponse->numberModification();

    //   // return Array - you must remove all this tokens in your database
    //   $downstreamResponse->tokensToDelete();

    //   // return Array (key : oldToken, value : new token - you must change the token in your database)
    //   $downstreamResponse->tokensToModify();

    //   // return Array - you should try to resend the message to the tokens in the array
    //   $downstreamResponse->tokensToRetry();

    //   // return Array (key:token, value:error) - in production you should remove from your database the tokens present in this array
    //   $downstreamResponse->tokensWithError();

    //   // dd($downstreamResponse);

    // }




}
