<?php
namespace App\Http\Controllers\ValidationsApi\V1;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class CountriesRequest extends FormRequest {

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return false;
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
             'Country_name'=>'required',
             'Country_code'=>'required',
             'Country_flag'=>'required|image',
             'Country_currency'=>'required',
             'Country_name_en'=>'required',
             'Country_currency_en'=>'required',
             'Country_val'=>'required|numeric|integer',
		];
	}


	protected function onUpdate() {
		return [
             'Country_name'=>'required',
             'Country_code'=>'required',
             'Country_flag'=>'required|image',
             'Country_currency'=>'required',
             'Country_name_en'=>'required',
             'Country_currency_en'=>'required',
             'Country_val'=>'required|numeric|integer',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
             'Country_name'=>trans('admin.Country_name'),
             'Country_code'=>trans('admin.Country_code'),
             'Country_flag'=>trans('admin.Country_flag'),
             'Country_currency'=>trans('admin.Country_currency'),
             'Country_name_en'=>trans('admin.Country_name_en'),
             'Country_currency_en'=>trans('admin.Country_currency_en'),
             'Country_val'=>trans('admin.Country_val'),
		];
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}