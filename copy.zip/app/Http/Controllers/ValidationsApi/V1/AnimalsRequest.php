<?php
namespace App\Http\Controllers\ValidationsApi\V1;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AnimalsRequest extends FormRequest {

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
             'animal_name_ar'=>'required',
             'animal_name_en'=>'required',
             'animal_price'=>'',
             'animal_photo'=>'required|image',
             'animal_gender'=>'',
             'animal_phone'=>'nullable',
             'animal_type'=>'exists:types,id|nullable',
             'animal_area'=>'',
             'animal_city'=>'',
             'animal_latitude'=>'',
             'animal_longitude'=>'',
             'animal_details'=>'',
             'animal_user_id'=>'',
             'animal_catagory'=>'',
             'animal_day'=>'',
             'animal_month'=>'',
             'animal_year'=>'',
             'animal_weight'=>'',
             'animal_car_brand'=>'required_if:animal_catagory,==,10|exists:car_brands,id|nullable',
             'animal_car_kilometers'=>'required_if:animal_catagory,==,10|exists:kilometers,id|nullable',
             'animal_car_status'=>'required_if:animal_catagory,==,10|exists:car_status,id|nullable',
             'animal_car_engine_capacities'=>'required_if:animal_catagory,==,10|exists:engine_capacities,id|nullable',
             'animal_car_motion_vectors'=>'required_if:animal_catagory,==,10|exists:motion_vectors,id|nullable',
             'animal_car_payment_methods'=>'required_if:animal_catagory,==,10|exists:payment_methods,id|nullable',
             'animal_car_fuel_types'=>'required_if:animal_catagory,==,10|exists:fuel_types,id|nullable',
             'animal_car_color'=>'required_if:animal_catagory,==,10|exists:colors,id|nullable',
             'animal_car_body_types'=>'required_if:animal_catagory,==,10|exists:body_types,id|nullable',
             'animal_car_connection_types'=>'required_if:animal_catagory,==,10|exists:connection_types,id|nullable',
             'manufacturing_years'=>'required_if:animal_catagory,==,10|exists:manufacturing_years,id|nullable'
			 
		];
	}

	protected function onUpdate() {
		return [
             'animal_name_ar'=>'required',
             'animal_name_en'=>'required',
             'animal_price'=>'',
             'animal_photo'=>'required|image',
             'animal_gender'=>'',
             'animal_phone'=>'nullable',
             'animal_type'=>'required|exists:types',
             'animal_area'=>'',
             'animal_city'=>'',
             'animal_latitude'=>'',
             'animal_longitude'=>'',
             'animal_details'=>'',
             'animal_user_id'=>'',
             'animal_catagory'=>'',
             'animal_day'=>'',
             'animal_month'=>'',
             'animal_year'=>'',
             'animal_weight'=>'',
             'animal_car_brand'=>'required_if:animal_catagory,==,10|exists:car_brands,id',
             'animal_car_kilometers'=>'required_if:animal_catagory,==,10|exists:kilometers,id',
             'animal_car_status'=>'required_if:animal_catagory,==,10|exists:car_status,id',
             'animal_car_engine_capacities'=>'required_if:animal_catagory,==,10|exists:engine_capacities,id',
             'animal_car_motion_vectors'=>'required_if:animal_catagory,==,10|exists:motion_vectors,id',
             'animal_car_payment_methods'=>'required_if:animal_catagory,==,10|exists:payment_methods,id',
             'animal_car_fuel_types'=>'required_if:animal_catagory,==,10|exists:fuel_types,id',
             'animal_car_color'=>'required_if:animal_catagory,==,10|exists:colors,id',
             'animal_car_body_types'=>'required_if:animal_catagory,==,10|exists:body_types,id',
             'animal_car_connection_types'=>'required_if:animal_catagory,==,10|exists:connection_types,id',
             'manufacturing_years'=>'required_if:animal_catagory,==,10|exists:manufacturing_years,id',
			 
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}



	public function attributes() {
		return [
			'animal_name_ar'=>trans('admin.animal_name_ar'),
			'animal_name_en'=>trans('admin.animal_name_en'),
			'animal_price'=>trans('admin.animal_price'),
			'animal_photo'=>trans('admin.animal_photo'),
			'animal_gender'=>trans('admin.animal_gender'),
			'animal_phone'=>trans('admin.animal_phone'),
			'animal_type'=>trans('admin.animal_type'),
			'animal_area'=>trans('admin.animal_area'),
			'animal_city'=>trans('admin.animal_city'),
			'animal_latitude'=>trans('admin.animal_latitude'),
			'animal_longitude'=>trans('admin.animal_longitude'),
			'animal_details'=>trans('admin.animal_details'),
			'animal_user_id'=>trans('admin.animal_user_id'),
			'animal_catagory'=>trans('admin.animal_catagory'),
			'manufacturing_years'=>trans('admin.manufacturingyears'),
			'animal_car_brand'=>trans('admin.animal_car_brand'),
			'animal_car_kilometers'=>trans('admin.animal_car_kilometers'),
			'animal_car_status'=>trans('admin.animal_car_status'),
			'animal_car_engine_capacities'=>trans('admin.animal_car_engine_capacities'),
			'animal_car_motion_vectors'=>trans('admin.animal_car_motion_vectors'),
			'animal_car_payment_methods'=>trans('admin.animal_car_payment_methods'),
			'animal_car_fuel_types'=>trans('admin.animal_car_fuel_types'),
			'animal_car_color'=>trans('admin.animal_car_color'),
			'animal_car_body_types'=>trans('admin.animal_car_body_types'),
			'animal_car_connection_types'=>trans('admin.animal_car_connection_types'),
		];
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}