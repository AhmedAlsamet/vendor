<?php
namespace App\Http\Controllers\ValidationsApi\V1;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class DoctorsRequest extends FormRequest {

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
             'doctor_name'=>'required|string|max:50',
             'doctor_phone'=>'required|numeric',
             'doctor_address'=>'required|string',
             'doctor_email'=>'required|email',
             'doctor_job_details'=>'',
             'password'=>'required',
             'contry_id'=>'required',
             'fcm'=>'',
             'doctor_photo'=>'required|image',
		];
	}


	protected function onUpdate() {
		return [
             'doctor_name'=>'required|string|max:50',
             'doctor_phone'=>'required|numeric',
             'doctor_address'=>'required|string',
             'doctor_email'=>'required|email',
             'doctor_job_details'=>'',
             'password'=>'required',
             'contry_id'=>'required',
             'fcm'=>'',
             'doctor_photo'=>'required|image',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
             'doctor_name'=>trans('admin.doctor_name'),
             'doctor_phone'=>trans('admin.doctor_phone'),
             'doctor_address'=>trans('admin.doctor_address'),
             'doctor_email'=>trans('admin.doctor_email'),
             'doctor_job_details'=>trans('admin.doctor_job_details'),
             'password'=>trans('admin.password'),
             'contry_id'=>trans('admin.contry_id'),
             'fcm'=>trans('admin.fcm'),
             'doctor_photo'=>trans('admin.doctor_photo'),
		];
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}