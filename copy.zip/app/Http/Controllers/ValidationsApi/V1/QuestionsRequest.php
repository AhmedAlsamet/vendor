<?php
namespace App\Http\Controllers\ValidationsApi\V1;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class QuestionsRequest extends FormRequest {

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
             'question_name'=>'required',
             'question_answer1'=>'required',
             'question_answer2'=>'required',
             'question_answer3'=>'required',
             'question_answer4'=>'required',
             'question_correct_answer'=>'required',
		];
	}


	protected function onUpdate() {
		return [
             'question_name'=>'required',
             'question_answer1'=>'required',
             'question_answer2'=>'required',
             'question_answer3'=>'required',
             'question_answer4'=>'required',
             'question_correct_answer'=>'required',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
             'question_name'=>trans('admin.question_name'),
             'question_answer1'=>trans('admin.question_answer1'),
             'question_answer2'=>trans('admin.question_answer2'),
             'question_answer3'=>trans('admin.question_answer3'),
             'question_answer4'=>trans('admin.question_answer4'),
             'question_correct_answer'=>trans('admin.question_correct_answer'),
		];
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}