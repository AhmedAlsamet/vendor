<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class Settings extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:settings_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:settings_edit', [
			'only' => ['store'],
		]);

	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index() {
		return view('admin.settings', ['title' => trans('admin.settings')]);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request) {
		$rules = [
			'system_message' => '',
		];

		$data = $this->validate(request(), $rules, [], [
			'system_message' => trans('admin.system_message'),
		]);

		Setting::where('id', 1)->update($data);

		$data["system_message"] = $request["game_info"];
		Setting::where('id', 2)->update($data);

		session()->flash('success', trans('admin.updated'));
		return redirect(aurl('settings'));

	}

}
