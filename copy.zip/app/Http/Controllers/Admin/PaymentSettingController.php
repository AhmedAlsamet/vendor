<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentSetting;
use Illuminate\Support\Facades\Auth;

class PaymentSettingController extends Controller
{
    public function active_class(){
        $payment = PaymentSetting::first();
        if($payment == Null){
           $payment = new PaymentSetting;
           $payment->save();
        }

      return  view('admin.payment.active_class',[
            'title'=>trans('admin.edit'),
            'payment'=>$payment
        ]);
    }
    public function add_class(Request $request){

          $payment = PaymentSetting::first();
          if($request->apple_pay == Null){
            $payment->apple_pay = 0;

          }else{

              $payment->apple_pay = $request->apple_pay;
          }
          $payment->save();
          return redirect()->back()->with(trans('admin.updated'));

     }
   public function add_payment(){

      $payment = PaymentSetting::first();
      if($payment == Null){
         $payment = new PaymentSetting;
         $payment->save();
      }
      return  view('admin.payment.index',[
        'title'=>trans('admin.edit'),
        'payment'=>$payment
    ]);
   }
   public function store_payment(Request $request){
      $validatedData = $request->validate([
         'test_token' => 'required',
         'DisplayCurrencyIso' => 'required',


     ],
     [
         'test_token.required'=>'من فضلك قم باضافة التوكين',
         'DisplayCurrencyIso.required'=>'من فضلك قم باضافة العملة ',

     ]);
        $payment = PaymentSetting::first();
        $payment->test_token = $request->test_token;
        $payment->secret_key = $request->secret_key;
        $payment->DisplayCurrencyIso = $request->DisplayCurrencyIso;
        $payment->account_type = $request->account_type;
        $payment->live_token = $request->live_token;
        $payment->save();
        return redirect()->back();

   }
}
