<?php
namespace App\Http\Controllers\Admin;

use App\DataTables\PackageBorderDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\packageRequest;
use App\Models\Border;
use App\Models\Package;
use Illuminate\Http\Request;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [It V 1.5.0 | https://it.phpanonymous.com]
// Copyright Reserved  [It V 1.5.0 | https://it.phpanonymous.com]
class packageBorder extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:package_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:package_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:package_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:package_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Display a listing of the resource.
	 * @return \Illuminate\Http\Response
	 */
	public function index(PackageBorderDataTable $package) {
		return $package->render('admin.package.package_border.index', ['title' => trans('admin.package')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Show the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function create() {
        $borders = Border::all();
		return view('admin.package.package_border.create', ['title' => trans('admin.create'),'borders'=>$borders]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(packageRequest $request) {
		// $data = $request->except("_token", "_method");
        // $data['type_package'] = 1;
		// Package::create($data);
        $package = new Package();
        $package->type = 2;
        $package->title = $request->title;
        $package->price = $request->price;
        $package->type_package = $request->type_package;
        if($request->for_ever){
            $package->for_ever = 1;
            $package->days = 0;
        }else{
            $package->days = $request->days;
            $package->for_ever = 0;

        }
        $package->save();
		return redirectWithSuccess(aurl('packageBorder'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$package = Package::find($id);
        $borders = Border::all();
		return is_null($package) || empty($package) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.package.package_border.edit', [
			'title' => trans('admin.edit'),
			'package' => $package,
            'borders' => $borders,

		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function update(packageRequest $request, $id) {
		// Check Record Exists

		$package = Package::find($id);
		if (is_null($package) || empty($package)) {
			return backWithError(trans("admin.undefinedRecord"));
		}

        $package->title = $request->title;
        $package->price = $request->price;
        $package->type_package = $request->type_package;

        if($request->for_ever ){

            $package->for_ever = 1;
            $package->days = 0;
        }else{
            $package->days = $request->days;
            $package->for_ever = 0;

        }
        $package->save();
		// $data = $request->except("_token", "_method");

		// Package::where('id', $id)->update([
		// 	'title' => $data['title'],
        //     'days' => $data['days'],
		// 	'for_ever' => $data['for_ever'],

		// ]);



		return redirectWithSuccess(aurl('packageBorder'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$package = Package::find($id);
		if (is_null($package) || empty($package)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		$package->delete();
		return backWithSuccess(trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$package = Package::find($id);
				if (is_null($package) || empty($package)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				$package->delete();

			}
			return backWithSuccess(trans('admin.deleted'));
		} else {
			$package = Package::find($data);
			if (is_null($package) || empty($package)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			$package->delete();
			return backWithSuccess(trans('admin.deleted'));
		}
	}

}
