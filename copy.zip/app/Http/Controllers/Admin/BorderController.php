<?php
namespace App\Http\Controllers\Admin;

use App\DataTables\borderDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\borderRequest;
use App\Models\Border;
use Illuminate\Http\Request;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [It V 1.5.0 | https://it.phpanonymous.com]
// Copyright Reserved  [It V 1.5.0 | https://it.phpanonymous.com]
class BorderController extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:border_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:border_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:border_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:border_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Display a listing of the resource.
	 * @return \Illuminate\Http\Response
	 */
	public function index(BorderDataTable $border) {
		// dd(print_r($border));
		return $border->render('admin.border.index', ['title' => trans('admin.border')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Show the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function create() {
		return view('admin.border.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(borderRequest $request) {
		$data = $request->except("_token", "_method");
		$data["border_image"] = "";
		$border = Border::create($data);
		if(request()->hasFile("border_image")){
			$border->border_image = it()->upload("border_image","borders/".$border->id);
			$border->save();
		}
		return redirectWithSuccess(aurl('Border'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$border = Border::find($id);
		return is_null($border) || empty($border) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.border.edit', [
			'title' => trans('admin.edit'),
			'border' => $border,
			'hasImage' => $border->border_image == '' ? false : true
		]);
	}


	public function update(borderRequest $request, $id) {
		// Check Record Exists
		$border = Border::find($id);
		if (is_null($border) || empty($border)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		if(request()->hasFile("border_image") && $request['border_image'] != ""){
			it()->delete($border->border_image);
			$border->border_image = it()->upload("border_image","borders/".$border->id);
		}

		$data = $request->except("_token", "_method");

		Border::where('id', $id)->update([
			'color' => $data['color'],
            'title' => $data['title'],
            'title_lat' => $data['title_lat'],
            'price' => $data['price'],
            'type' => $data['type'],
			"border_image" =>$border->border_image,
		]);



		return redirectWithSuccess(aurl('Border'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$border = Border::find($id);
		if (is_null($border) || empty($border)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('borders',$id);
		$border->delete();
		return redirectWithSuccess(aurl("Border"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$border = Border::find($id);
				if (is_null($border) || empty($border)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('borders',$id);
				$border->delete();

			}
			return redirectWithSuccess(aurl("Border"),trans('admin.deleted'));
		} else {
			$border = Border::find($data);
			if (is_null($border) || empty($border)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('borders',$border->id);
			$border->delete();
			return redirectWithSuccess(aurl("Border"),trans('admin.deleted'));
		}
	}
}
