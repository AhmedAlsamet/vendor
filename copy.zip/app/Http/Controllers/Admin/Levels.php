<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\LevelDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\LevelRequest;
use App\Models\Level;
use Illuminate\Http\Request;

class Levels extends Controller
{
    public function __construct() {

		$this->middleware('AdminRole:levels_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:levels_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:levels_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:levels_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index(LevelDataTable $level) {
		// dd(print_r($level));
        // dd($level->ajax());
		return $level->render('admin.levels.index', ['title' => trans('admin.levels')]);
	}


	public function create() {
		return view('admin.levels.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(LevelRequest $request) {
		$data = $request->except("_token", "_method");
		$level = Level::create($data);
		return redirectWithSuccess(aurl('levels'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$level = Level::find($id);
		return is_null($level) || empty($level) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.levels.edit', [
			'title' => trans('admin.edit'),
			'level' => $level,
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function update(LevelRequest $request, $id) {
		// Check Record Exists
		$level = Level::find($id);
		if (is_null($level) || empty($level)) {
			return backWithError(trans("admin.undefinedRecord"));
		}

		$data = $request->except("_token", "_method");

		Level::where('id', $id)->update([
			'name' => $data['name'],
			'name_lat' => $data['name_lat'],
            'points' => $data['points']
		]);

		return redirectWithSuccess(aurl('levels'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$level = Level::find($id);
		if (is_null($level) || empty($level)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('levels',$id);
		$level->delete();
		return redirectWithSuccess(aurl("levels"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$level = Level::find($id);
				if (is_null($level) || empty($level)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('levels',$id);
				$level->delete();

			}
			return redirectWithSuccess(aurl("levels"),trans('admin.deleted'));
		} else {
			$level = Level::find($data);
			if (is_null($level) || empty($level)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('levels',$data);
			$level->delete();
			return redirectWithSuccess(aurl("levels"),trans('admin.deleted'));
		}
	}
}
