<?php
namespace App\Http\Controllers\Admin;

use App\DataTables\GoldWisdomArchivesDataTable;
use App\Http\Controllers\Controller;
use App\DataTables\PostsDataTable;
use App\DataTables\GoldWisdomsDataTable;
use App\DataTables\MonthGoldWishdomDataTable;
use Carbon\Carbon;
use App\Models\Post;
use App\Models\Winner;

use App\Models\TodayWisdom;
use Illuminate\Http\Request;


// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class gold_wisdoms extends Controller
{

	public function __construct() {



        $this->middleware('AdminRole:GoldWisdoms_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:GoldWisdoms_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:GoldWisdoms_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);


	}



            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function wisdom_application(){
                return view('admin.gold_wisdoms.wisdom_application', ['title' => 'الحكم الموفرة فى التطبيق']);

            }
            public function archives_gold_wisdom(GoldWisdomArchivesDataTable $wishdom){
                return $wishdom->render('admin.gold_wisdoms.wisdom_archives.index',['title'=>'حكم فى الارشيف']);

            }
            public function month_gold_wisdom(MonthGoldWishdomDataTable $wishdom){
                return $wishdom->render('admin.gold_wisdoms.month_gold_wisdom',['title'=>'حكم هذا الشهر']);

            }
            public function index(GoldWisdomsDataTable $wishdom)
            {
               return $wishdom->render('admin.gold_wisdoms.index',['title'=>trans('admin.GoldWisdoms')]);
            }
            public function create(){

                return view('admin.gold_wisdoms.create', ['title' => trans('admin.create')]);

            }
            public function store(Request $request)
            {
              // Check Record Exists
              $wishdom = new TodayWisdom();

              $wishdom->wisdoms = $request->wisdoms;
              $wishdom->type = 1;
              $wishdom->Save();
              $redirect = isset($request["add_back"])?"/create":"";

              return redirectWithSuccess(aurl('GoldWisdoms'.$redirect), trans('admin.added'));
            }

            public function show($id)
            {
        		$wishdom =  TodayWisdom::find($id);
        		return is_null($wishdom) || empty($wishdom)?
        		backWithError(trans("admin.undefinedRecord"),aurl("GoldWisdoms")) :
        		view('admin.gold_wisdoms.show',[
				    'title'=>trans('admin.show'),
					'wishdom'=>$wishdom
        		]);
            }

            public function goldWisdom_Transport($id){
                $section = TodayWisdom::findOrfail($id);
                $section->month_wisdom = 0;
                $section->save();
                $redirect = isset($request["add_back"])?"/create":"";

                return redirectWithSuccess(aurl('GoldWisdoms'.$redirect), 'تم النقل بنجاح');

           }

            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$wishdom =  TodayWisdom::find($id);
        		return is_null($wishdom) || empty($wishdom)?
        		backWithError(trans("admin.undefinedRecord"),aurl("GoldWisdoms")) :
        		view('admin.gold_wisdoms.edit',[
				  'title'=>trans('admin.edit'),
				  'wishdom'=>$wishdom
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */


            public function update(Request $request, $id)
            {
              // Check Record Exists
              $wishdom =  TodayWisdom::find($id);
              if(is_null($wishdom) || empty($wishdom)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("posts"));
              }
              $wishdom->wisdoms = $request->wisdoms;
              $wishdom->Save();
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              if($request->month == 1){
                return redirectWithSuccess(aurl('Month-GoldWisdom'.$redirect), trans('admin.updated'));

             }else{
                return redirectWithSuccess(aurl('GoldWisdoms'.$redirect), trans('admin.updated'));

             }
            }
            public function destroy($id) {
                $border = TodayWisdom::find($id);
                if (is_null($border) || empty($border)) {
                    return backWithError(trans('admin.undefinedRecord'));
                }
                // Delete Roles
                $border->delete();
                return backWithSuccess(trans('admin.deleted'));

            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */







}
