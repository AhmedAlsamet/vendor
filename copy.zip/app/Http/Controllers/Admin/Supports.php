<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\DataTables\ReadSupportsDataTable;
use App\DataTables\UnreadSupportsDataTable;
use Carbon\Carbon;
use App\Models\Support;

use App\Http\Controllers\Validations\SupportsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Supports extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:supports_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:supports_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:supports_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:supports_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	

            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function index(ReadSupportsDataTable $supports)
            {
               return $supports->render('admin.supports.index',['title'=>'المقروءة']);
            }
            public function unread(UnreadSupportsDataTable $supports)
            {
               return $supports->render('admin.supports.index',['title'=>"الغير مقروءة"]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * Show the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function create()
            {
            	
               return view('admin.supports.create',['title'=>trans('admin.create')]);
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * Store a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response Or Redirect
             */
            public function store(SupportsRequest $request)
            {
                $data = $request->except("_token", "_method");
            			  		$supports = Support::create($data); 
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('supports'.$redirect), trans('admin.added')); }

            /**
             * Display the specified resource.
             * Baboon Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
        		$supports =  Support::find($id);
        		return is_null($supports) || empty($supports)?
        		backWithError(trans("admin.undefinedRecord"),aurl("supports")) :
        		view('admin.supports.show',[
				    'title'=>trans('admin.show'),
					'supports'=>$supports
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$supports =  Support::find($id);
        		return is_null($supports) || empty($supports)?
        		backWithError(trans("admin.undefinedRecord"),aurl("supports")) :
        		view('admin.supports.edit',[
				  'title'=>trans('admin.edit'),
				  'supports'=>$supports
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new SupportsRequest)->attributes()) as $fillableUpdate) {
					if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					}
				}
				return $fillableCols;
			}

            public function update(SupportsRequest $request,$id)
            {
              // Check Record Exists
              $supports =  Support::find($id);
              if(is_null($supports) || empty($supports)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("supports"));
              }
              $data = $this->updateFillableColumns(); 
              Support::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('supports'.$redirect), trans('admin.updated'));
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */
	public function destroy($id){
		$supports = Support::find($id);
		if(is_null($supports) || empty($supports)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("supports"));
		}
               
		it()->delete('support',$id);
		$supports->delete();
		return redirectWithSuccess(aurl("supports"),trans('admin.deleted'));
	}

  public function readOrUnread($id) {
		// Check Record Exists
		$supports = Support::find($id);
		if (is_null($supports) || empty($supports)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		if($supports->state == 0){
			$data['state'] = 1;
      Support::where('id', $id)->update($data);
      return redirectWithSuccess(aurl('unread_supports'), trans('Admin.updated'));
		}
		else{
			$data['state'] = 0;
      Support::where('id', $id)->update($data);
      return redirectWithSuccess(aurl('supports'), trans('Admin.updated'));
		}
	}


	public function multi_readOrUnread(){
		$data = request('selected_data');
		if(is_array($data)){
      $isRead = false;
			foreach($data as $id){
				$supports = Support::find($id);
				if(is_null($supports) || empty($supports)){
					return backWithError(trans('admin.undefinedRecord'),aurl("supports"));
				}
                    	
        if($supports->state == 0){
          $data['state'] = 1;
          $supports->update($data);
          $isRead = true;
        }
        else{
          $data['state'] = 0;
          $supports->update($data);
          $isRead = false;
        }
			}
      if($isRead){
        return redirectWithSuccess(aurl('unread_supports'), trans('Admin.updated'));
      }else{
        return redirectWithSuccess(aurl('supports'), trans('Admin.updated'));
      }
		}else {
			$supports = Support::find($data);
			if(is_null($supports) || empty($supports)){
				return backWithError(trans('admin.undefinedRecord'),aurl("supports"));
			}
      if($supports->state == 0){
        $data['state'] = 1;
        $supports->update($data);
        return redirectWithSuccess(aurl('unread_supports'), trans('Admin.updated'));
      }
      else{
        $data['state'] = 0;
        $supports->update($data);
        return redirectWithSuccess(aurl('supports'), trans('Admin.updated'));
      }
		}
	}
            
	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$supports = Support::find($id);
				if(is_null($supports) || empty($supports)){
					return backWithError(trans('admin.undefinedRecord'),aurl("supports"));
				}
                    	
				it()->delete('support',$id);
				$supports->delete();
			}
			return redirectWithSuccess(aurl("supports"),trans('admin.deleted'));
		}else {
			$supports = Support::find($data);
			if(is_null($supports) || empty($supports)){
				return backWithError(trans('admin.undefinedRecord'),aurl("supports"));
			}
                    
			it()->delete('support',$data);
			$supports->delete();
			return redirectWithSuccess(aurl("supports"),trans('admin.deleted'));
		}
	}
            

}