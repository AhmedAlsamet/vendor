<?php
namespace App\Http\Controllers\Admin;

use App\DataTables\SocialDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\SocialRequest;
use App\Models\Social;
use Carbon\Carbon;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class SocialController extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:questions_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:questions_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:questions_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:questions_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function index(SocialDataTable $socials)
            {
               return $socials->render('admin.social.index',['title'=>trans('admin.social Medial')]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * Show the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function create()
            {

               return view('admin.social.create',['title'=>trans('admin.create')]);
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * Store a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response Or Redirect
             */
            public function store(SocialRequest $request)
            {
                $data = $request->except("_token", "_method");
            			  		$socials = Social::create($data);
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('Social'.$redirect), trans('admin.added')); }

            /**
             * Display the specified resource.
             * Baboon Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
        		$socials =  Social::find($id);
        		return is_null($socials) || empty($socials)?
        		backWithError(trans("admin.undefinedRecord"),aurl("Social")) :
        		view('admin.social.show',[
				    'title'=>trans('admin.show'),
					'socials'=>$socials
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$socials =  Social::find($id);
        		return is_null($socials) || empty($socials)?
        		backWithError(trans("admin.undefinedRecord"),aurl("Social")) :
        		view('admin.social.edit',[
				  'title'=>trans('admin.edit'),
				  'socials'=>$socials
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new SocialRequest)->attributes()) as $fillableUpdate) {
					if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					}
				}
				return $fillableCols;
			}

            public function update(SocialRequest $request,$id)
            {
              // Check Record Exists
              $socials =  Social::find($id);
              if(is_null($socials) || empty($socials)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("Social"));
              }
              $data = $this->updateFillableColumns();
              Social::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('Social'.$redirect), trans('admin.updated'));
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */
	public function destroy($id){
		$socials = Social::find($id);
		if(is_null($socials) || empty($socials)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("Social"));
		}

		it()->delete('socials',$id);
		$socials->delete();
		return redirectWithSuccess(aurl("Social"),trans('admin.deleted'));
	}


	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$socials = Social::find($id);
				if(is_null($socials) || empty($socials)){
					return backWithError(trans('admin.undefinedRecord'),aurl("Social"));
				}

				it()->delete('socials',$id);
				$socials->delete();
			}
			return redirectWithSuccess(aurl("Social"),trans('admin.deleted'));
		}else {
			$socials = Social::find($data);
			if(is_null($socials) || empty($socials)){
				return backWithError(trans('admin.undefinedRecord'),aurl("Social"));
			}

			it()->delete('socials',$data);
			$socials->delete();
			return redirectWithSuccess(aurl("Social"),trans('admin.deleted'));
		}
	}


}
