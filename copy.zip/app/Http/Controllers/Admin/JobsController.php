<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\JobsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\JobsRequest;
use App\Models\Job;
use Illuminate\Http\Request;

class JobsController extends Controller
{
    public function __construct()
    {
        $this->middleware('AdminRole:jobs_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:jobs_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:jobs_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:jobs_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     * Baboon Script By [it v 1.6.33]
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(JobsDataTable $questions)
    {
        return $questions->render('admin.jobs.index', ['title' => trans('admin.jobs')]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.jobs.create', ['title' => trans('admin.create')]);
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(JobsRequest $request)
    {
        $data = $request->except("_token", "_method");
        $questions = Job::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl("jobs" . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     * Baboon Script By [it v 1.6.33]
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $jobs =  Job::find($id);
        return is_null($jobs) || empty($jobs) ?
            backWithError(trans("admin.undefinedRecord"), aurl("jobs")) :
            view('admin.jobs.show', [
                'title' => trans('admin.show'),
                'jobs' => $jobs
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $jobs =  Job::find($id);
        return is_null($jobs) || empty($jobs) ?
            backWithError(trans("admin.undefinedRecord"), aurl("jobs")) :
            view('admin.jobs.edit', [
                'title' => trans('admin.edit'),
                'jobs' => $jobs
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new JobsRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(JobsRequest $request, $id)
    {
        // Check Record Exists
        $questions =  Job::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("jobs"));
        }
        $data = $this->updateFillableColumns();
        Job::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl('jobs' . $redirect), trans('admin.updated'));
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $questions = Job::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("jobs"));
        }

        it()->delete('job', $id);
        $questions->delete();
        return redirectWithSuccess(aurl("jobs"), trans('admin.deleted'));
    }


    public function multi_delete()
    {
        $data = request('selected_data');
        if (is_array($data)) {
            foreach ($data as $id) {
                $questions = Job::find($id);
                if (is_null($questions) || empty($questions)) {
                    return backWithError(trans('admin.undefinedRecord'), aurl("jobs"));
                }

                it()->delete('job', $id);
                $questions->delete();
            }
            return redirectWithSuccess(aurl("jobs"), trans('admin.deleted'));
        } else {
            $questions = Job::find($data);
            if (is_null($questions) || empty($questions)) {
                return backWithError(trans('admin.undefinedRecord'), aurl("jobs"));
            }

            it()->delete('job', $data);
            $questions->delete();
            return redirectWithSuccess(aurl("jobs"), trans('admin.deleted'));
        }
    }
}
