<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\ColorDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\ColorRequest;
use App\Models\Colors;

class ColorsController extends Controller
{
    public function __construct() {

		$this->middleware('AdminRole:colors_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:colors_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:colors_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:colors_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index(ColorDataTable $color) {
		// dd(print_r($color));
		return $color->render('admin.colors.index', ['title' => trans('admin.colors')]);
	}


	public function create() {
		return view('admin.colors.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(ColorRequest $request) {
		$data = $request->except("_token", "_method");
		$data["photo"] = "";
		$color = Colors::create($data);
		if(request()->hasFile("photo")){
			$color->photo = it()->upload("photo","colors/".$color->id);
			$color->save();
		}
		return redirectWithSuccess(aurl('colors'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$color = Colors::find($id);
		return is_null($color) || empty($color) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.colors.edit', [
			'title' => trans('admin.edit'),
			'color' => $color,
			'hasImage' => $color->photo == '' ? 0 : 1
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function update(ColorRequest $request, $id) {
		// Check Record Exists
		$color = Colors::find($id);
		if (is_null($color) || empty($color)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		if(request()->hasFile("photo") && $request['photo'] != ""){
			it()->delete($color->photo);
			$color->photo = it()->upload("photo","colors/".$color->id);
		}

		$data = $request->except("_token", "_method");

		Colors::where('id', $id)->update([
			'name' => $data['name'],
			'name_lat' => $data['name_lat'],
            'price' => $data['price'],
			"photo" =>$color->photo,
			"color" =>$data['color'],
		]);



		return redirectWithSuccess(aurl('colors'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$color = Colors::find($id);
		if (is_null($color) || empty($color)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('colors',$id);
		$color->delete();
		return redirectWithSuccess(aurl("colors"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$color = Colors::find($id);
				if (is_null($color) || empty($color)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('colors',$id);
				$color->delete();

			}
			return redirectWithSuccess(aurl("colors"),trans('admin.deleted'));
		} else {
			$color = Colors::find($data);
			if (is_null($color) || empty($color)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('colors',$data);
			$color->delete();
			return redirectWithSuccess(aurl("colors"),trans('admin.deleted'));
		}
	}
}
