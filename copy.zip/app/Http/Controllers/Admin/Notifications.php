<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\DataTables\NotificationsDataTable;
use Carbon\Carbon;
use App\Models\Notification;
use App\Models\Post;
use App\Models\Winner;
use App\FcmNotification;
use App\Http\Controllers\Validations\NotificationsRequest;
use App\Models\User;

class Notifications extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:notifications_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:notifications_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:notifications_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:notifications_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	
            public function index(NotificationsDataTable $notifications)
            {
               return $notifications->render('admin.notifications.index',['title'=>trans('admin.notifications')]);
            }


            public function create()
            {
            	
               return view('admin.notifications.create',['title'=>trans('admin.create')]);
            }


            public function store(NotificationsRequest $request)
            {
                $data = $request->except("_token", "_method");
    // if ($data['Notification_resever'] == "post") {
    //   $tokens = Post::join('users', 'users.id', '=', 'posts.user_id')
    //   ->pluck('fcm_token')->all();
    //   $title = $data['Notification_title'];
    //   $body  = $data['Notification_body'];
    //   $notfiy = FcmNotification::sendNotification($tokens, $title ,$body);
    // } else {
    //   $tokens = Winner::join('users', 'users.id', '=', 'winners.user_id')
    //   ->pluck('fcm_token')->all();
    //   $title = $data['Notification_title'];
    //   $body  = $data['Notification_body'];
    //   $notfiy = FcmNotification::sendNotification($tokens, $title ,$body);
    // }
    $token = "";
    if ($data['Notification_for'] == null) {
      $data['Notification_for'] = 0;
      // $token = User::all()->pluck('fcm_token')->toArray();
    }
    else{
      $token = User::all()->where("id",$data['Notification_for'])->pluck('fcm_token')[0];
    }
    
    $title = $data['Notification_title'];
    $body  = $data['Notification_body'];
    $data['Notification_title_lat'] = $data['Notification_title_lat'] ?? $data['Notification_title']; 
    $data['Notification_body_lat'] = $data['Notification_body_lat'] ?? $data['Notification_body']; 
    // if(count($tokens) > 500){
    //   $temp = [];
    //   for ( $i = 0; $i < count($tokens); $i+=500) {
    //     $end = $i+500;
    //     if($end > count($tokens))
    //     $end = count($tokens);
    //     array_push($temp ,array_slice($tokens,0,$end));
    //   }
    //   for ($i = 0; $i < count($temp); $i++) {
    //     FcmNotification::sendNotification($title, $body,$temp[$i]);
    //   }
    // }
    // else{
    // }
    FcmNotification::sendNotification($title, $body,$token);


                $notifications = Notification::create($data); 
                // Post Winner
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('notifications'.$redirect), trans('admin.added')); 
            }

            /**
             * Display the specified resource.
             * Baboon Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
        		$notifications =  Notification::find($id);
        		return is_null($notifications) || empty($notifications)?
        		backWithError(trans("admin.undefinedRecord"),aurl("notifications")) :
        		view('admin.notifications.show',[
				    'title'=>trans('admin.show'),
					'notifications'=>$notifications
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$notifications =  Notification::find($id);
        		return is_null($notifications) || empty($notifications)?
        		backWithError(trans("admin.undefinedRecord"),aurl("notifications")) :
        		view('admin.notifications.edit',[
				  'title'=>trans('admin.edit'),
				  'notifications'=>$notifications
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new NotificationsRequest)->attributes()) as $fillableUpdate) {
					// if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					// }
				}
				return $fillableCols;
			}

            public function update(NotificationsRequest $request,$id)
            {
              // Check Record Exists
              $notifications =  Notification::find($id);
              if(is_null($notifications) || empty($notifications)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("notifications"));
              }
              $data = $this->updateFillableColumns(); 
              $data['Notification_title_lat'] = $data['Notification_title_lat'] ?? $data['Notification_title']; 
              $data['Notification_body_lat'] = $data['Notification_body_lat'] ?? $data['Notification_body'];
              if ($data['Notification_for'] == null) {
                $data['Notification_for'] = 0;
              }
              Notification::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('notifications'.$redirect), trans('admin.updated'));
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */
	public function destroy($id){
		$notifications = Notification::find($id);
		if(is_null($notifications) || empty($notifications)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("notifications"));
		}
               
		it()->delete('notification',$id);
		$notifications->delete();
		return redirectWithSuccess(aurl("notifications"),trans('admin.deleted'));
	}


	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$notifications = Notification::find($id);
				if(is_null($notifications) || empty($notifications)){
					return backWithError(trans('admin.undefinedRecord'),aurl("notifications"));
				}
                    	
				it()->delete('notification',$id);
				$notifications->delete();
			}
			return redirectWithSuccess(aurl("notifications"),trans('admin.deleted'));
		}else {
			$notifications = Notification::find($data);
			if(is_null($notifications) || empty($notifications)){
				return backWithError(trans('admin.undefinedRecord'),aurl("notifications"));
			}
                    
			it()->delete('notification',$data);
			$notifications->delete();
			return redirectWithSuccess(aurl("notifications"),trans('admin.deleted'));
		}
	}
            

}