<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\DataTables\PostsDataTable;
use Carbon\Carbon;
use App\Models\Post;
use App\Models\Winner;

use App\Http\Controllers\Validations\PostsRequest;
use App\Models\PostDetails;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Posts extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:posts_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:posts_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:posts_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:posts_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}



            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function index(PostsDataTable $posts)
            {
               return $posts->render('admin.posts.index',['title'=>trans('admin.posts')]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * Show the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function create()
            {

               return view('admin.posts.create',['title'=>trans('admin.create')]);
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * Store a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response Or Redirect
             */
            public function store(PostsRequest $request)
            {
                $data = $request->except("_token", "_method");
            			  		$posts = Post::create($data);
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('posts'.$redirect), trans('admin.added')); }

            /**
             * Display the specified resource.
             * Baboon Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
        		$posts =  Post::find($id);
        		return is_null($posts) || empty($posts)?
        		backWithError(trans("admin.undefinedRecord"),aurl("posts")) :
        		view('admin.posts.show',[
                    'posts_details'=>PostDetails::where('post_id',$posts->id)->get(),
				    'title'=>trans('admin.show'),
					'posts'=>$posts
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$posts =  Post::find($id);
        		return is_null($posts) || empty($posts)?
        		backWithError(trans("admin.undefinedRecord"),aurl("posts")) :
        		view('admin.posts.edit',[
				  'title'=>trans('admin.edit'),
				  'posts'=>$posts
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new PostsRequest)->attributes()) as $fillableUpdate) {
					if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					}
				}
				return $fillableCols;
			}

            public function update(PostsRequest $request,$id)
            {
              // Check Record Exists
              $posts =  Post::find($id);
              if(is_null($posts) || empty($posts)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("posts"));
              }
              $data = $this->updateFillableColumns();
              Post::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('posts'.$redirect), trans('admin.updated'));
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */
	public function destroy($id){
		$posts = Post::find($id);
		if(is_null($posts) || empty($posts)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("posts"));
		}

		it()->delete('post',$id);
		$posts->delete();
		return redirectWithSuccess(aurl("posts"),trans('admin.deleted'));
	}




  public function convent_winners(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$posts = Post::find($id);
				if(is_null($posts) || empty($posts)){
					return backWithError(trans('admin.undefinedRecord'),aurl("posts"));
				} else {

          $winner = new Winner();
          $winner->user_id = $posts->user_id;
        //   $winner->qestion_id = $posts->qestion_id;
          $winner->compitetion_id = $posts->compitetion_id;
          $winner->time = $posts->time;
          $winner->mark = $posts->mark;
          $winner->save();
          $posts->delete();
        }

			}
			return redirectWithSuccess(aurl("posts"),trans('admin.deleted'));
		}
	}
	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$posts = Post::find($id);
				if(is_null($posts) || empty($posts)){
					return backWithError(trans('admin.undefinedRecord'),aurl("posts"));
				}

				it()->delete('post',$id);
				$posts->delete();
			}
			return redirectWithSuccess(aurl("posts"),trans('admin.deleted'));
		}else {
			$posts = Post::find($data);
			if(is_null($posts) || empty($posts)){
				return backWithError(trans('admin.undefinedRecord'),aurl("posts"));
			}

			it()->delete('post',$data);
			$posts->delete();
			return redirectWithSuccess(aurl("posts"),trans('admin.deleted'));
		}
	}


}
