<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\FontDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\FontRequest;
use App\Models\Font;
use Illuminate\Http\Request;

class FontsController extends Controller
{
    public function __construct() {

		$this->middleware('AdminRole:font_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:font_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:font_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:font_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index(FontDataTable $font) {
		// dd(print_r($font));
		return $font->render('admin.fonts.index', ['title' => trans('admin.fonts')]);
	}


	public function create() {
		return view('admin.fonts.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(FontRequest $request) {
		$data = $request->except("_token", "_method");
		$font = Font::create($data);
		return redirectWithSuccess(aurl('fonts'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$font = Font::find($id);
		return is_null($font) || empty($font) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.fonts.edit', [
			'title' => trans('admin.edit'),
			'font' => $font,
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function update(FontRequest $request, $id) {
		// Check Record Exists
		$font = Font::find($id);
		if (is_null($font) || empty($font)) {
			return backWithError(trans("admin.undefinedRecord"));
		}

		$data = $request->except("_token", "_method");

		Font::where('id', $id)->update([
			'name' => $data['name'],
			'name_lat' => $data['name_lat'],
            'price' => $data['price'],
			"photo" =>$data['photo'],
			"link"=>$data['link'],
		]);



		return redirectWithSuccess(aurl('fonts'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$font = Font::find($id);
		if (is_null($font) || empty($font)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('fonts',$id);
		$font->delete();
		return redirectWithSuccess(aurl("fonts"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$font = Font::find($id);
				if (is_null($font) || empty($font)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('fonts',$id);
				$font->delete();

			}
			return redirectWithSuccess(aurl("fonts"),trans('admin.deleted'));
		} else {
			$font = Font::find($data);
			if (is_null($font) || empty($font)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('fonts',$data);
			$font->delete();
			return redirectWithSuccess(aurl("fonts"),trans('admin.deleted'));
		}
	}
}
