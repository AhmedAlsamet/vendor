<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\OurPartnerDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\OurPartnerRequest;
use App\Models\OurPartner;
use Illuminate\Http\Request;

class OurPartners extends Controller
{
    public function __construct() {

		$this->middleware('AdminRole:ourPartners_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:ourPartners_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:ourPartners_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:ourPartners_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index(OurPartnerDataTable $ourPartner) {
		// dd(print_r($ourPartner));
		return $ourPartner->render('admin.our_partners.index', ['title' => trans('admin.our_partners')]);
	}


	public function create() {
		return view('admin.our_partners.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */



     public function store(OurPartnerRequest $request) {
		$data = $request->except("_token", "_method");
		$data["logo"] = "";
		$ourPartner = OurPartner::create($data);
		if(request()->hasFile("logo")){
			$ourPartner->logo = it()->upload("logo","our_partner_logos/".$ourPartner->id);
			$ourPartner->save();
		}
		return redirectWithSuccess(aurl('our_partners'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$ourPartner = OurPartner::find($id);
		return is_null($ourPartner) || empty($ourPartner) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.our_partners.edit', [
			'title' => trans('admin.edit'),
			'ourPartner' => $ourPartner,
			'hasImage' => $ourPartner->logo == '' ? false : true
		]);
	}


	public function update(OurPartnerRequest $request, $id) {
		// Check Record Exists
		$ourPartner = OurPartner::find($id);
		if (is_null($ourPartner) || empty($ourPartner)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		if(request()->hasFile("logo") && $request['logo'] != ""){
			it()->delete($ourPartner->logo);
			$ourPartner->logo = it()->upload("logo","our_partner_logos/".$ourPartner->id);
		}

		$data = $request->except("_token", "_method");

		OurPartner::where('id', $id)->update([
            'name' => $data['name'],
            'name_lat' => $data['name_lat'],
            'url' => $data['url'],
			"logo" =>$ourPartner->logo,
		]);



		return redirectWithSuccess(aurl('our_partners'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$ourPartner = OurPartner::find($id);
		if (is_null($ourPartner) || empty($ourPartner)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('our_partners',$id);
		$ourPartner->delete();
		return redirectWithSuccess(aurl("our_partners"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$ourPartner = OurPartner::find($id);
				if (is_null($ourPartner) || empty($ourPartner)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('our_partners',$id);
				$ourPartner->delete();

			}
			return redirectWithSuccess(aurl("our_partners"),trans('admin.deleted'));
		} else {
			$ourPartner = OurPartner::find($data);
			if (is_null($ourPartner) || empty($ourPartner)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('our_partners',$ourPartner->id);
			$ourPartner->delete();
			return redirectWithSuccess(aurl("our_partners"),trans('admin.deleted'));
		}
	}
}
