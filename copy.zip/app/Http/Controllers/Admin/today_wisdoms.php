<?php
namespace App\Http\Controllers\Admin;

use App\DataTables\MonthTodayWishdomDataTable;
use App\Http\Controllers\Controller;
use App\DataTables\PostsDataTable;
use App\DataTables\TodayWisdomArchivesDataTable;
use App\DataTables\TodayWisdomsDataTable;
use App\Http\Controllers\Validations\WisdomRequest;
use Carbon\Carbon;
use App\Models\Post;
use App\Models\Winner;

use App\Models\TodayWisdom;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Calculation\TextData\Format;
use PhpOffice\PhpSpreadsheet\Worksheet\Validations;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class today_wisdoms extends Controller
{

	public function __construct() {


		$this->middleware('AdminRole:TodayWisdoms_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:TodayWisdoms_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:TodayWisdoms_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);


	}



            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function archives_today_wisdom(TodayWisdomArchivesDataTable $wishdom){
                return $wishdom->render('admin.wishdom.wisdom_archives.index',['title'=>'حكم فى الارشيف']);

            }
            public function month_today_wisdom(MonthTodayWishdomDataTable $wishdom){
                return $wishdom->render('admin.wishdom.month_today_wisdom',['title'=>'حكم هذا الشهر']);

            }
            public function index(TodayWisdomsDataTable $wishdom)
            {
               return $wishdom->render('admin.wishdom.index',['title'=>"جميع الأحاديث والحكم"]);
            }
            public function create(){

              return view('admin.wishdom.create', ['title' => trans('admin.create')]);

            }

            public function store(WisdomRequest $request){
                
                $wishdom =  new TodayWisdom;
                $wishdom->wisdoms = $request->wisdoms;
                $wishdom->wisdoms_lat = $request->wisdoms_lat;
                $wishdom->month_wisdom = TodayWisdom::query()->min("month_wisdom");
                $wishdom->day = TodayWisdom::query()->max("day");
                $wishdom->Save();
                $redirect = isset($request["add_back"])?"/create":"";

                return redirectWithSuccess(aurl('TodayWisdom'.$redirect), trans('admin.added'));

            }

            public function show($id)
            {
        		$wishdom =  TodayWisdom::find($id);
        		return is_null($wishdom) || empty($wishdom)?
        		backWithError(trans("admin.undefinedRecord"),aurl("TodayWisdom")) :
        		view('admin.wishdom.show',[
				    'title'=>trans('admin.show'),
					'wishdom'=>$wishdom
        		]);
            }

           public function TodayWisdom_Transport($id){
                $section = TodayWisdom::findOrfail($id);
                $section->month_wisdom = 0;
                $section->save();
                $redirect = isset($request["add_back"])?"/create":"";

                return redirectWithSuccess(aurl('TodayWisdom'.$redirect), 'تم النقل بنجاح');

           }
           public function multi_TodayWisdom_Transport() {
            $data = request('selected_data');

            if (is_array($data)) {
                foreach ($data as $id) {
                    $section = TodayWisdom::find($id);
                    if (is_null($section) || empty($section)) {
                        return backWithError(trans('admin.undefinedRecord'));
                    }
                    // Delete Roles
                    $section->month_wisdom = 0;
                    $section->save();
                }
                return backWithSuccess('تم النقل بنجاح');
            } else {
                $section = TodayWisdom::find($data);
                if (is_null($section) || empty($section)) {
                    return backWithError(trans('admin.undefinedRecord'));
                }
                // Delete Roles
                $section->month_wisdom = 0;
                $section->save();
                return backWithSuccess('تم النقل بنجاح');
            }
        }
            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit(Request $request, $id)
            {

        		$wishdom =  TodayWisdom::find($id);
                $month = $request->month;
        		return is_null($wishdom) || empty($wishdom)?
        		backWithError(trans("admin.undefinedRecord"),aurl("TodayWisdom")) :
        		view('admin.wishdom.edit',[
				  'title'=>trans('admin.edit'),
				  'wishdom'=>$wishdom,
                  'month'=>$month,
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */


            public function update(Request $request, $id)
            {
              // Check Record Exists
              $wishdom =  TodayWisdom::find($id);
              if(is_null($wishdom) || empty($wishdom)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("TodayWisdom"));
              }
              $wishdom->wisdoms = $request->wisdoms;
              $wishdom->wisdoms_lat = $request->wisdoms_lat;
              $wishdom->type = $request->type;
              $wishdom->Save();
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
             if($request->month == 1){
                return redirectWithSuccess(aurl('Month-TodayWisdom'.$redirect), trans('admin.updated'));

             }else{
                return redirectWithSuccess(aurl('TodayWisdom'.$redirect), trans('admin.updated'));

             }
            }
            public function destroy($id) {
                $border = TodayWisdom::find($id);
                if (is_null($border) || empty($border)) {
                    return backWithError(trans('admin.undefinedRecord'));
                }
                // Delete Roles
                $border->delete();
                return backWithSuccess(trans('admin.deleted'));

            }
            public function export_todayWisdom(Request $request){
                $startDate = Carbon::now(); //returns current day
                $firstDay = $startDate->firstOfMonth()->format('Y-m-d');
                $days = $startDate->lastOfMonth()->Format('d');
            
                // $sections_found = TodayWisdom::where('month_wisdom',1)->where('type',$request->type)->get();
                // foreach ($sections_found as  $value) {
                //    $value->month_wisdom = 0;
                //    $value->save();
                // }
                // dd('om');
                $sections_found = TodayWisdom::where('month_wisdom',1)->where('type',$request->type)->count();


                if($sections_found > $days){
                    if ($request->type  == 0) {
                        return backWithError('تم اضافة حكم بالفعل فى هذا الشهر', aurl("TodayWisdom"));
                    }else{
                        return backWithError('تم اضافة حكم بالفعل فى هذا الشهر', aurl("GoldWisdoms"));

                    }
                }

               $sections = TodayWisdom::where('month_wisdom',0)->where('type',$request->type)->take($days)->get();
               if($days == count($sections)){
                    foreach($sections as $i=>$section){

                        if ($i == 0) {
                            $day = date('Y-m-d', strtotime($firstDay));
                       }else{

                           $day = date('Y-m-d', strtotime($firstDay .'+'.$i.' day'));

                       }

                        $section->month_wisdom = 1;
                        $section->start_at = $day;
                        $section->day = date('d', strtotime($day));
                        $section->save();
                    }

                    $redirect = isset($request["add_back"])?"/create":"";
                    if($request->type  == 0){
                        return redirectWithSuccess(aurl('TodayWisdom'.$redirect), trans('تم نقل الحكم بنجاح'));
                    }else{
                        return redirectWithSuccess(aurl('GoldWisdoms'.$redirect), trans('تم نقل الحكم بنجاح'));

                    }


               }else{
                return backWithError('عدد الحكم اقل من عدد ايام الشهر يجب ان يكون الحكم يساوى عدد حكم الشهر',aurl("TodayWisdom"));
               }
            }

            public function new_Wisdom(){
                return view('admin.wishdom.new_Wisdom', ['title' => 'الحكم الجدبدة']);

            }

            public function old_Wisdom(){
                return view('admin.wishdom.old_Wisdom', ['title' => 'الحكم السابقة']);

            }
            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */







}
