<?php
namespace App\Http\Controllers\Admin;
use App\DataTables\UsersDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\UsersRequest;
use App\Models\User;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [It V 1.5.0 | https://it.phpanonymous.com]
// Copyright Reserved  [It V 1.5.0 | https://it.phpanonymous.com]
class Users extends Controller {

	// public function __construct() {

	// 	$this->middleware('UserRole:Users_show', [
	// 		'only' => ['index', 'show'],
	// 	]);
	// 	$this->middleware('UserRole:Users_add', [
	// 		'only' => ['create', 'store'],
	// 	]);
	// 	$this->middleware('UserRole:Users_edit', [
	// 		'only' => ['edit', 'update'],
	// 	]);
	// 	$this->middleware('UserRole:Users_delete', [
	// 		'only' => ['destroy', 'multi_delete'],
	// 	]);
	// }


	public function index(UsersDataTable $Users) {
		return $Users->render('admin.users.index', ['title' => trans('admin.users')]);
	}


	public function create() {
		return view('admin.users.create', ['title' => trans('admin.create')]);
	}


	public function store(UsersRequest $request) {
		$data = $request->except("_token", "_method");
		if (request()->hasFile('photo_profile')) {
			$data['photo_profile'] = it()->upload('photo_profile', 'Users');
		} else {
			$data['photo_profile'] = "";
		}

		$data['password'] = bcrypt(request('password'));

		User::create($data);
		return redirectWithSuccess(aurl('users'), trans('Admin.added'));
	}


	public function show($id) {
		$Users = User::find($id);
		return is_null($Users) || empty($Users) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.users.show', [
			'title' => trans('Admin.show'),
			'users' => $Users,
		]);
		
		//the problem here is that the blade is waiting for the user as lowercase but the controller is sending with Upper 'U'
	}


	public function edit($id) {
		$users = User::find($id);
		return is_null($users) || empty($users) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.users.edit', [
			'title' => trans('Admin.edit'),
			'users' => $users,
		]);
	}


	public function updateFillableColumns() {
		$fillableCols = [];
		foreach (array_keys((new UsersRequest)->attributes()) as $fillableUpdate) {
			if (!is_null(request($fillableUpdate))) {
				$fillableCols[$fillableUpdate] = request($fillableUpdate);
			}
		}
		return $fillableCols;
	}

	public function update(UsersRequest $request, $id) {
		// Check Record Exists
		$Users = User::find($id);
		if (is_null($Users) || empty($Users)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		$data = $this->updateFillableColumns();
		if (!empty(request('password'))) {
			$data['password'] = bcrypt(request('password'));
		}

		if (request()->hasFile('photo_profile')) {
			it()->delete($Users->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'Users');
		}
		User::where('id', $id)->update($data);
		return redirectWithSuccess(aurl('users'), trans('Admin.updated'));
	}
	public function blockOrInblock($id) {
		// Check Record Exists
		$users = User::find($id);
		if (is_null($users) || empty($users)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		if($users->is_blocked == 0){
			$data['is_blocked'] = 1;
		}
		else{
			$data['is_blocked'] = 0;
		}

		User::where('id', $id)->update($data);
		return redirectWithSuccess(aurl('users'), trans('Admin.updated'));
	}


	public function destroy($id) {
		$Users = User::find($id);
		if (is_null($Users) || empty($Users)) {
			return backWithError(trans('Admins.undefinedRecord'));
		}
		if (!empty($Users->photo_profile)) {
			it()->delete($Users->photo_profile);
		}

		$Users->delete();
		return backWithSuccess(trans('Admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$Users = User::find($id);
				if (is_null($Users) || empty($Users)) {
					return backWithError(trans('Admin.undefinedRecord'));
				}
				if (!empty($Users->photo_profile)) {
					it()->delete($Users->photo_profile);
				}

				$Users->delete();

			}
			return backWithSuccess(trans('Admin.deleted'));
		} else {
			$Users = User::find($data);
			if (is_null($Users) || empty($Users)) {
				return backWithError(trans('Admin.undefinedRecord'));
			}

			if (!empty($Users->photo_profile)) {
				it()->delete($Users->photo_profile);
			}

			$Users->delete();
			return backWithSuccess(trans('admin.deleted'));
		}
	}

}