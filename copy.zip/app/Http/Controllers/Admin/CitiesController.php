<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\CitiesDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\CitiesRequest;
use App\Models\City;

class CitiesController extends Controller
{

    public function __construct()
    {
        $this->middleware('AdminRole:cities_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:cities_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:cities_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:cities_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     * Baboon Script By [it v 1.6.33]
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(CitiesDataTable $questions)
    {
        return $questions->render('admin.cities.index', ['title' => trans('admin.city')]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.cities.create', ['title' => trans('admin.create')]);
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(CitiesRequest $request)
    {
        $data = $request->except("_token", "_method");
        $questions = City::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl("cities" . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     * Baboon Script By [it v 1.6.33]
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cities =  City::find($id);
        return is_null($cities) || empty($cities) ?
            backWithError(trans("admin.undefinedRecord"), aurl("cities")) :
            view('admin.cities.show', [
                'title' => trans('admin.show'),
                'cities' => $cities
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cities =  City::find($id);
        return is_null($cities) || empty($cities) ?
            backWithError(trans("admin.undefinedRecord"), aurl("cities")) :
            view('admin.cities.edit', [
                'title' => trans('admin.edit'),
                'cities' => $cities
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new CitiesRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(CitiesRequest $request, $id)
    {
        // Check Record Exists
        $questions =  City::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("cities"));
        }
        $data = $this->updateFillableColumns();
        City::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl('cities' . $redirect), trans('admin.updated'));
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $questions = City::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("cities"));
        }

        it()->delete('city', $id);
        $questions->delete();
        return redirectWithSuccess(aurl("cities"), trans('admin.deleted'));
    }


    public function multi_delete()
    {
        $data = request('selected_data');
        if (is_array($data)) {
            foreach ($data as $id) {
                $questions = City::find($id);
                if (is_null($questions) || empty($questions)) {
                    return backWithError(trans('admin.undefinedRecord'), aurl("cities"));
                }

                it()->delete('city', $id);
                $questions->delete();
            }
            return redirectWithSuccess(aurl("cities"), trans('admin.deleted'));
        } else {
            $questions = City::find($data);
            if (is_null($questions) || empty($questions)) {
                return backWithError(trans('admin.undefinedRecord'), aurl("cities"));
            }

            it()->delete('city', $data);
            $questions->delete();
            return redirectWithSuccess(aurl("cities"), trans('admin.deleted'));
        }
    }
}
