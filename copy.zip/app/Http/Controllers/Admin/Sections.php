<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\DataTables\SectionsDataTable;
use Carbon\Carbon;
use App\Models\Section;

use App\Http\Controllers\Validations\SectionsRequest;

class Sections extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:sections_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:sections_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:sections_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:sections_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	
            public function index(SectionsDataTable $sections)
            {
               return $sections->render('admin.sections.index',['title'=>trans('admin.sections')]);
            }


            public function create()
            {
            	
               return view('admin.sections.create',['title'=>trans('admin.create')]);
            }


            public function store(SectionsRequest $request)
            {
                $data = $request->except("_token", "_method");
            			  		$sections = Section::create($data); 
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('sections'.$redirect), trans('admin.added')); }


            public function show($id)
            {
        		$sections =  Section::find($id);
        		return is_null($sections) || empty($sections)?
        		backWithError(trans("admin.undefinedRecord"),aurl("sections")) :
        		view('admin.sections.show',[
				    'title'=>trans('admin.show'),
					'sections'=>$sections
        		]);
            }


            public function edit($id)
            {
        		$sections =  Section::find($id);
        		return is_null($sections) || empty($sections)?
        		backWithError(trans("admin.undefinedRecord"),aurl("sections")) :
        		view('admin.sections.edit',[
				  'title'=>trans('admin.edit'),
				  'sections'=>$sections
        		]);
            }



            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new SectionsRequest)->attributes()) as $fillableUpdate) {
					if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					}
				}
				return $fillableCols;
			}

            public function update(SectionsRequest $request,$id)
            {
              // Check Record Exists
              $sections =  Section::find($id);
              if(is_null($sections) || empty($sections)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("sections"));
              }
              $data = $this->updateFillableColumns(); 
              Section::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('sections'.$redirect), trans('admin.updated'));
            }

	public function destroy($id){
		$sections = Section::find($id);
		if(is_null($sections) || empty($sections)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("sections"));
		}
               
		it()->delete('section',$id);
		$sections->delete();
		return redirectWithSuccess(aurl("sections"),trans('admin.deleted'));
	}


	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$sections = Section::find($id);
				if(is_null($sections) || empty($sections)){
					return backWithError(trans('admin.undefinedRecord'),aurl("sections"));
				}
                    	
				it()->delete('section',$id);
				$sections->delete();
			}
			return redirectWithSuccess(aurl("sections"),trans('admin.deleted'));
		}else {
			$sections = Section::find($data);
			if(is_null($sections) || empty($sections)){
				return backWithError(trans('admin.undefinedRecord'),aurl("sections"));
			}
                    
			it()->delete('section',$data);
			$sections->delete();
			return redirectWithSuccess(aurl("sections"),trans('admin.deleted'));
		}
	}
            

}