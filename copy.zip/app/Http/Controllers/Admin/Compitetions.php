<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\DataTables\CompitetionsDataTable;
use Carbon\Carbon;
use App\Models\Compitetion;

use App\Http\Controllers\Validations\CompitetionsRequest;
use App\Models\Post;
use App\Models\Question;
use App\Models\Winner;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Compitetions extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:compitetions_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:compitetions_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:compitetions_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:compitetions_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}



            /**
             * Baboon Script By [it v 1.6.33]
             * Display a listing of the resource.
             * @return \Illuminate\Http\Response
             */
            public function index(CompitetionsDataTable $compitetions)
            {
               return $compitetions->render('admin.compitetions.index',['title'=>trans('admin.compitetions')]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * Show the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function create()
            {

               return view('admin.compitetions.create',['title'=>trans('admin.create')]);
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * Store a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response Or Redirect
             */
            public function store(CompitetionsRequest $request)
            {
                $data = $request->except("_token", "_method");

                // $compitetions = Compitetion::whereDate('created_at', Carbon::today())->first();
                // if ( $compitetions != null) {
                //   return backWithError("يوجد مسابقة بالفعل فى نفس اليوم");
                // }
            	  $data['start_date'] = date('Y-m-d H:i', strtotime(request('start_date')));
                $data['end_date'] = date('Y-m-d H:i', strtotime(request('end_date')));
                      //  $questions = Question::where('compitetion',null)->orderBy('id', 'DESC')->take($request->count_question)->get();
                      //   if(count($questions) == 0){

                      //       return backWithError("لا يوجد اسئله لاضافتها لمسابقة");

                      //   }
                        $compitetions = Compitetion::create($data);
                        // foreach($questions as $question)
                        // {
                        //     $question->compitetion = $compitetions->id;
                        //     $question->save();
                        // }
                $redirect = isset($request["add_back"])?"/create":"";
                return redirectWithSuccess(aurl('compitetions'.$redirect), trans('admin.added')); }

            /**
             * Display the specified resource.
             * Baboon Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
        		$compitetions =  Compitetion::find($id);
        		return is_null($compitetions) || empty($compitetions)?
        		backWithError(trans("admin.undefinedRecord"),aurl("compitetions")) :
        		view('admin.compitetions.show',[
				    'title'=>trans('admin.show'),
					'compitetions'=>$compitetions
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * edit the form for creating a new resource.
             * @return \Illuminate\Http\Response
             */
            public function edit($id)
            {
        		$compitetions =  Compitetion::find($id);
        		return is_null($compitetions) || empty($compitetions)?
        		backWithError(trans("admin.undefinedRecord"),aurl("compitetions")) :
        		view('admin.compitetions.edit',[
				  'title'=>trans('admin.edit'),
				  'compitetions'=>$compitetions
        		]);
            }


            /**
             * Baboon Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @param  \Illuminate\Http\Request  $request
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				$fillableCols = [];
				foreach (array_keys((new CompitetionsRequest)->attributes()) as $fillableUpdate) {
					if (!is_null(request($fillableUpdate))) {
						$fillableCols[$fillableUpdate] = request($fillableUpdate);
					}
				}
				return $fillableCols;
			}

            public function update(CompitetionsRequest $request,$id)
            {
              // Check Record Exists
              $compitetions =  Compitetion::find($id);
              if(is_null($compitetions) || empty($compitetions)){
              	return backWithError(trans("admin.undefinedRecord"),aurl("compitetions"));
              }
              $data = $this->updateFillableColumns();
              $data['start_date'] = date('Y-m-d H:i', strtotime(request('start_date')));
              $data['end_date'] = date('Y-m-d H:i', strtotime(request('end_date')));
              Compitetion::where('id',$id)->update($data);
              $redirect = isset($request["save_back"])?"/".$id."/edit":"";
              return redirectWithSuccess(aurl('compitetions'.$redirect), trans('admin.updated'));
            }

            /**
             * Baboon Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @param  $id
             * @return \Illuminate\Http\Response
             */
	public function destroy($id){
		$compitetions = Compitetion::find($id);
		if(is_null($compitetions) || empty($compitetions)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("compitetions"));
		}
      // $posts = Post::where('compitetion_id',$id)->first();
      //  if($posts != null){
      //       foreach($posts->posts_details as $details){
      //           $details->delete();
      //       }
      //       $posts->delete();
      //  }
      //  $qts = Question::where('compitetion',$id)->get();
      //  foreach($qts as $qt){
      //   $qt->compitetion = null;
      //   $qt->save();
      //  }
      //  $winers = Winner::where('compitetion_id',$id)->get('compitetion_id');
      //  foreach($winers as $win){
      //   $win->delete();
      //  }
		it()->delete('compitetion',$id);
		$compitetions->delete();
		return redirectWithSuccess(aurl("compitetions"),trans('admin.deleted'));
	}


	public function multi_delete(){
		$data = request('selected_data');
		if(is_array($data)){
			foreach($data as $id){
				$compitetions = Compitetion::find($id);
				if(is_null($compitetions) || empty($compitetions)){
					return backWithError(trans('admin.undefinedRecord'),aurl("compitetions"));
				}

				it()->delete('compitetion',$id);
				$compitetions->delete();
			}
			return redirectWithSuccess(aurl("compitetions"),trans('admin.deleted'));
		}else {
			$compitetions = Compitetion::find($data);
			if(is_null($compitetions) || empty($compitetions)){
				return backWithError(trans('admin.undefinedRecord'),aurl("compitetions"));
			}

			it()->delete('compitetion',$data);
			$compitetions->delete();
			return redirectWithSuccess(aurl("compitetions"),trans('admin.deleted'));
		}
	}


}
