<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\DataTables\WinnersDataTable;
use App\Models\Compitetion;
use App\Models\User;
use App\Sms;
use Carbon\Carbon;
use App\Models\Winner;

use App\Http\Controllers\Validations\WinnersRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class Winners extends Controller
{

    public function __construct()
    {

        $this->middleware('AdminRole:winners_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:winners_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:winners_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:winners_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(WinnersDataTable $winners)
    {
        return $winners->render('admin.winners.index', ['title' => trans('admin.winners')]);
    }

    public function newWinners(){

        $winners = $this->getData(true);
        return View::make('admin.winners.index', ['title' => trans('admin.posts'),'winners'=>$winners]);
    }
    public function lastWinners(){

        $winners = $this->getData(false);
        return View::make('admin.winners.index', ['title' => trans('admin.winners'),'winners'=>$winners]);
    }

    public function getData($forWinners){
        $compitetion = Compitetion::query()
        ->where(function ($query){
            $date = date('Y-m-d H:i:s');
                $query->where("start_date","<",$date)
                ->where("end_date",">=",$date); 
        })->orWhere("frequency","LOOP")->get()->first();

        $now = Carbon::parse(date('Y-m-d H:i:s'));
        if(Carbon::parse($compitetion->start_date)->addDays($now->diffInDays($compitetion->created_at)) > $now){
            $now->subDays(1);
        }
        $compitetion->start_date = Carbon::parse($compitetion->start_date)->addDays($now->diffInDays($compitetion->created_at));
        $compitetion->number = $now->diffInDays($compitetion->created_at);
        $now->addDay();
        $compitetion->end_date = Carbon::parse($compitetion->end_date)->addDays($now->diffInDays($compitetion->created_at));
        // $data['test'] = date_format(auth()->user()->last_task ?? Carbon::now(),"m");
        // $compitetion->start_date = $compitetion->start_date->formatLocalized("%Y-%m-%d");
        // $compitetion->end_date = $compitetion->end_date->formatLocalized("%Y-%m-%d");
        if(!$forWinners){
            $compitetion->start_date->subDay();
            $compitetion->end_date->subDay();
        }
        $winners = 
        DB::table('user_points')
        // UserPoint::all()
        // ->where("user_id",$id)
        // ->where("compitetion_id",request()['compitetion_id'])
        ->where("compitetion_start_date",Carbon::parse($compitetion->start_date)->formatLocalized("%Y-%m-%d"))
        ->where("compitetion_end_date",Carbon::parse($compitetion->end_date)->formatLocalized("%Y-%m-%d"))
        ->groupBy('user_id')
        ->get(["user_id",DB::raw('IFNULL(SUM(points),0) AS win_points')]);
        
        for ($i=0; $i < count($winners); $i++) { 
            $winners[$i]->user = User::find($winners[$i]->user_id);
            $id = $winners[$i]->user->id;
            $winners[$i]->win_count = 
            // GameResult::all()
            DB::table('game_results')
            ->where(function ($query) use($id){
                $query->where("user_win1",$id)
                ->orWhere("user_win2",$id); 
            })
            ->where("type","game")
            ->where("compitetion_start_date",$compitetion->start_date)
            ->where("compitetion_end_date",$compitetion->end_date)
            ->get(DB::raw('COUNT(id) as val'))[0]->val;
            $winners[$i]->loss_count = 
            // GameResult::all()
            DB::table('game_results')
            ->where(function ($query) use($id){
                $query->where("user_loss1",$id)
                ->orWhere("user_loss2",$id); 
            })
            ->where("type","game")
            ->where("compitetion_start_date",$compitetion->start_date)
            ->where("compitetion_end_date",$compitetion->end_date)
            ->get(DB::raw('COUNT(id) as val'))[0]->val;
        }
        return $winners;
    }
    /**
     * Baboon Script By [it v 1.6.33]
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.winners.create', ['title' => trans('admin.create')]);
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * Store a newly created resource in storage.
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(WinnersRequest $request)
    {
        $data = $request->except("_token", "_method");
        $winners = Winner::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl('winners' . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     * Baboon Script By [it v 1.6.33]
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $winners = Winner::find($id);

        return is_null($winners) || empty($winners) ?
            backWithError(trans("admin.undefinedRecord"), aurl("winners")) :
            view('admin.winners.show', [
                'title' => trans('admin.show'),
                'winners' => $winners
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $winners = Winner::find($id);
        return is_null($winners) || empty($winners) ?
            backWithError(trans("admin.undefinedRecord"), aurl("winners")) :
            view('admin.winners.edit', [
                'title' => trans('admin.edit'),
                'winners' => $winners
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * update a newly created resource in storage.
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new WinnersRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(WinnersRequest $request, $id)
    {
        // Check Record Exists
        $winners = Winner::find($id);
        if (is_null($winners) || empty($winners)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("winners"));
        }
        $data = $this->updateFillableColumns();
        Winner::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl('winners' . $redirect), trans('admin.updated'));
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $winners = Winner::find($id);
        if (is_null($winners) || empty($winners)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("winners"));
        }

        it()->delete('winner', $id);
        $winners->delete();
        return redirectWithSuccess(aurl("winners"), trans('admin.deleted'));
    }


    public function multi_delete()
    {
        $data = request('selected_data');
        if (is_array($data)) {
            foreach ($data as $id) {
                $winners = Winner::find($id);
                if (is_null($winners) || empty($winners)) {
                    return backWithError(trans('admin.undefinedRecord'), aurl("winners"));
                }

                it()->delete('winner', $id);
                $winners->delete();
            }
            return redirectWithSuccess(aurl("winners"), trans('admin.deleted'));
        } else {
            $winners = Winner::find($data);
            if (is_null($winners) || empty($winners)) {
                return backWithError(trans('admin.undefinedRecord'), aurl("winners"));
            }

            it()->delete('winner', $data);
            $winners->delete();
            return redirectWithSuccess(aurl("winners"), trans('admin.deleted'));
        }
    }

 public function send_sms_all_winners($compitetions_id)
    {
        if ($compitetions_id) {
            $competition = Compitetion::query()->findOrFail($compitetions_id);
            $winners = Winner::query()->where('compitetion_id', $competition->id)
                ->pluck('user_id')->toArray();
            $users = User::query()->whereIn('id', $winners)->get();

            $competition_start_date = $competition->start_date;
            $message = 'لقد ربحت في المسابقة المقامة بتاريخ ' . $competition_start_date . '- تطبيق من الرابح';

            $string = "";
            foreach ($users as $key => $user) {

                if ($key != 0) {
                    $string = $string . ',';
                }
                $string = $string . $user->phone;

            }

            Sms::send($string, $message);

            return redirectWithSuccess(aurl("winners?id=$compitetions_id"), 'الإرسال للفائزين');

        } else {
            return redirect()->back();
        }


    }

}









