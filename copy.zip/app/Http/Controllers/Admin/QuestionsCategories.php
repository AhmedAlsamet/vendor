<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\QuestionCategoriesDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\QuestionCategoriesRequest;
use Illuminate\Http\Request;
use App\Models\QuestionsCategory;

class QuestionsCategories extends Controller
{

    public function __construct()
    {
        $this->middleware('AdminRole:questions_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:questions_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:questions_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:questions_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     * Baboon Script By [it v 1.6.33]
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(QuestionCategoriesDataTable $questions)
    {
        return $questions->render('admin.question_categories.index', ['title' => trans('admin.question_categories')]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.question_categories.create', ['title' => trans('admin.create')]);
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(QuestionCategoriesRequest $request)
    {

        $data = $request->except("_token", "_method");
        if ($data['question_categorie_is_active'] !== null) {
            $data['question_categorie_is_active'] = 1;
        } else {
            $data['question_categorie_is_active'] = 0;
        }
        $questions = QuestionsCategory::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl("question_categories" . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     * Baboon Script By [it v 1.6.33]
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $questions =  QuestionsCategory::find($id);
        return is_null($questions) || empty($questions) ?
            backWithError(trans("admin.undefinedRecord"), aurl("question_categories")) :
            view('admin.question_categories.show', [
                'title' => trans('admin.show'),
                'questions' => $questions
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $questions =  QuestionsCategory::find($id);
        return is_null($questions) || empty($questions) ?
            backWithError(trans("admin.undefinedRecord"), aurl("question_categories")) :
            view('admin.question_categories.edit', [
                'title' => trans('admin.edit'),
                'questions' => $questions
            ]);
    }


    /**
     * Baboon Script By [it v 1.6.33]
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new QuestionCategoriesRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(QuestionCategoriesRequest $request, $id)
    {
        // Check Record Exists
        $questions =  QuestionsCategory::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("question_categories"));
        }
        $data = $this->updateFillableColumns();
        if ($data['question_categorie_is_active'] !== null) {
            $data['question_categorie_is_active'] = 1;
        } else {
            $data['question_categorie_is_active'] = 0;
        }
        QuestionsCategory::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl('question_categories' . $redirect), trans('admin.updated'));
    }

    /**
     * Baboon Script By [it v 1.6.33]
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $questions = QuestionsCategory::find($id);
        if (is_null($questions) || empty($questions)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("question_categories"));
        }

        it()->delete('question_category', $id);
        $questions->delete();
        return redirectWithSuccess(aurl("question_categories"), trans('admin.deleted'));
    }


    public function multi_delete()
    {
        $data = request('selected_data');
        if (is_array($data)) {
            foreach ($data as $id) {
                $questions = QuestionsCategory::find($id);
                if (is_null($questions) || empty($questions)) {
                    return backWithError(trans('admin.undefinedRecord'), aurl("question_categories"));
                }

                it()->delete('question_category', $id);
                $questions->delete();
            }
            return redirectWithSuccess(aurl("question_categories"), trans('admin.deleted'));
        } else {
            $questions = QuestionsCategory::find($data);
            if (is_null($questions) || empty($questions)) {
                return backWithError(trans('admin.undefinedRecord'), aurl("question_categories"));
            }

            it()->delete('question_category', $data);
            $questions->delete();
            return redirectWithSuccess(aurl("question_categories"), trans('admin.deleted'));
        }
    }
}
