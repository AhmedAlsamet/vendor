<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\AppQuestionDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\AppQuestionRequest;
use App\Models\AppQuestion;
use Illuminate\Http\Request;

class AppQuestions extends Controller
{
    public function __construct() {

		$this->middleware('AdminRole:AppQuestions_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:AppQuestions_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:AppQuestions_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:AppQuestions_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index(AppQuestionDataTable $appQuestion) {
		// dd(print_r($appQuestion));
		return $appQuestion->render('admin.app_questions.index', ['title' => "الأسئلة الشائعة"]);
	}


	public function create() {
		return view('admin.app_questions.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */


	public function store(AppQuestionRequest $request) {
		$data = $request->except("_token", "_method");
		$appQuestion = AppQuestion::create($data);
		return redirectWithSuccess(aurl('app_questions'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */


	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$appQuestion = AppQuestion::find($id);
		return is_null($appQuestion) || empty($appQuestion) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.app_questions.edit', [
			'title' => trans('admin.edit'),
			'appQuestion' => $appQuestion,
		]);
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function update(AppQuestionRequest $request, $id) {
		// Check Record Exists
		$appQuestion = AppQuestion::find($id);
		if (is_null($appQuestion) || empty($appQuestion)) {
			return backWithError(trans("admin.undefinedRecord"));
		}

		$data = $request->except("_token", "_method");

		AppQuestion::where('id', $id)->update([
			'title' => $data['title'],
			'title_lat' => $data['title_lat'],
			'description' => $data['description'],
			'description_lat' => $data['description_lat'],
		]);



		return redirectWithSuccess(aurl('app_questions'), trans('admin.updated'));
	}

	/**
	 * Baboon Script By [It V 1.5.0 | https://it.phpanonymous.com]
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$appQuestion = AppQuestion::find($id);
		if (is_null($appQuestion) || empty($appQuestion)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		// Delete Roles
		it()->delete('app_questions',$id);
		$appQuestion->delete();
		return redirectWithSuccess(aurl("app_questions"),trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$appQuestion = AppQuestion::find($id);
				if (is_null($appQuestion) || empty($appQuestion)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				// Delete Roles
				it()->delete('app_questions',$id);
				$appQuestion->delete();

			}
			return redirectWithSuccess(aurl("app_questions"),trans('admin.deleted'));
		} else {
			$appQuestion = AppQuestion::find($data);
			if (is_null($appQuestion) || empty($appQuestion)) {
				return backWithError(trans('admin.undefinedRecord'));
			}
			// Delete Roles
			it()->delete('app_questions',$data);
			$appQuestion->delete();
			return redirectWithSuccess(aurl("app_questions"),trans('admin.deleted'));
		}
	}
}
