<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\QuestionsCategory;
use App\Models\Setting;
use App\Models\TodayWisdom;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class Dashboard extends Controller {

	public function home() {
        // check expired TodayWisdom
        $today = date('Y-m-d');
        $sections = TodayWisdom::where('month_wisdom',1)->where('start_at','<',$today)->get();
        if(count($sections) > 0){
            foreach ($sections as $section) {
               $section->month_wisdom = 2;
               $section->save();
            }
        }
		$record = User::select(DB::raw("COUNT(*) as count"), DB::raw("MONTHNAME(created_at) as month_name"), DB::raw("MONTH(created_at) as month"))
		->where('created_at', '>', Carbon::today()->subDay(366))
		->groupBy('month_name','month')
		->orderBy('month')
		->get();
	 
		 $data = [];
	
		 foreach($record as $row) {
			$data['label'][] = $row->month_name;
			$data['data'][] = (int) $row->count;
		  }
	
		$data['chart_data'] = json_encode($data);
		return view('admin.home', $data);
	}

	public function prepareKey($key) {
		$setting = setting()->theme_setting;
		if (!empty($setting) && !empty($setting->{$key})) {
			$$key = $setting->{$key};
		} else {
			$$key = '';
		}

		if (request()->has($key)) {
			if (!empty(request($key))) {
				return [$key => request($key)];
			} else {
				return [$key => ''];
			}
		} else {
			return [$key => $$key];
		}

	}

	public function theme_setting() {
		$data_setting = [];
		$data_setting = array_merge($data_setting, $this->prepareKey('brand_color'));
		$data_setting = array_merge($data_setting, $this->prepareKey('sidebar_class'));
		$data_setting = array_merge($data_setting, $this->prepareKey('main_header'));
		$data_setting = array_merge($data_setting, $this->prepareKey('navbar'));
		//return print_r($data_setting);
		return json_encode($data_setting);
	}

	public function theme($id) {
		if (request()->ajax()) {
			$update = Setting::find(setting()->id);
			$update->theme_setting = $this->theme_setting();
			$update->save();
			return setting()->theme_setting;
		} else {
			return 'no ajax request';
		}
	}
}
