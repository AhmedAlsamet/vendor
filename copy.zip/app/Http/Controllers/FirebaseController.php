<?php

namespace App\Http\Controllers;

use App\Firebase;
use App\FcmNotification;
use Illuminate\Http\Request;
use Validator;
use App\Models\User;

class FirebaseController extends Controller
{
    public function index()
    {
    //     $title = "قبول الطلب";
	// 	$body = '  تم قبول عرضك بنجاح على طلب رقم ';
    //   $firebaseToken = User::whereNotNull('fcm_token')->pluck('fcm_token')->all();
    //     FcmNotification::sendNotification();
        return "done";
    }
   
    public function store(Request $request)
    {


        $tokens = Firebase::all();
        
        $data = Validator::make($request->all(), [
            'title' => ['required', 'string', 'max:255'],
            'body' => ['required', 'string'],
            'file' => ['required', 'string'],
        ],
        [
            'title.required' => 'عنوان الاشعار مطلوب ',
            'file.required' => 'ملف الصوت مطلوب ',
            'body.required' => 'تفاصيل الاشعار مطلوب'
        ]

        );

        if ($data->fails()) {
            return back()->withErrors($data)->withInput();
        }
        


            $date =[
                "title" => request()->title,
                "file" => request()->file,
            ];
            FcmNotification::sendToMultiple($tokens, $date , request()->body,null ,null);
            // dd($request->file);

        
        return back()->with("status" , "تم ارسال الاشعار بنجاح !");

    }

    public function save(Request $request)
    {
        dd($request->all());
        if($request->fcm_token == ""  && empty($request->fcm_token)) {
            
            return  response()->json([
                "status" => false,
                "code"=> 203,
                "message"=> "التوكن خالى تاكد من البيانات"
            ], 203);
        }

        $Firebase = new Firebase();
        $Firebase->fcm_token = $request->fcm_token;
        $Firebase->save(); 

        return  response()->json([
            "status" => true,
            "code"=> 200,
            "message"=> "تمت الإضافة بنجاح"
        ], 200);

    }

    public function saveToken(Request $request)
    {
        auth()->user()->update(['device_token'=>$request->token]);
        return response()->json(['token saved successfully.']);
    }

    public function sendNotification(Request $request)
    {
        $firebaseToken = User::whereNotNull('fcm_token')->pluck('fcm_token')->all();


        $SERVER_API_KEY = "AAAAo88FVJg:APA91bE_9n1h5mFPVk6TEolFjpHHySk0KU7qd4Scr7vBVia0jzhOOnm7gLZO7UylZDe0oyIpzbXjbwgIl_dSh7eb64cEN1PqH0lNSxXBgFvqEYjUQ49PmCh4dmShGAb6zsMsOwbUxg-b";

        $data = [
            "registration_ids" => $firebaseToken,
            "notification" => [
                "title" => $request->title,
                "body" => $request->body,
                "content_available" => true,
                "priority" => "high",
            ],
            "data" => [
                "title" => $request->title,
                "body" => $request->body,
                "content_available" => true,
                "priority" => "high",
            ]
        ];
        $dataString = json_encode($data);
        $headers = [
            'Authorization: key=' . $SERVER_API_KEY,
            'Content-Type: application/json',
        ];

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

        $response = curl_exec($ch);

        dd($response);
    }


}
