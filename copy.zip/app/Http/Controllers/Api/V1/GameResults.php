<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\GameResult;
use Illuminate\Http\Request;

class GameResults extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $gameResult = new GameResult();
        $gameResult->compitetion_id = $request["compitetion_id"];
        $gameResult->session_id = $request["session_id"];
        $gameResult->user_win1 = $request["user_win1"];
        $gameResult->user_win2 = $request["user_win2"]??null;
        $gameResult->type = $request["type"];
        $gameResult->state = $request["state"];
        $gameResult->user_loss1 = $request["user_loss1"];
        $gameResult->user_loss2 = $request["user_loss2"]??null;
        $gameResult->winner_result = $request["winner_result"];
        $gameResult->losser_result = $request["losser_result"];
        $gameResult->save();
        return successResponseJson(["data"=>$gameResult]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
