<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\FriendRequest;
use App\Http\Resources\FriendResource;
use App\Models\Friend;
use App\Models\User;
use Illuminate\Http\Request;

class FriendsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(FriendRequest $request)
    {
        $data = $request->except("_token");
		$Users = Friend::where("user_id",auth()->user()->id)->where("user_friend_id",$data["user_id"])->get();

        if(count($Users)>0){
            if($Users[0]->state == "ORDER"){
                return errorResponseJson([
                    "message"=>trans("admin.added"),
                    "data"=>["ar"=>"لقد قمت بالفعل بإرسال طلب لهذا المستخدم","en"=>"لقد قمت بالفعل بإرسال طلب لهذا المستخدم"]                ]);
            }
            return errorResponseJson([
                "message"=>trans("admin.added"),
                "data"=>["ar"=>"لقد قمت بالفعل بإضافة هذا المستخدم لقائمة الأصدقاء","en"=>"لقد قمت بالفعل بإضافة هذا المستخدم لقائمة الأصدقاء"]                
            ]);
        }
        $user = User::find($data["user_id"]);
        if (is_null($user) || empty($user) || $user->id == auth()->user()->id) {
            return errorResponseJson([
                "message"=>trans("admin.added"),
                "data"=>["ar"=>"رقم هذا المستخدم غير موجود","en"=>"رقم هذا المستخدم غير موجود"]
            ]);
		}
        $friend = new Friend();
        $friend->state = "ORDER";
        $friend->user_id = auth()->user()->id;
        $friend->user_friend_id  = $data["user_id"];

        $friend = $friend->save();
        $your_send_order = FriendResource::collection(Friend::select("*",'friends.id','friends.created_at','friends.updated_at')
        ->join('users', 'users.id', '=', 'friends.user_friend_id')->where("state","ORDER")
        ->where("user_id",auth()->user()->id)->where("user_friend_id",$data["user_id"])->get());
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$your_send_order
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->except("_token");
        $friend = Friend::find($id);
        $friend->state = $data["state"];

        $friend = $friend->update();
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$friend
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $friend = Friend::find($id);

        $friend = $friend->delete();
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$friend
        ]);
    }
}
