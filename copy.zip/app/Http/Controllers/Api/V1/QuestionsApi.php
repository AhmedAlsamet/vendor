<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Question;
use App\Models\Winner;
use App\Models\Post;

use App\Models\Compitetion;

use Validator;
use App\Http\Controllers\ValidationsApi\V1\QuestionsRequest;
use App\Models\PostDetails;
use App\Models\QuestionsCategory;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class QuestionsApi extends Controller{
	protected $selectColumns = [
		"id",
		"question_name",
		"question_answer1",
		"question_answer2",
		"question_answer3",
		"question_answer4",
		"question_name_lat",
		"question_answer1_lat",
		"question_answer2_lat",
		"question_answer3_lat",
		"question_answer4_lat",
		"question_category_id",
		"question_correct_answer",
	];

    private function auth() {
		return auth()->guard('api');
	}


            public function arrWith(){
               return [];
            }


        public function index()
        {

            $compitetions = Compitetion::where('start_date','<=',now())
            ->where('end_date','>=',now())->first();
            $today = Carbon::now()->format('Y-m-d');
            if ( $compitetions == null) {
                return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقات اليوم");
            }elseif($today == date('Y-m-d', strtotime($compitetions->end_date))){
                return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقات اليوم");
            }
            $posts = Post::join('compitetions', 'compitetions.id', '=', 'posts.compitetion_id')->select(['posts.*', 'compitetions.start_date', 'compitetions.end_date'])
            ->where('compitetion_id',$compitetions->id)
            ->where('posts.user_id', auth()->user()->id)
            ->first();

            if ( $posts != null) {

                // return errorResponseJson(['data' => null], 202 , "اجبت على مسابقة اليوم");
                $details = PostDetails::where('post_id',$posts->id)->get()->pluck('qestion_id')->toArray();

            }else{
                $details = [];
            }

            // $winners = Winner::where("user_id", auth()->user()->id)->where('compitetion_id',$compitetions->id)->get()->pluck('qestion_id')->toArray();
            // $data = array_merge($winners, $details);
            $oneQuestions = Question::whereNotIn("id",$details)->where('compitetion',$compitetions->id)->OrderBy('id','DESC')->get();

            // if(isset($data) && !empty($data)){
            //     $oneQuestions = Question::whereNotIn("id",$details)->OrderBy('id','DESC')->get();


            // }else{

            //     $oneQuestions = Question::where('compitetion',$compitetions->id)->OrderBy('id','DESC')->get();

            // }

            if(count($oneQuestions) == 0){
                return errorResponseJson(['data' => null], 204 , "عفواً! لقدت اجبت علي جميع الاسألة الرجاء الإنتظار المسابقة القادمة");
            }

            $first = rand(0,$oneQuestions->count()-1);
            if ( $oneQuestions == null ) {
                return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقة");
            }
            return successResponseJson(["data"=>[
                "compitetion" => $compitetions,
                // "question" => $oneQuestions[$first]
                "question" => $oneQuestions
             ]
                 , ]);
        }

        public function getCategories()
        {
            $compitetions = QuestionsCategory::all();
            if(count($compitetions) == 0){
                return errorResponseJson(['data' => null], 204 , "لا توجد روابط لجلبها");
            }
    
            return successResponseJson(["data"=>$compitetions]);
        }
    

        public function store(QuestionsRequest $request)
        {

            $data = $request->except("_token");

            $Question = Question::create($data);

            $Question = Question::with($this->arrWith())->find($Question->id,$this->selectColumns);
            return successResponseJson([
                "message"=>trans("admin.added"),
                "data"=>$Question
            ]);
        }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Question = Question::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Question) || empty($Question)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Question
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new QuestionsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(QuestionsRequest $request,$id)
            {
            	$Question = Question::find($id);
            	if(is_null($Question) || empty($Question)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();

              Question::where("id",$id)->update($data);

              $Question = Question::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Question
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $questions = Question::find($id);
            	if(is_null($questions) || empty($questions)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("question",$id);

               $questions->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $questions = Question::find($id);
	            	if(is_null($questions) || empty($questions)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("question",$id);
                    	$questions->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $questions = Question::find($data);
	            	if(is_null($questions) || empty($questions)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("question",$data);

                    $questions->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }
}
