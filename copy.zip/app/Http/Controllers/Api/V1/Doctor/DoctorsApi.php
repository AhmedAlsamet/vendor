<?php
// namespace App\Http\Controllers\Api\V1;
namespace App\Http\Controllers\Api\V1\Doctor;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Doctor;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\DoctorsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class DoctorsApi extends Controller{
	protected $selectColumns = [
		"id",
		"doctor_name",
		"doctor_phone",
		"doctor_address",
		"doctor_email",
		"doctor_job_details",
		"password",
		"contry_id",
		"fcm",
		"doctor_photo",
	];



            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return [];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
            	$Doctor = Doctor::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->get();
               return successResponseJson(["data"=>$Doctor]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
            private function auth() {
                return auth()->guard('doctor');
            }
        
            protected function respondWithToken($token) {
                return [
                    'access_token' => $token,
                    'token_type' => 'Bearer',
                    'expires_in' => $this->auth()->factory()->getTTL() * 60,
                    'user' => $this->auth()->user(),
                ];
            }
    public function store(DoctorsRequest $request)
    {
    	$data = $request->except("_token");
    	
                $data["doctor_photo"] = "";
        $Doctor = Doctor::create($data); 
               if(request()->hasFile("doctor_photo")){
              $Doctor->doctor_photo = it()->upload("doctor_photo","doctors/".$Doctor->id);
              $Doctor->save();
              }

		//   $Doctor = Doctor::with($this->arrWith())->find($Doctor->id,$this->selectColumns);
          $credentials = request(['doctor_phone', 'password' , 'contry_id']);

          $token = auth()->attempt($credentials);
        // dd($this->respondWithToken($token));
          if (!$token) {
              return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
          }
          $user  = $this->auth()->user();

          $users = array([
              'id' => $user->id,
              'doctor_name' => $user->doctor_name,
              'doctor_phone' => $user->doctor_phone,
              'doctor_email' => $user->doctor_email ?? null,
              'contry_id' => $user->contry_id,
              'doctor_address' => $user->doctor_address,
              'doctor_job_details' => $user->doctor_job_details,
              'doctor_photo' => $user->doctor_photo,
              'token' => $this->respondWithToken($token)['access_token'],
              'token_type' => $this->respondWithToken($token)['token_type'],
          ]);
          // $data =  Users::collection($users);
          return successResponseJson(['data' =>$users],trans('admin.loginsuccess'));

    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Doctor = Doctor::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Doctor) || empty($Doctor)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Doctor
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new DoctorsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update($id)
            {
                return "not worked ";
                $validation = Validator::make(request()->all(),[ 
                    'doctor_name'=>'string|max:50',
                    'doctor_phone'=>'numeric',
                    'doctor_address'=>'string',
                    'doctor_email'=>'email',
                    'doctor_job_details'=>'',
                    'password'=>'',
                    'contry_id'=>'',
                    'doctor_photo'=>'image',
                ]);
            
                if($validation->fails()){
        
                    if(count($validation->errors()) > 0 ) {
                        $erorrs = $validation->errors();
        
                        foreach($erorrs->all() as $item) {
                        return errorResponseJson(['data' => $erorrs->all()]  ,203 ,$item);	
        
                        }
                    }
                }
            	$Doctor = Doctor::find($id);
            	if(is_null($Doctor) || empty($Doctor)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

                 
               if(request()->hasFile("doctor_photo")){
                  it()->delete($Doctor->doctor_photo);
                  $Doctor->doctor_photo = it()->upload("doctor_photo","doctors/".$Doctor->id);
               }
               if ($Doctor->doctor_name != "" && $Doctor->doctor_name != null) { 
                $Doctor->doctor_name = request()->doctor_name;
               }
               if ($Doctor->doctor_phone != "" && $Doctor->doctor_phone != null) { 
                $Doctor->doctor_phone = request()->doctor_phone;
               }
               if ($Doctor->doctor_address != "" && $Doctor->doctor_address != null) { 
                $Doctor->doctor_address = request()->doctor_address;
               }
               if ($Doctor->doctor_email != "" && $Doctor->doctor_email != null) { 
                $Doctor->doctor_email = request()->doctor_email;
               }
               if ($Doctor->doctor_job_details != "" && $Doctor->doctor_job_details != null) { 
                $Doctor->doctor_job_details = request()->doctor_job_details;
               }
               if ($Doctor->password != "" && $Doctor->password != null) { 
                $Doctor->password = request()->password;
               }

               $Doctor->save();

              $Doctor = Doctor::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Doctor
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $doctors = Doctor::find($id);
            	if(is_null($doctors) || empty($doctors)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


              if(!empty($doctors->doctor_photo)){
               it()->delete($doctors->doctor_photo);
              }
               it()->delete("doctor",$id);

               $doctors->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $doctors = Doctor::find($id);
	            	if(is_null($doctors) || empty($doctors)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	if(!empty($doctors->doctor_photo)){
                    	it()->delete($doctors->doctor_photo);
                    	}
                    	it()->delete("doctor",$id);
                    	$doctors->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $doctors = Doctor::find($data);
	            	if(is_null($doctors) || empty($doctors)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	if(!empty($doctors->doctor_photo)){
                    	it()->delete($doctors->doctor_photo);
                    	}
                    	it()->delete("doctor",$data);

                    $doctors->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}