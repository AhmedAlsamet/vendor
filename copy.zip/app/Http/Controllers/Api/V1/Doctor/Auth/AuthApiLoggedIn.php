<?php
namespace App\Http\Controllers\Api\V1\Doctor\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Http\Resources\Users;
use App\Models\User;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
class AuthApiLoggedIn extends Controller {

	public function __construct() {

		$this->middleware(['jwt.doctor:doctor'], ['except' => ['login' , 'otp']]);
		auth()->setDefaultDriver('doctor');
		config()->set( 'auth.defaults.guard', 'doctor' );
		config()->set('jwt.users', 'App\Models\Doctor'); 
		config()->set('auth.providers.doctors.model', \App\Models\Doctor::class);
	}
	private function auth() {
		return auth()->guard('doctor');
	}

	public function login() {
		$validation = Validator::make(request()->all(),[ 
			'doctor_phone' => 'required|min:8',
			'password' => 'required',
			'contry_id' => 'required'
		]);
	
		if($validation->fails()){
			return errorResponseJson(['data' =>  $validation->errors()] ,203 ,trans('admin.error_loggedin'));	
		}
		
		
			$credentials = request(['doctor_phone', 'password' , 'contry_id']);
			$token = auth()->attempt($credentials);
			
	

		if (!$token) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		$user  = $this->auth()->user();

		$users = array([
			'id' => $user->id,
			'doctor_name' => $user->doctor_name,
			'doctor_phone' => $user->doctor_phone,
			'doctor_email' => $user->doctor_email ?? null,
			'contry_id' => $user->contry_id,
			'doctor_address' => $user->doctor_address,
			'doctor_job_details' => $user->doctor_job_details,
			'doctor_photo' => $user->doctor_job_details,
			'token' => $this->respondWithToken($token)['token'],
			'token_type' => $this->respondWithToken($token)['token_type'],
		]);
		// $data =  Users::collection($users);
		return successResponseJson(['data' =>$users],trans('admin.loginsuccess'));
	}

	public function me() {
		$user  = $this->auth()->user();
		if (!$user) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		if (! empty( request()->fcm_token)  || request()->has('fcm_token') )  {
			$user->fcm_token = request()->fcm_token;
			$user->update();
		}

		$users = array([
			'id' => $user->id,
			'doctor_name' => $user->doctor_name,
			'doctor_phone' => $user->doctor_phone,
			'doctor_email' => $user->doctor_email ,
			'contry_id' => $user->contry_id,
			'doctor_address' => $user->doctor_address,
			'doctor_job_details' => $user->doctor_job_details,
			'doctor_photo' => $user->doctor_photo,

		]);
		return successResponseJson(['data' =>$users],trans('admin.infosuccess'));
	}

	public function update_profile()
	{
		$user = User::find($this->auth()->user()->id);
		// $user->id = $this->auth()->user()->id;
		if (request()->name  || request()->name != null ) {
			$user->name = request()->name;

		} 
		if (request()->phone  || request()->phone != null ) {
			$user->phone = request()->phone;

		} 
		if (request()->contry_id  || request()->contry_id != null ) {
			$user->contry_id = request()->contry_id;

		} 
		if (request()->password  || request()->password != null ) {
			$user->password = \Hash::make(request()->password);

		} 
		if (request()->fcm_token  || request()->fcm_token != null ) {
			$user->fcm_token = request()->fcm_token;

		} 
		$user->update();
		return successResponseJson(['data' =>true],trans('admin.Updatesuccessfully'));



	}
	
	public function logout() {
		$this->auth()->logout();
		return successResponseJson(['data' =>true],trans('admin.logoutsuccess'));
	}

	public function refresh() {
		return successResponseJson(['data' =>$this->respondWithToken( $this->auth()->refresh())],trans('admin.updatetokensuccess'));
		// return successResponseJson(['data' =>  ]);
	}
	protected function respondWithToken($token) {
		return [
			'token' => $token,
			'token_type'   => 'bearer',
		];
	}

	function generatePIN($digits = 4){
        $i = 0; //counter
        $pin = ""; //our default pin is blank.
        while($i < $digits){
            //generate a random number between 0 and 9.
            $pin .= mt_rand(0, 9);
            $i++;
        }
        return (int)$pin;
   }

}