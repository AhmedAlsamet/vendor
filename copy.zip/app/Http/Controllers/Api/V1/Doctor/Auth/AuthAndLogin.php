<?php
namespace App\Http\Controllers\Api\V1\Doctor\Auth;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ValidationsApi\V1\Auth\ChangePasswordRequest;
use App\Http\Controllers\ValidationsApi\V1\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Validator;
use App\Http\Resources\Users;

class AuthAndLogin extends Controller {


	public function __construct() {

		$this->middleware(['jwt.doctor:doctor'], ['except' => ['login' , 'otp']]);
		auth()->setDefaultDriver('doctor');
		config()->set( 'auth.defaults.guard', 'doctor' );
		config()->set('jwt.doctor', 'App\Models\Doctor'); 
		config()->set('auth.providers.users.model', \App\Models\Doctor::class);
	}

	private function auth() {
		return auth()->guard('doctor');
	}

	protected function respondWithToken($token) {
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
	}


	public function me() {
		$user  =$this->auth()->user();
		if (!$user) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		if (! empty( request()->fcm_token)  || request()->has('fcm_token') )  {
			$user->fcm_token = request()->fcm_token;
			$user->update();
		}
		$users = array([
			'id' => $user->id,
			'name' => $user->name,
			'phone' => $user->phone,
			'email' => $user->email ?? null,
			'contry_id' => $user->contry_id,
			'type' => $user->type
		]);
		// $data =  Users::collection($users);
		return successResponseJson(['data' =>$users],trans('admin.infosuccess'));
	}

	public function logout() {
		$this->auth()->logout();
		return successResponseJson([['data' =>null], 'Successfully logged out']);
	}


	public function refresh() {
		return successResponseJson(['data' => $this->respondWithToken($this->auth()->refresh())]);
	}

	public function account() {
		return successResponseJson(['data' => $this->auth()->user()]);
	}

	public function login() {
		$validation = Validator::make(request()->all(),[ 
			'phone' => 'required|min:8',
			'password' => 'required',
			'contry_id' => 'required'
		]);
	
		if($validation->fails()){

			if(count($validation->errors()) > 0 ) {
				$erorrs = $validation->errors();

				foreach($erorrs->all() as $item) {
				return errorResponseJson(['data' => $erorrs->all()]  ,203 ,$item);	

				}
			}
		}
		
		
			$credentials = request(['phone', 'password' , 'contry_id']);
			$token = $this->auth()->attempt($credentials);
			
	

		if (!$token) {
			return errorResponseJson(['data' => [] ],203, trans('auth.failed'));
		}
		// $user  = Auth::guard("client")->user();
		// $credentials = request(['phone', 'password']);
		// try {
		// 	if (!$token = $this->auth()->attempt($credentials)) {
		// 		return errorResponseJson(['data' => 'Unauthorized', 'message' => trans('auth.failed')]);
		// 	}
		// } catch (JWTException $e) {
		// 	return errorResponseJson(['data' => 'Unauthorized', 'message' => 'Could not create token']);
		// }
		$user  = $this->auth()->user();

		$users = array([
			'id' => $user->id,
			'name' => $user->name,
			'phone' => $user->phone,
			'email' => $user->email ?? null,
			'contry_id' => $user->contry_id,
			'type' => $user->type,
			'token' => $token,
			'token_type' => 'Bearer',
		]);
		$data =  Users::collection($users);
		return successResponseJson(['data' =>$data],trans('admin.loginsuccess'));

		// return successResponseJson(['data' =>$this->respondWithToken($token)]);
	}

	public function change_password(ChangePasswordRequest $changepassword) {
		User::where('id', $this->auth()->user()->id)->update([
			'password' => bcrypt(request('new_password')),
		]);
		return successResponseJson([
			'message' => trans('main.password_changed'),
		]);
	}

}