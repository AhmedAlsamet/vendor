<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Session;
use Carbon\Carbon;
use Illuminate\Http\Request;
use TomatoPHP\LaravelAgora\Services\Agora;

use function Ramsey\Uuid\v4;

class SessionsApi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
     public function createNewSessionOrSearchFor(Request $request){
        $now = Carbon::now()->subMinutes(1);
        $session = Session::query()->select("*")->where('updated_at','>',$now)->where("type",$request["type"])->where("state","waiting")->first();
        if($request["key"] != null){
            $now = Carbon::now()->subMinutes(5);
            $session = Session::query()->select("*")->where('updated_at','>',$now)->where("type",$request["type"])->where("state","waiting")->where("link",$request["key"])->first();
        }
        if($session != null){
            $userNumber = "user2";
            $session->state = "started";
            if($request["type"] == "competition_four"){
                
            }
            else if($request["type"] == "competition_tow"){
                
            }
            else{
                $session->user2 = auth()->user()->id;
                $session->user2_state = "exist";
                $session->number_of_users = 2;
                $userNumber = "user2";
            }
            $session->save();
            return successResponseJson(["data"=>$session,"state"=>"update","user"=>$userNumber]);
        }else{
            if($request["key"] == null){
                $session = new Session();
                $session->user1 = auth()->user()->id;
                $session->link = v4();
                $session->type = $request["type"];
                $session->state = "waiting";
                $session->number_of_users = 1;
                $session->user1_state = "exist";
                // $session->save();
                $session->token = Agora::make(id: $session->id)->uId(0)->channel('game')->token();
                $session->save();
                return successResponseJson(["data"=>$session,"state"=>"new","user"=>"user1"]);
            }else{
                return errorResponseJson(["data"=>"Not Found"]);
            }
        }
    }

    public function updateUserState(Request $request){
        $session = Session::find($request["id"]);
        $session[$request['user']] = auth()->user()->id;
        $session[$request['user']."_state"] = "exist";
        $session->save();
        return successResponseJson(["data"=>$session]);
    }

    public static function v4() 
    {
        // return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        return sprintf('%04x%04x-%04x-%04x%04x',

        // 32 bits for "time_low"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),

        // 16 bits for "time_mid"
        mt_rand(0, 0xffff),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand(0, 0x0fff) | 0x4000,

        // 16 bits, 8 bits for "clk_seq_hi_res",
        // 8 bits for "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand(0, 0x3fff) | 0x8000,

        // 48 bits for "node"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
