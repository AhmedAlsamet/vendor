<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Add;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\AddsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class AddsApi extends Controller{
	protected $selectColumns = [
		"id",
		"adds_name",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return [];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
                $Add = Add::orderBy('id','desc')->get();
                return successResponseJson(['data' =>$Add],trans('admin.Datasuccessfully'));
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(AddsRequest $request)
    {
    	$data = $request->except("_token");
    	
        $Add = Add::create($data); 

		  $Add = Add::with($this->arrWith())->find($Add->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$Add
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Add = Add::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Add) || empty($Add)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Add
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new AddsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(AddsRequest $request,$id)
            {
            	$Add = Add::find($id);
            	if(is_null($Add) || empty($Add)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Add::where("id",$id)->update($data);

              $Add = Add::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Add
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $adds = Add::find($id);
            	if(is_null($adds) || empty($adds)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("add",$id);

               $adds->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $adds = Add::find($id);
	            	if(is_null($adds) || empty($adds)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("add",$id);
                    	$adds->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $adds = Add::find($data);
	            	if(is_null($adds) || empty($adds)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	it()->delete("add",$data);

                    $adds->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}