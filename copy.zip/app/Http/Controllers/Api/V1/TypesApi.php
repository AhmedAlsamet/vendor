<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Type;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\TypesRequest;
use App\Http\Resources\TypesResourse;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class TypesApi extends Controller{
	protected $selectColumns = [
		"id",
		"type_name_ar",
		"type_name_en",
		"type_photo",
		"type_catagory",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return ['type_catagory',];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
               $Type = Type::orderBy("id","desc")->get();
                $TypesResourse =  TypesResourse::collection($Type);
                return successResponseJson(['data' =>$TypesResourse],trans('admin.Datasuccessfully'));
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(TypesRequest $request)
    {
    	$data = $request->except("_token");
    	
                $data["type_photo"] = "";
        $Type = Type::create($data); 
               if(request()->hasFile("type_photo")){
              $Type->type_photo = it()->upload("type_photo","types/".$Type->id);
              $Type->save();
              }

		  $Type = Type::with($this->arrWith())->find($Type->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$Type
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                
                $Type = Type::where("type_catagory" , "=" ,$id )->orderBy("id","desc")->get();

            	if(is_null($Type) || empty($Type)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                $TypesResourse =  TypesResourse::collection($Type);
                return successResponseJson(['data' =>$TypesResourse],trans('admin.Datasuccessfully'));
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new TypesRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(TypesRequest $request,$id)
            {
            	$Type = Type::find($id);
            	if(is_null($Type) || empty($Type)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
               if(request()->hasFile("type_photo")){
              it()->delete($Type->type_photo);
              $data["type_photo"] = it()->upload("type_photo","types/".$Type->id);
               }
              Type::where("id",$id)->update($data);

              $Type = Type::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Type
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $types = Type::find($id);
            	if(is_null($types) || empty($types)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


              if(!empty($types->type_photo)){
               it()->delete($types->type_photo);
              }
               it()->delete("type",$id);

               $types->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $types = Type::find($id);
	            	if(is_null($types) || empty($types)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	if(!empty($types->type_photo)){
                    	it()->delete($types->type_photo);
                    	}
                    	it()->delete("type",$id);
                    	$types->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $types = Type::find($data);
	            	if(is_null($types) || empty($types)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	if(!empty($types->type_photo)){
                    	it()->delete($types->type_photo);
                    	}
                    	it()->delete("type",$data);

                    $types->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}