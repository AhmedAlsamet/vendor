<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Catagory;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\CategoriesRequest;
use App\Http\Resources\CatagoryResourse;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class CategoriesApi extends Controller{
	protected $selectColumns = [
		"id",
		"catagory_name_ar",
		"catagory_name_en",
		"Catagory_photo",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return [];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
                $Catagory = Catagory::query();
                if (request()->search && request()->search != null ) {
                    $Catagory->where('catagory_name_ar', 'LIKE', '%'.request()->search.'%');
                    $Catagory->Orwhere('catagory_name_en', 'LIKE', '%'.request()->search.'%');
                }
                if (request()->type && request()->type != null && request()->type == "true"  ) {
                    $cat = [];
                    foreach($Catagory->get() as $item) {
                       if ($item->type->count() > 0) {
                        array_push($cat,$item);

                       } 
                    }
                    $CatagoryResourse =  CatagoryResourse::collection($cat);
                    return successResponseJson(['data' =>$CatagoryResourse],trans('admin.Datasuccessfully'));
                    // dd($cat);
                 }


                $CatagoryResourse =  CatagoryResourse::collection($Catagory->orderBy("id","asc")->get());
                return successResponseJson(['data' =>$CatagoryResourse],trans('admin.Datasuccessfully'));
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(CategoriesRequest $request)
    {
    	$data = $request->except("_token");
        $data["Catagory_photo"] = "";
        $Catagory = Catagory::create($data); 
               if(request()->hasFile("Catagory_photo")){
              $Catagory->Catagory_photo = it()->upload("Catagory_photo","categories/".$Catagory->id);
              $Catagory->save();
              }

		  $Catagory = Catagory::with($this->arrWith())->find($Catagory->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$Catagory
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Catagory = Catagory::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Catagory) || empty($Catagory)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                $CatagoryResoursed =  array(
                    [
                        'id' => $Catagory['id'],
                        'name' => app()->getlocale() == "ar" ? $Catagory['catagory_name_ar'] : $Catagory['catagory_name_en'] ,
                        'image' => $Catagory['catagory_photo'] ?? null
                    ]
                );
                return successResponseJson(['data' =>$CatagoryResoursed],trans('admin.Datasuccessfully'));
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new CategoriesRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(CategoriesRequest $request,$id)
            {
            	$Catagory = Catagory::find($id);
            	if(is_null($Catagory) || empty($Catagory)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Catagory::where("id",$id)->update($data);

              $Catagory = Catagory::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Catagory
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $categories = Catagory::find($id);
            	if(is_null($categories) || empty($categories)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


              if(!empty($categories->catagory_photo)){
               it()->delete($categories->catagory_photo);
              }
              if(!empty($categories->catagory_photo_en)){
               it()->delete($categories->catagory_photo_en);
              }
               it()->delete("catagory",$id);

               $categories->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $categories = Catagory::find($id);
	            	if(is_null($categories) || empty($categories)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	if(!empty($categories->catagory_photo)){
                    	it()->delete($categories->catagory_photo);
                    	}
                    	if(!empty($categories->catagory_photo_en)){
                    	it()->delete($categories->catagory_photo_en);
                    	}
                    	it()->delete("catagory",$id);
                    	$categories->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $categories = Catagory::find($data);
	            	if(is_null($categories) || empty($categories)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	if(!empty($categories->catagory_photo)){
                    	it()->delete($categories->catagory_photo);
                    	}
                    	if(!empty($categories->catagory_photo_en)){
                    	it()->delete($categories->catagory_photo_en);
                    	}
                    	it()->delete("catagory",$data);

                    $categories->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}