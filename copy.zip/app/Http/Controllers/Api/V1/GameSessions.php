<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\GameSession;
use Illuminate\Http\Request;

class GameSessions extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    // public function createNewSessionOrSearchFor(Request $request){
    //     $now = Carbon::now()->subMinutes(1);
    //     $session = Session::query()->select("*")->where('updated_at','>',$now)->where("type",$request["type"])->where("state","waiting")->first();
    //     if($session != null){
    //         $userNumber = "user2";
    //         $session->state = "started";
    //         if($request["type"] == "competition_four"){
                
    //         }
    //         else if($request["type"] == "competition_tow"){
                
    //         }
    //         else{
    //             $session->user2 = auth()->user()->id;
    //             $session->user2_state = "exist";
    //             $session->number_of_users = 2;
    //             $userNumber = "user2";
    //         }
    //         $session->save();
    //         return successResponseJson(["data"=>$session,"state"=>"update","user"=>$userNumber]);
    //     }else{
    //         $session = new Session();
    //         $session->user1 = auth()->user()->id;
    //         $session->link = v4();
    //         $session->type = $request["type"];
    //         $session->state = "waiting";
    //         $session->number_of_users = 1;
    //         $session->user1_state = "exist";
    //         $session->save();
    //         return successResponseJson(["data"=>$session,"state"=>"new","user"=>"user1"]);
    //     }
    // }

    // public function updateUserState(Request $request){
    //     $session = Session::find($request["id"]);
    //     $session[$request['user']] = auth()->user()->id;
    //     $session[$request['user']."_state"] = "exist";
    //     $session->save();
    //     return successResponseJson(["data"=>$session]);
    // }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $gameStep = new GameSession();
        $gameStep->session_id = $request["id"];
        $gameStep->from = $request["from"];
        $gameStep->to = $request["to"];
        $gameStep->user = $request["user"];
        $gameStep->type = $request["type"];
        $gameStep->save();
        return successResponseJson(["data"=>$gameStep]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $sessions = GameSession::query()->select("*")->where("session_id",1)->where('id','>',$id)->get();
        return successResponseJson(["data"=>$sessions]);
    }

    public function getNewSteps(Request $request)
    {
        $sessions = GameSession::query()->select("*")->where('id','>',$request["id"])->where("session_id",$request["session_id"])->get();
        return successResponseJson(["data"=>$sessions]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
