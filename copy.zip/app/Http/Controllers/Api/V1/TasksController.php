<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\TaskModel;
use App\Models\User;
use App\Models\UserDoneTask;
use App\Models\UserPoint;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;

class TasksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tasks = TaskModel::all();
        if(count($tasks) == 0){
            return errorResponseJson(['data' => null], 204 , "لا توجد روابط لجلبها");
        }

        return successResponseJson(["data"=>$tasks]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->except("_token");
        
        $user = User::find(auth()->user()->id);
        if($data["type"] != "ROLL"){
            if($data["type"] == "TASK")
                $user->last_task = date('Y-m-d H:i:s');
            $taskDone = new UserDoneTask();
            $taskDone->user = auth()->user()->id;
            $taskDone->date =  date('Y-m-'.($request->number).' H:i:s');
            $taskDone->type = $data["type"];
            $taskDone->save();
        }else if( $data["type"] == "ROLL"){
            $taskDone = new UserDoneTask();
            $taskDone->user = auth()->user()->id;
            $taskDone->date =  date('Y-m-'.($request->number).' H:i:s');
            $taskDone->type = $data["type"];
            $taskDone->save();
            if(date('Y-m-d') == date_format(Carbon::parse($user->roll_date ?? date('Y-m-d H:i:s')),"Y-m-d")){
                $user->roll_count = $user->roll_count + 1;
            }
            else{
                $user->roll_count = 1;
                $user->roll_date = date('Y-m-d H:i:s');
            }
        }
        $lastTask = date_format(Carbon::parse($user->last_task ?? date('Y-m-d H:i:s')),"d");

        $user->xp_points = $data["xp_points"] + ($user->xp_points ?? 0);
        $user->win_points = $data["win_points"] + ($user->win_points ?? 0);
        if($data["win_points"] > 0){
            $point = new UserPoint();
            $point->user_id = auth()->user()->id;
            $point->type = $data["type"];
            $point->points = $data["win_points"];
            $point->compitetion_number = $data["compitetion_number"];
            $point->compitetion_id = $data["compitetion_id"];
            $point->compitetion_start_date = $data["compitetion_start_date"];
            $point->compitetion_end_date = $data["compitetion_end_date"];
            $point->save();
        }
        $user->save();
        $user = User::find(auth()->user()->id);
        $response['last_task'] = $lastTask;
        $response['roll_count'] = $user->roll_count;
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$response
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
