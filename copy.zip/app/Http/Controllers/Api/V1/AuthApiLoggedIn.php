<?php
namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Http\Resources\Users;
use App\Models\User;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
class AuthApiLoggedIn extends Controller {

	public function __construct() {
		$this->middleware(['jwt.user:users'], ['except' => ['login']]);
		auth()->setDefaultDriver('client');
		config()->set( 'auth.defaults.guard', 'client' );
		config()->set('jwt.user', 'App\Models\User'); 
		config()->set('auth.providers.users.model', \App\Models\User::class);
	}


	public function login() {
		$validation = Validator::make(request()->all(),[ 
			'phone' => 'required|min:8',
			'password' => 'required',
			'contry_id' => 'required'
		]);
	
		if($validation->fails()){
			return errorResponseJson(['data' =>  $validation->errors()] ,203 ,trans('admin.error_loggedin'));	
		}
		
		
			$credentials = request(['phone', 'password' , 'contry_id']);
			$token = Auth::guard("client")->attempt($credentials);
			
	

		if (!$token) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		$user  = Auth::guard("client")->user();

		$users = array([
			'id' => $user->id,
			'name' => $user->name,
			'phone' => $user->phone,
			'email' => $user->email ?? null,
			'contry_id' => $user->contry_id,
			'token' => $this->respondWithToken($token)['token'],
			'token_type' => $this->respondWithToken($token)['token_type'],
		]);
		$data =  Users::collection($users);
		return successResponseJson(['data' =>$data],trans('admin.loginsuccess'));
	}


	public function me() {
		$user  = Auth::guard("client")->user();
		if (!$user) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		if (! empty( request()->fcm_token)  || request()->has('fcm_token') )  {
			$user->fcm_token = request()->fcm_token;
			$user->update();
		}
		if (! empty( request()->notafications_status)  || request()->has('notafications_status') )  {
			$user->notafications_status = request()->notafications_status;
			$user->update();
		}
		if (! empty( request()->locations_status)  || request()->has('locations_status') )  {
			$user->locations_status = request()->locations_status;
			$user->update();
		}
		$users = array([
			'id' => $user->id,
			'name' => $user->name,
			'phone' => $user->phone,
			'email' => $user->email ?? null,
			'contry_id' => $user->contry_id,
			'locations_status' => $user->locations_status,
			'notafications_status' => $user->notafications_status,
		]);
		// $data =  Users::collection($users);
		return successResponseJson(['data' =>$users],trans('admin.infosuccess'));
	}

	public function update_profile()
	{
		$user = User::find(Auth::guard("client")->user()->id);
		// $user->id = Auth::guard("client")->user()->id;
		if (request()->name  || request()->name != null ) {
			$user->name = request()->name;

		} 
		if (request()->phone  || request()->phone != null ) {
			$user->phone = request()->phone;

		} 
		if (request()->contry_id  || request()->contry_id != null ) {
			$user->contry_id = request()->contry_id;

		} 
		if (request()->password  || request()->password != null ) {
			$user->password = \Hash::make(request()->password);

		} 
		if (request()->fcm_token  || request()->fcm_token != null ) {
			$user->fcm_token = request()->fcm_token;

		} 
		$user->update();
		return successResponseJson(['data' =>true],trans('admin.Updatesuccessfully'));



	}
	

	public function logout() {
		Auth::guard("client")->logout();
		return successResponseJson(['data' =>true],trans('admin.logoutsuccess'));
	}

	public function refresh() {
		return successResponseJson(['data' =>$this->respondWithToken( Auth::guard("client")->refresh())],trans('admin.updatetokensuccess'));
		// return successResponseJson(['data' =>  ]);
	}
	protected function respondWithToken($token) {
		return [
			'token' => $token,
			'token_type'   => 'bearer',
		];
	}
	function generatePIN($digits = 4){
        $i = 0; //counter
        $pin = ""; //our default pin is blank.
        while($i < $digits){
            //generate a random number between 0 and 9.
            $pin .= mt_rand(0, 9);
            $i++;
        }
        return (int)$pin;
   }

}