<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Doctor;
use App\FcmNotification;
use Validator;
class Notification extends Controller{
    public function store()
    {
        $validation = Validator::make(request()->all(),[ 
			'users' => 'required|string',
			'title' => 'required|min:10',
			'body' => 'required|min:10',
            'type' => 'required|in:doctor,user',

		]);
	
		if($validation->fails()){

			if(count($validation->errors()) > 0 ) {
				$erorrs = $validation->errors();

				foreach($erorrs->all() as $item) {
				return errorResponseJson(['data' => $erorrs->all()]  ,203 ,$item);	

				}
			}
		}
        if (request()->type == "user") {
            // get all token users
            $tokens = User::whereIn('phone', json_decode(request()->users))->pluck('fcm_token')->all();
            $notfiy = FcmNotification::sendNotification($tokens, request()->title ,request()->body);
            return successResponseJson(["data"=> true] , trans("admin.notify_send"));  

        } else {
            // get all token doctor
            $tokens = Doctor::whereIn('doctor_phone', json_decode(request()->users))->pluck('fcm')->all();
            $notfiy = FcmNotification::sendNotification($tokens, request()->title ,request()->body);
            return successResponseJson(["data"=> true] , trans("admin.notify_send"));  

        }
    }
}