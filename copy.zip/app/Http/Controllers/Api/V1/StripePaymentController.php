<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Stripe;

class StripePaymentController extends Controller
{
    public function stripePost(Request $request){
        try{
            
            $stripe = new \Stripe\StripeClient(
                env('STRIPE_SECRET')
            );

            $res = $stripe->tokens->create([
            'card' => [
                'number' => $request->card_number,
                'exp_month' => $request->exp_month,
                'exp_year' => $request->exp_year,
                'cvc' => $request->cvc,
            ],
            ]);

            Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

            $response = $stripe->charges->create([
            'amount' => $request->amount,
            'currency' => 'SAR',
            'source' => $res->id,
            'discription' => $request->discription
            ]);

            return successResponseJson([
                "message"=>trans("admin.added"),
                "data"=>$response
            ]);
        }
        catch(Exception $ex){
            return errorResponseJson(['data' => "Error$ex"], 205);
        }
    }
}
