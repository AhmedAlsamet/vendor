<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Admin\Levels;
use App\Http\Controllers\Controller;
use App\Http\Resources\AppQuestionResource;
use App\Http\Resources\BorderResource;
use App\Http\Resources\ColorResource;
use App\Http\Resources\FontResource;
use App\Http\Resources\FriendResource;
use App\Http\Resources\OurPartnersResource;
use App\Http\Resources\WisdomResource;
use App\Models\AppQuestion;
use App\Models\Border;
use App\Models\Colors;
use App\Models\Compitetion;
use App\Models\Font;
use App\Models\Friend;
use App\Models\GameResult;
use App\Models\Level;
use App\Models\OurPartner;
use App\Models\PaymentSetting;
use App\Models\TaskModel;
use App\Models\TodayWisdom;
use App\Models\User;
use App\Models\UserDoneTask;
use App\Models\UserPoint;
use App\Models\UserQuestionCategory;
use App\Models\UserSell;
use Carbon\Carbon;
use Carbon\CarbonImmutable;
use DateTime;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\DB;
use TomatoPHP\LaravelAgora\Services\Agora;

class AppData extends Controller
{
    public function list_data(){
        $id = auth()->user()->id;
        $today = date('Y-m-d');
        $maxDays=date('t');
        $cureentDay=date('j');
        $borders = BorderResource::collection(Border::all());
        $fonts = FontResource::collection(Font::all());
        $colors = ColorResource::collection(Colors::all());
        // $lines = LineResource::collection(Line::all());

        // $TodayWisdom = WisdomResource::collection(TodayWisdom::where('type',0)->whereDate('start_at',$today)->where('month_wisdom',1)->where('day','!=',null)->get());
        // $goldWisdom = WisdomResource::collection(TodayWisdom::where('type',1)->whereDate('start_at',$today)->where('month_wisdom',1)->where('day','!=',null)->get());
        // $last_wisdoms = WisdomResource::collection(TodayWisdom::orderBy('id','asc')->where('type',0)->orderBy('month_wisdom','asc')->take($cureentDay)->get());
        // $last_hadiths = WisdomResource::collection(TodayWisdom::orderBy('id','asc')->where('type',1)->orderBy('month_wisdom','asc')->take($cureentDay)->get());
        
        // $wisdoms = WisdomResource::collection(TodayWisdom::orderBy('id','desc')->where('type',0)->where("month_wisdom",0)->take($maxDays - $cureentDay)->get());
        // $hadiths = WisdomResource::collection(TodayWisdom::orderBy('id','desc')->where('type',1)->where("month_wisdom",0)->take($maxDays - $cureentDay)->get());
        $wisdoms = WisdomResource::collection(TodayWisdom::orderBy('id','desc')->where('type',0)->orderBy('month_wisdom','asc')->take($maxDays)->get());
        $hadiths = WisdomResource::collection(TodayWisdom::orderBy('id','desc')->where('type',1)->orderBy('month_wisdom','asc')->take($maxDays)->get());
        
        $your_friends = Friend::select("*",
        // 'borders.id as border_id',
        // 'borders.title as border_title',
        // 'borders.title_lat as border_title_lat',
        // 'borders.border_image as border_image',
        // 'borders.price as border_price',
        // 'borders.type as border_type',
        // 'borders.color as border_color',

        // 'fonts.id as font_id',
        // 'fonts.name as font_name',
        // 'fonts.name_lat as font_name_lat',
        // 'fonts.photo as font_photo',
        // 'fonts.price as font_price',
        // 'fonts.link as font_link',
        
        'friends.id','friends.created_at','friends.updated_at')
        ->join('users', 'users.id', '=', 'friends.user_friend_id')
        // ->leftJoin('borders', 'borders.id', '=', 'users.border_id')
        // ->leftJoin('fonts', 'fonts.id', '=', 'users.font_id')
        ->where("state","REAL")
        ->where("user_id",$id)
        ->orWhere("user_friend_id",$id)->get();

        for ($i = 0 ;$i < count($your_friends); $i++) {
            if($your_friends[$i]["user_friend_id"] == $id){
                $u = User::find($your_friends[$i]["user_id"]);
                $your_friends[$i]['name'] = $u['name'];
                $your_friends[$i]['gender'] = $u['gender'];
                $your_friends[$i]['phone'] = $u['phone'];
                $your_friends[$i]['email'] = $u['email'] ?? null;
                $your_friends[$i]["border_id"] = $u->border_id;
                $your_friends[$i]["font_id"] = $u->font_id;
            }
            $your_friends[$i]->border = Border::find($your_friends[$i]["border_id"]);
            $your_friends[$i]->font = Font::find($your_friends[$i]["font_id"]);
        }
        $your_friends = FriendResource::collection($your_friends);

        $your_recive_orders = Friend::select("*",
        // 'borders.id as border_id',
        // 'borders.title as border_title',
        // 'borders.title_lat as border_title_lat',
        // 'borders.border_image as border_image',
        // 'borders.price as border_price',
        // 'borders.type as border_type',
        // 'borders.color as border_color',

        // 'fonts.id as font_id',
        // 'fonts.name as font_name',
        // 'fonts.name_lat as font_name_lat',
        // 'fonts.photo as font_photo',
        // 'fonts.price as font_price',
        // 'fonts.link as font_link',
        
        'friends.id','friends.created_at','friends.updated_at')
        ->join('users', 'users.id', '=', 'friends.user_id')
        // ->leftJoin('borders', 'borders.id', '=', 'users.border_id')
        // ->leftJoin('fonts', 'fonts.id', '=', 'users.font_id')
        ->where("state","ORDER")
        ->where("user_friend_id",$id)->get();

        for ($i = 0 ;$i < count($your_recive_orders); $i++) {
            $u = User::find($your_recive_orders[$i]["user_id"]);
            $your_recive_orders[$i]["border_id"] = $u->border_id;
            $your_recive_orders[$i]["font_id"] = $u->font_id;
            $your_recive_orders[$i]->border = Border::find($your_recive_orders[$i]["border_id"]);
            $your_recive_orders[$i]->font = Font::find($your_recive_orders[$i]["font_id"]);
        }
        $your_recive_orders = FriendResource::collection($your_recive_orders);

        $your_send_orders = Friend::select("*",
        // 'borders.id as border_id',
        // 'borders.title as border_title',
        // 'borders.title_lat as border_title_lat',
        // 'borders.border_image as border_image',
        // 'borders.price as border_price',
        // 'borders.type as border_type',
        // 'borders.color as border_color',

        // 'fonts.id as font_id',
        // 'fonts.name as font_name',
        // 'fonts.name_lat as font_name_lat',
        // 'fonts.photo as font_photo',
        // 'fonts.price as font_price',
        // 'fonts.link as font_link',
        
        'friends.id','friends.created_at','friends.updated_at')
        ->join('users', 'users.id', '=', 'friends.user_friend_id')
        // ->leftJoin('borders', 'borders.id', '=', 'users.border_id')
        // ->leftJoin('fonts', 'fonts.id', '=', 'users.font_id')
        ->where("state","ORDER")
        ->where("user_id",$id)->get();

        for ($i = 0 ;$i < count($your_send_orders); $i++) {
            $u = User::find($your_send_orders[$i]["user_friend_id"]);
            $your_send_orders[$i]["border_id"] = $u->border_id;
            $your_send_orders[$i]["font_id"] = $u->font_id;
            $your_send_orders[$i]->border = Border::find($your_send_orders[$i]["border_id"]);
            $your_send_orders[$i]->font = Font::find($your_send_orders[$i]["font_id"]);
        }
        $your_send_orders = FriendResource::collection($your_send_orders);

        $tasks = TaskModel::all();
        $lastTask = date_format(Carbon::parse(auth()->user()->last_task  ?? Carbon::now() ),"d");
        if(auth()->user()->last_task == null || date('m') != date_format(Carbon::parse(auth()->user()->last_task ?? Carbon::now()),"m")){
            $lastTask = 0;
        }
        
        $rollCount = auth()->user()->roll_count;
        if(date('Y-m-d') != date_format(Carbon::parse(auth()->user()->roll_date ?? Carbon::now()),"Y-m-d")){
            $rollCount = 0;
        }

        $user = User::find($id);
        $userPreferncees = UserQuestionCategory::query()->select("question_category_id")->where("user_id",$id)->get();
        $temp = [];
        for ($i=0; $i < count($userPreferncees); $i++) { 
            $temp[$i]= $userPreferncees[$i]["question_category_id"];
        }
        $user->preferncees = array_values($temp);

        $done_tasks = UserDoneTask::query()->whereBetween("date",[date('Y-m-')."01",date('Y-m-').$maxDays])->get();
        
        $compitetion = Compitetion::query()
        ->where(function ($query){
            $date = date('Y-m-d H:i:s');
                $query->where("start_date","<",$date)
                ->where("end_date",">=",$date); 
        })->orWhere("frequency","LOOP")->get()->first();

        // $datetime1 = new DateTime($compitetion->created_at);
        // $datetime2 = new DateTime(Carbon::now());
        // $interval = $datetime1->diff($datetime2);
        $now = Carbon::parse(date('Y-m-d H:i:s'));
        if(Carbon::parse($compitetion->start_date)->addDays($now->diffInDays($compitetion->created_at)) > $now){
            $now->subDays(1);
        }
        $compitetion->start_date = Carbon::parse($compitetion->start_date)->addDays($now->diffInDays($compitetion->created_at));
        $compitetion->number = $now->diffInDays($compitetion->created_at);
        $now->addDay();
        $compitetion->end_date = Carbon::parse($compitetion->end_date)->addDays($now->diffInDays($compitetion->created_at));
        // $data['test'] = date_format(auth()->user()->last_task ?? Carbon::now(),"m");

        $user->win_points = DB::table('user_points')
            ->where('compitetion_number',$compitetion->number)
            ->where('compitetion_id', $compitetion->id)
            ->where('compitetion_start_date', $compitetion->start_date->formatLocalized("%Y-%m-%d"))
            ->where('compitetion_end_date', $compitetion->end_date->formatLocalized("%Y-%m-%d"))
            ->where('user_id', $id)
            ->pluck(DB::raw('IFNULL(SUM(points),0)'))[0];

        $single_play_count = DB::table('sessions')
            ->where('type','tow_comp')
            ->where('compitetion_number',$compitetion->number)
            ->where('compitetion_id', $compitetion->id)
            ->where('compitetion_start_date', $compitetion->start_date->formatLocalized("%Y-%m-%d"))
            ->where('compitetion_end_date', $compitetion->end_date->formatLocalized("%Y-%m-%d"))
            ->where(function ($query) use($id){
                $query->where('user1', $id)
                ->orWhere("user2",$id) 
                ->orWhere("user3",$id) 
                ->orWhere("user4",$id); 
            })
            ->pluck(DB::raw('COUNT(id)'))[0];

        $four_play_count = DB::table('sessions')
            ->where('type','four_comp')
            ->where('compitetion_number',$compitetion->number)
            ->where('compitetion_id', $compitetion->id)
            ->where('compitetion_start_date', $compitetion->start_date->formatLocalized("%Y-%m-%d"))
            ->where('compitetion_end_date', $compitetion->end_date->formatLocalized("%Y-%m-%d"))
            ->where(function ($query) use($id){
                $query->where('user1', $id)
                ->orWhere("user2",$id) 
                ->orWhere("user3",$id) 
                ->orWhere("user4",$id); 
            })
            ->pluck(DB::raw('COUNT(id)'))[0];

        $game_play_count = DB::table('sessions')
            ->where('type','game')
            ->where('compitetion_number',$compitetion->number)
            ->where('compitetion_id', $compitetion->id)
            ->where('compitetion_start_date', $compitetion->start_date->formatLocalized("%Y-%m-%d"))
            ->where('compitetion_end_date', $compitetion->end_date->formatLocalized("%Y-%m-%d"))
            ->where(function ($query) use($id){
                $query->where('user1', $id)
                ->orWhere("user2",$id) 
                ->orWhere("user3",$id) 
                ->orWhere("user4",$id); 
            })
            ->pluck(DB::raw('COUNT(id)'))[0];
         
        $compitetion->secounds = ($compitetion->end_date->diffInSeconds($compitetion->start_date)) - ($compitetion->start_date->diffInSeconds(Carbon::now()));
        $compitetion->start_date = $compitetion->start_date->formatLocalized("%Y-%m-%d %H:%M:%S");
        $compitetion->end_date = $compitetion->end_date->formatLocalized("%Y-%m-%d %H:%M:%S");
        
        $user->level = Level::all()->where("points",">=",$user->xp_points)->first()->name;
        
        // if($user->win_points == 0){
        //     $user->win_points = 0;
        // }

        if($user->border_id != 0){
            $user->border = Border::find($user->border_id);
        }
        if($user->color_id != 0){
            $user->color = Colors::find($user->color_id);
        }
        if($user->font_id != 0){
            $user->font = Font::find($user->font_id);
        }

        $payment = PaymentSetting::all()->first();

        $sells = UserSell::query()->select("*")->where("user_id",$id)->get();

        $data['single_play_count'] = $single_play_count;
        $data['four_play_count'] = $four_play_count;
        $data['game_play_count'] = $game_play_count;
        $data['sells'] = $sells;
        $data['payment'] = $payment;
        $data['compitetion'] = $compitetion;
        $data['user'] = $user;
        $data['max_days'] = $maxDays;
        $data['cureent_date'] = $cureentDay;
        $data['last_task'] = $lastTask;
        $data['roll_count'] = $rollCount;
        $data['borders'] = $borders;
        $data['fonts'] = $fonts;
        $data['colors'] = $colors;
        $data['wisdoms'] = $wisdoms ;
        $data['hadiths'] = $hadiths ;
        // $data['last_wisdoms'] = $last_wisdoms;
        // $data['last_hadiths'] = $last_hadiths;
        $data['your_friends'] = $your_friends;
        $data['your_recive_orders'] = $your_recive_orders;
        $data['your_send_orders'] = $your_send_orders;
        $data['tasks'] = $tasks;
        $data['done_tasks'] = $done_tasks;
        $data['date'] = $today;
        return response()->json(['success'=>true,'data'=>$data, 'message'=>'Success', 'code'=>200]);
    }

    public function app_questions(){
        $appQuestions = AppQuestionResource::collection(AppQuestion::all());
        return response()->json(['success'=>true,'data'=>$appQuestions, 'message'=>'Success', 'code'=>200]);
    }
    public function our_partners(){
        $ourPartners = OurPartnersResource::collection(OurPartner::all());
        return response()->json(['success'=>true,'data'=>$ourPartners, 'message'=>'Success', 'code'=>200]);
    }

    public function new_token(){
        $ourPartners = Agora::make(id: request()->id)->uId(0)->channel('game')->token();
        // $ourPartners = Agora::make(id: 1)->uId(rand(999, 1999))->token();
        return response()->json(['success'=>true,'token'=>$ourPartners]);
    }
    public function done_tasks(){
        $maxDays=date('t');
        $done_tasks = UserDoneTask::query()->whereBetween("date",[date('Y-m-')."01",date('Y-m-').$maxDays])->get();
        // $ourPartners = Agora::make(id: 1)->uId(rand(999, 1999))->token();
        return response()->json(['success'=>true,'data'=>$done_tasks]);
    }

    public function winners(){
        $winners = 
        DB::table('user_points')
        // UserPoint::all()
        // ->where("user_id",$id)
        // ->where("compitetion_id",request()['compitetion_id'])
        ->where("compitetion_start_date",Carbon::parse(request()['compitetion_start_date'])->formatLocalized("%Y-%m-%d"))
        ->where("compitetion_end_date",Carbon::parse(request()['compitetion_end_date'])->formatLocalized("%Y-%m-%d"))
        ->groupBy('user_id')
        ->get(["user_id",DB::raw('IFNULL(SUM(points),0) AS win_points')]);
        
        for ($i=0; $i < count($winners); $i++) { 
            $winners[$i]->user = User::find($winners[$i]->user_id);
            $id = $winners[$i]->user->id;

            // if($winners[$i]->user->border_id != 0){
            //     $winners[$i]->user->border = Border::find($winners[$i]->user->border_id);
            // }
            // if($winners[$i]->user->color_id != 0){
            //     $winners[$i]->user->color = Colors::find($winners[$i]->user->color_id);
            // }
            if($winners[$i]->user->font_id != 0){
                $winners[$i]->user->font = Font::find($winners[$i]->user->font_id);
            }
            $winners[$i]->win_count = 
            // GameResult::all()
            DB::table('game_results')
            ->where(function ($query) use($id){
                $query->where("user_win1",$id)
                ->orWhere("user_win2",$id); 
            })
            ->where("type","game")
            ->where("compitetion_start_date",Carbon::parse(request()['compitetion_start_date'])->formatLocalized("%Y-%m-%d"))
            ->where("compitetion_end_date",Carbon::parse(request()['compitetion_end_date'])->formatLocalized("%Y-%m-%d"))
            ->get(DB::raw('COUNT(id) as val'))[0]->val;
            $winners[$i]->loss_count = 
            // GameResult::all()
            DB::table('game_results')
            ->where(function ($query) use($id){
                $query->where("user_loss1",$id)
                ->orWhere("user_loss2",$id); 
            })
            ->where("type","game")
            ->where("compitetion_start_date",Carbon::parse(request()['compitetion_start_date'])->formatLocalized("%Y-%m-%d"))
            ->where("compitetion_end_date",Carbon::parse(request()['compitetion_end_date'])->formatLocalized("%Y-%m-%d"))
            ->get(DB::raw('COUNT(id) as val'))[0]->val;
        }
        
        return response()->json(['success'=>true,'data'=>$winners]);
    }
}
