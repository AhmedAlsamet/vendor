<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Bidder;
use App\Models\Auction;
use App\Models\User;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\BiddersRequest;
use App\FcmNotification;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class BiddersApi extends Controller{
    private function auth() {
		return auth()->guard('api');
	}
	protected $selectColumns = [
		"id",
		"bidder_auction",
		"bidder_user_id",
		"bidder_price",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return ['bidder_auction.auction_animal','bidder_user_id',];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
            	$Bidder = Bidder::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->paginate(15);
               return successResponseJson(["data"=>$Bidder]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(BiddersRequest $request)
    {
    	$data = $request->except("_token");
        $data["bidder_user_id"] = auth()->guard('api')->user()->id;
        $Auction = Auction::find($data["bidder_auction"]);
        if(is_null($Auction) || empty($Auction)){
            return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));
        }
        // dd($Auction['auction_opening_price'] , $data["bidder_price"] , $Auction['auction_opening_price'] > $data["bidder_price"]);
        
        // auction_status done
        if ($Auction['auction_status'] == "done") {
            return errorResponseJson(['data' => null], 203 ,trans("admin.Auction_has_ended"));
        }

        // auction_opening_price > price 
        if ($Auction['auction_opening_price'] > $data["bidder_price"]) {
            return errorResponseJson(['data' => null], 203 ,trans("admin.price_lower_than"));
        }
        



        $max_price = Bidder::where("bidder_auction" , $data["bidder_auction"])->max('bidder_price');
        // max number 
        // dd((int)$max_price ,  (int)$data["bidder_price"] < (int)$max_price , (int)$data["bidder_price"] );
        if ($max_price >= $data["bidder_price"]) {
            return errorResponseJson(['data' => null], 203 ,trans("admin.max_price"));
        }
        // dd( $Auction['auction_opening_price'] < $data["bidder_price"] ,$Auction);        

        // price > start price 

        
        $Bidder = Bidder::create($data);
        $tokens = User::where('id', $Auction->animal->animal_user_id)->pluck('fcm_token')->all();
        $title = trans("admin.title_notifations");
        $body  = trans('admin.new_bidder');
        $notfiy = FcmNotification::sendNotification($tokens, $title ,$body);


		  $Bidder = Bidder::with($this->arrWith())->find($Bidder->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$Bidder
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Bidder = Bidder::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Bidder) || empty($Bidder)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Bidder
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new BiddersRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(BiddersRequest $request,$id)
            {
            	$Bidder = Bidder::find($id);
            	if(is_null($Bidder) || empty($Bidder)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Bidder::where("id",$id)->update($data);

              $Bidder = Bidder::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Bidder
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $bidders = Bidder::find($id);
            	if(is_null($bidders) || empty($bidders)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("bidder",$id);

               $bidders->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $bidders = Bidder::find($id);
	            	if(is_null($bidders) || empty($bidders)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("bidder",$id);
                    	$bidders->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $bidders = Bidder::find($data);
	            	if(is_null($bidders) || empty($bidders)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	it()->delete("bidder",$data);

                    $bidders->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}