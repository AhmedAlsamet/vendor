<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ActiveClassResource;
use App\Http\Resources\MyPackageResource;
use App\Http\Resources\PackageBorderAdsResource;
use App\Http\Resources\PackageGoldWisdomResource;
use App\Http\Resources\PackageLineResource;
use App\Http\Resources\PackageTodayWisdomResource;
use App\Http\Resources\PackageWithOutAdsResource;
use App\Http\Resources\SocialResource;
use App\Models\AddPackage;
use App\Models\Package;
use App\Models\PaymentSetting;
use App\Models\Social;
use Illuminate\Http\Request;
use Validator;
class PackageApi extends Controller
{
   public function list_packages(){

        $packageWithOutAds = PackageWithOutAdsResource::collection(Package::where('type',1)->get());
        $packagesBorder = PackageBorderAdsResource::collection(Package::where('type',2)->get());
        $PackageLine = PackageLineResource::collection(Package::where('type',3)->get());
        $PackageGoldWisdomResource = PackageGoldWisdomResource::collection(Package::where('type',4)->get());
        $social = SocialResource::collection(Social::orderBy('id', 'DESC')->get());
        $data['packageWithOutAds'] = $packageWithOutAds;
        $data['packagesBorder'] = $packagesBorder;
        $data['PackageLine'] = $PackageLine;
        $data['PackageGoldWisdomResource'] = $PackageGoldWisdomResource;
        $data['social'] = $social;
        return response()->json(['success'=>true,'data'=>$data, 'message'=>'Success', 'code'=>200]);
   }
   public function add_package(Request $request){
        $validation = Validator::make(request()->all(),[

            'package' => 'required',

        ]);

        if($validation->fails()){

            if(count($validation->errors()) > 0 ) {
                $erorrs = $validation->errors();

                foreach($erorrs->all() as $item) {
                return errorResponseJson(['data' => $erorrs->all()]  ,203 ,$item);

                }
            }
        }
        $package = Package::find($request->package);
        if($package == Null){
            return response()->json(['success' => false,  'message'=>'This Package Not Found Or This ID Not Correct', "code"=>200],200);
        }
        $today =  date('Y-m-d');
        $add_package = AddPackage::where('type',$package->type)->where('user',auth('api')->user()->id)->whereDate('expired','>',$today)->where('approve',1)->first();

        if($add_package == Null){
            // return response()->json(['success' => false,  'message'=>'باقتك الحالية لم تنتهى ', "code"=>200],200);
            $add_package = new AddPackage();
        }
        $add_package->user = auth('api')->user()->id;
        $add_package->package = $package->id;
        $add_package->type = $package->type;
        $add_package->for_ever = $package->for_ever;
        $add_package->approve = 1;
        $days =date("Y-m-d", strtotime("$today +$package->days day"));
        $add_package->expired = $days;

        $add_package->save();
        return response()->json(['success' => true, 'message'=>'تمت الاضافه بنجاح', 'code'=>200]);

        // return response()->json(['success' => true, 'payment_url'=> url('payment/index/'.$add_package->id), 'code'=>200]);


   }
   public function my_package(){
        $data = MyPackageResource::collection(AddPackage::where('user',auth('api')->user()->id)->where('approve',1)->get());
        return response()->json(['success'=>true,'data'=>$data, 'message'=>'Success', 'code'=>200]);

    }
    public function active_class(){
        $data = new ActiveClassResource(PaymentSetting::first());
        return response()->json(['success'=>true,'data'=>$data, 'message'=>'Success', 'code'=>200]);

    }

}
