<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Favorite;
use App\Models\Animal;

use Validator;

use App\Http\Controllers\ValidationsApi\V1\FavoritesRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class FavoritesApi extends Controller{
	protected $selectColumns = [
		"favorite_user_id",
		"favorite_type_id",
	];

    protected $selectColumnsAnimal = [
		"animals.id",
		"animals.animal_name_ar",
		"animals.animal_name_en",
		"animals.animal_price",
		"animals.animal_photo",
		"animals.animal_gender",
		"animals.animal_phone",
		"animals.animal_type",
		"animals.animal_area",
		"animals.animal_city",
		"animals.animal_latitude",
		"animals.animal_longitude",
		"animals.animal_details",
		"animals.animal_user_id",
		"animals.animal_catagory",
    'animals.animal_day',
    'animals.animal_month',
    'animals.animal_year',
    'animals.animal_weight',
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return ['favorite_type_id'];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
                $Animal = Animal::select($this->selectColumnsAnimal)
                ->join('favorites' , "favorites.favorite_type_id" , "=", "animals.id")
                ->where("favorites.favorite_user_id" ,auth()->guard('api')->user()->id)
                ->with(['animal_type','animal_area','animal_city','animal_user_id','animal_catagory','images' ,'auction' ])->get();
                return successResponseJson([
                    "data"=> $Animal ?? []
                    ]); 
            // 	$Favorite = Favorite::with($this->arrWith())->orderBy("id","desc")->where("favorite_user_id" ,auth()->guard('api')->user()->id )->get();
            //    return successResponseJson(["data"=>$Favorite]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(FavoritesRequest $request)
    {
    	$data = $request->except("_token");
        $data["favorite_user_id"] = auth()->guard('api')->user()->id;
        $chack = Favorite::where($data)->first();
        if($chack != null) {
			return errorResponseJson(['data' => null ] ,203 ,trans('admin.Favoriteisexist'));	
        }
        $Favorite = Favorite::create($data); 

        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>true
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Favorite = Favorite::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Favorite) || empty($Favorite)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Favorite
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new FavoritesRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(FavoritesRequest $request,$id)
            {
            	$Favorite = Favorite::find($id);
            	if(is_null($Favorite) || empty($Favorite)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Favorite::where("id",$id)->update($data);

              $Favorite = Favorite::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Favorite
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {

                $Favorite = Favorite::where([ 
                    "favorite_user_id" => auth()->guard('api')->user()->id,
                    "favorite_type_id" => $id
                 ])->first();
   
                 if(is_null($Favorite) || empty($Favorite)){
                    return errorResponseJson(['data' => false] ,203 ,trans('admin.undefinedRecord'));
                 }
                 $Favorite->delete();
                 return successResponseJson(['data' =>true],trans('admin.deleted'));


            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $favorites = Favorite::find($id);
	            	if(is_null($favorites) || empty($favorites)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("favorite",$id);
                    	$favorites->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $favorites = Favorite::find($data);
	            	if(is_null($favorites) || empty($favorites)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	it()->delete("favorite",$data);

                    $favorites->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}