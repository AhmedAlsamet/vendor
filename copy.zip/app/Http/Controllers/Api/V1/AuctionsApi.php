<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Auction;
use App\Models\Bidder;
use App\Models\User;

use App\FcmNotification;

use Validator;
use App\Http\Controllers\ValidationsApi\V1\AuctionsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class AuctionsApi extends Controller{
	public function __construct() {
		$this->middleware('jwt.user:users');
		auth()->setDefaultDriver('api');
		config()->set( 'auth.defaults.guard', 'api' );
		config()->set('jwt.users', 'App\Models\User'); 
		config()->set('auth.providers.doctors.model', \App\Models\User::class);
	}
	protected $selectColumns = [
		"id",
		"auction_animal",
		"auction_opening_price",
		"auction_end_price",
        "auction_status"
	];


            public function arrWith(){
               return ['auction_animal',];
            }



            public function index()
            {
            	$ِAuction =Auction::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->get();
               return successResponseJson(["data"=>$ِAuction]);
            }



    public function store(AuctionsRequest $request)
    {
    	$data = $request->except("_token");

        $ِAuction =Auction::create($data); 

		  $ِAuction =Auction::with($this->arrWith())->find($ِAuction->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$ِAuction
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function endAuction($id)
            {
                $Auction = Auction::find($id,$this->selectColumns);
                $max_price = Bidder::where("bidder_auction" , $id)->max('bidder_price');

            	if(is_null($Auction) || empty($Auction)){

                 return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

            	}
                if ($Auction->animal->animal_user_id != auth()->user()->id ) {
                    return errorResponseJson(['data' => null], 203 ,trans("admin.This_user_does_not_have_permissions"));
                }
                
            	if(is_null($max_price ) || empty($max_price)){
                    return errorResponseJson(['data' => null], 203 ,trans("admin.There_are_no_more_bids_on_the_auction"));
                }
                // max_price 

                //send notifications
                $max_user_bidder = Bidder::where(["bidder_auction" => $id,'bidder_price' => $max_price])->first();
                $tokens = User::where('id', $max_user_bidder->bidder_user_id)->pluck('fcm_token')->all();

                $title = trans("admin.title_notifations");
                $body  = trans('admin.Your_account_has_bee_successfully_activated');
                $notfiy = FcmNotification::sendNotification($tokens, $title ,$body);

                //  max price  |  updete price 
                $Auction->auction_status = "done";
                $Auction->auction_end_price = $max_price;
                $Auction->save();

                 return successResponseJson([
              "data"=> $Auction
              ] , trans("admin.auctionEnd"));  
            }


            public function maxPriceAuction($id)
            {
                $Auction = Auction::find($id);
            	if(is_null($Auction) || empty($Auction)){
                 return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));
            	}
                $bidders = Bidder::where(["bidder_auction" => $id])->max('bidder_price');
                $date = Bidder::where(["bidder_auction" =>  $id , 'bidder_price' => $bidders])->first();
                
                $allData = array([
                    "max_price" => $bidders,
                    "user_data" => $date->user?? null
                ]);
                return successResponseJson(['data' => $allData],trans('admin.MaxpriceDatasuccessfully'));


            }


            public function show($id)
            {
                $ِAuction =Auction::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($ِAuction) || empty($ِAuction)){
                    return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

            	}

                 return successResponseJson([
              "data"=> $ِAuction
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new AuctionsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(AuctionsRequest $request,$id)
            {
            	$ِAuction =Auction::find($id);
            	if(is_null($ِAuction) || empty($ِAuction)){
                    return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

  			       }

            	$data = $this->updateFillableColumns();
                 
             Auction::where("id",$id)->update($data);

              $ِAuction =Auction::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $ِAuction
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $auctions =Auction::find($id);
            	if(is_null($auctions) || empty($auctions)){
                    return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

            	}


               it()->delete("ِauction",$id);

               $auctions->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $auctions =Auction::find($id);
	            	if(is_null($auctions) || empty($auctions)){
                        return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

	            	}

                    	it()->delete("ِauction",$id);
                    	$auctions->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $auctions =Auction::find($data);
	            	if(is_null($auctions) || empty($auctions)){
                        return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));

	            	}
 
                    	it()->delete("ِauction",$data);

                    $auctions->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}