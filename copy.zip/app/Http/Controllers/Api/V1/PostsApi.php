<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Post;
use App\Models\Question;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\PostsRequest;
use App\Models\AddPackage;
use App\Models\Compitetion;
use App\Models\Package;
use App\Models\PostDetails;
use Illuminate\Support\Facades\DB;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class PostsApi extends Controller{
	protected $selectColumns = [
		"posts.id",
		"posts.user_id",
        "posts.time",
        "posts.created_at"
	];

    protected function getSelectString()
    {
        return "posts.id,posts.user_id,posts.time,posts.mark,posts.created_at,(select count(*) from posts p where id<=posts.id and compitetion_id=compitetions.id) as index_count";
    }

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return ['user_id'];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
                  $compitetions = Compitetion::where('start_date','<=',now())
                    ->where('end_date','>=',now())->first();
                    $today = Carbon::now()->format('Y-m-d');
                    if ( $compitetions == null) {
                        return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقات اليوم");
                    }elseif($today == date('Y-m-d', strtotime($compitetions->end_date))){
                        return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقات اليوم");
                    }
                   $Post = Post::join('compitetions', 'compitetions.id', '=', 'posts.compitetion_id')->selectRaw($this->getSelectString())->with($this->arrWith())
                     ->where('compitetion_id',$compitetions->id)
                ->orderBy("mark","DESC")->orderBy("time","ASC")->orderBy("id","ASC")->get();

                $lines = array();
                $colors = array();
                $today =  date('Y-m-d');
              foreach($Post as $posts)
              {
                    $fonts = AddPackage::where('type',3)->where('user',$posts->user_id)->where('approve',1)->first();

                    if($fonts !== Null)
                    {
                        if($fonts->for_ever == 0){

                            // this package not forever
                            if($fonts->expired > $today){

                                $package = Package::find($fonts->package);

                                if($package !== Null){
                                    $lines []= array('id'=> optional($package->line_info)->id ?? null);

                                }else{
                                    $lines [] = array('id'=>null);
                                }
                            }
                        }else{

                            $package = Package::find($fonts->package);

                                if($package !== Null){
                                    $lines []= array('id'=> optional($package->line_info)->id ?? null);

                                }else{
                                    $lines [] = array('id'=>null);
                                }
                        }

                    }else{
                        // no package found
                                $lines [] = array('id'=>null);

                    }


                $borders = AddPackage::where('type',2)->where('user',$posts->user_id)->where('approve',1)->first();

                    if($borders !== Null){
                        if($borders->for_ever == 0){
                            // this package not forever
                            if($borders->expired > $today){
                                $package = Package::find($borders->package);
                                if($package !== Null){
                                    $colors []= array('id'=> optional($package->border_info)->color ?? null);

                                }else{
                                    $colors [] = array('id'=>null);
                                }
                            }
                        }else{
                            $package = Package::find($fonts->package);
                                if($package !== Null){
                                    $colors []= array('id'=> optional($package->border_info)->color ?? null);

                                }else{
                                    $colors [] = array('id'=>null);
                                }
                        }

                    }else{
                        // no package found
                        $colors [] = array('id'=>null);
                    }


          }

                // dd(Post::whereDate('created_at', Carbon::today())->get());
                return successResponseJson(["data"=>$Post,'ines'=>$lines,'colors'=>$colors]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */

    private function auth() {
		return auth()->guard('api');
    }
    public function store(PostsRequest $request)
    {

        $qestion_id =  explode(',', $request->qestion_id);

        $mark =  explode(',', $request->mark);
        $time =  explode(',', $request->time);
        if(count($qestion_id) != count($mark) || count($qestion_id) != count($time))
        {

            return errorResponseJson(['data' => 'qestion_id '.count($qestion_id).' mark '.count($mark).' time '.count($time)], 200 , "عدد الاسئلة وعدد االدراجات  وعدد الوقت لا يساوى بعض ");
        }
        $compitetion = Compitetion::find($request->compitetion_id);
        if($compitetion == null){
            return errorResponseJson(['data' => null], 200 , "This ID OF compitetion Not Correct Or Not Found");
        }
        
    	$data = $request->except("_token" , 'answer');
        $posts = Post::whereDate('created_at', Carbon::today())->first();
        $posts = Post::join('compitetions', 'compitetions.id', '=', 'posts.compitetion_id')->select(['posts.*', 'compitetions.start_date', 'compitetions.end_date'])
        ->where('compitetion_id',$compitetion->id)
        ->where('posts.user_id', auth()->user()->id)
        ->first();


        if ( $posts != null) {
            $details = PostDetails::where('post_id',$posts->id)->get()->pluck('qestion_id')->toArray();
            $oneQuestions = Question::whereNotIn("id",$details)->where('compitetion',$compitetion->id)->OrderBy('id','DESC')->get();
            if(count($oneQuestions) == 0){
                return errorResponseJson(['data' => null], 204 , "عفواً! لقدت اجبت علي جميع الاسألة الرجاء الإنتظار المسابقة القادمة");
            }
        }
        DB::beginTransaction();
        try {
                    $new_post = Post::where('compitetion_id',$request->compitetion_id)->where('user_id',auth()->user()->id)->first();
                    if($new_post == null){
                        $new_post = new Post();
                    }else{
                        $count_posts = PostDetails::where('post_id',$new_post)->count();
                        if($count_posts > $compitetion->count_question){
                            return errorResponseJson(['data' => null], 204 , "عفواً! لقدت اجبت علي جميع الاسألة الرجاء الإنتظار المسابقة القادمة");
                        }
                    }
                    $new_post->compitetion_id = $request->compitetion_id;
                    $new_post->user_id = auth()->user()->id;
                    $new_post->save();
                    for($i = 0; $i < count($qestion_id); $i++)
                    {
                        $oneQues = Question::where('id',$qestion_id[$i])->where('compitetion',$request->compitetion_id)->first();
                        $ans = PostDetails::where('post_id',$new_post->id)->where('qestion_id',$qestion_id[$i])->first();
                        if($ans !== null){
                            return errorResponseJson(['data' => null], 202 , "عفواً! لقدت اجبت علي هذا السؤال");
                        }
                        if($oneQues !== null)  {
                            $adp = new PostDetails();
                            $adp->post_id = $new_post->id;
                            $adp->qestion_id = $qestion_id[$i];
                            $adp->mark = $mark[$i];
                            $adp->time = $time[$i];
                            $adp->save();
                            $new_post->mark = $new_post->mark + $mark[$i];

                            $new_post->time = $new_post->time + $time[$i];
                            $new_post->save();
                        }else{
                                return errorResponseJson(['data' => false], 203 , "السؤال غير صحيح او لسه ضمن هذه المسابقه قم بارسال السؤال الصحيح");
                        }
                    }
                    DB::commit();
                    if($mark[0] == 0){
                        return errorResponseJson(['data' => false], 202 , "اجابتك خطا حاول مرة اخرة");

                    }else{

                        return successResponseJson([
                            "data"=> true
                        ] , "مبروك انت الان فى قائمة المرشحين ");
                    }

                // $oneQuestions = Question::where("id",$request->qestion_id)->first();
                // if($oneQuestions)  {
                //     if ($oneQuestions->question_correct_answer ==  $request->answer) {
                //         $Post = Post::create($data);
                //         return successResponseJson([
                //             "data"=> true
                //         ] , "مبروك انت الان فى قائمة المرشحين ");
                //     } else {
                //         return errorResponseJson(['data' => false], 203 , "اجابتك خطا حاول مرة اخرة");
                //     }
                // }


                // return successResponseJson([
                //     "message"=>trans("admin.added"),
                //     "data"=>true
                // ]);
            } catch (\Exception $e) {

                DB::rollback();
                return errorResponseJson(['data' => false], 203 , "حدث خطأ ! حاول فى وقت لاحق", );

            }
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Post = Post::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Post) || empty($Post)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Post
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new PostsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(PostsRequest $request,$id)
            {
            	$Post = Post::find($id);
            	if(is_null($Post) || empty($Post)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();

              Post::where("id",$id)->update($data);

              $Post = Post::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Post
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $posts = Post::find($id);
            	if(is_null($posts) || empty($posts)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("post",$id);

               $posts->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $posts = Post::find($id);
	            	if(is_null($posts) || empty($posts)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("post",$id);
                    	$posts->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $posts = Post::find($data);
	            	if(is_null($posts) || empty($posts)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("post",$data);

                    $posts->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }


}
