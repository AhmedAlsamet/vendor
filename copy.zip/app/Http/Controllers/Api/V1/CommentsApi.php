<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Comment;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\CommentsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class CommentsApi extends Controller{
	protected $selectColumns = [
		"id",
		"comment_user_id",
		"comment_text",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return ['comment_user_id'];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
            	$Comment = Comment::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->paginate(15);
               return successResponseJson(["data"=>$Comment]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(CommentsRequest $request)
    {
    	$data = $request->except("_token");
    	$data['comment_status'] = "pending";
    	$data['comment_user_id'] = auth()->guard('api')->user()->id;
        
        $Comment = Comment::create($data); 

		  $Comment = Comment::with($this->arrWith())->find($Comment->id,$this->selectColumns);
          return successResponseJson(['data' =>$Comment],trans("admin.added"));

    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Comment = Comment::where("comment_animal_id" , $id)->with($this->arrWith())->get();
            	if(is_null($Comment) || empty($Comment)){
                  return errorResponseJson(['data' => null], 203 ,trans("admin.undefinedRecord"));
            	}
               return successResponseJson(['data' =>$Comment]);

            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new CommentsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(CommentsRequest $request,$id)
            {
            	$Comment = Comment::find($id);
            	if(is_null($Comment) || empty($Comment)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Comment::where("id",$id)->update($data);

              $Comment = Comment::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Comment
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $comments = Comment::find($id);
            	if(is_null($comments) || empty($comments)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("comment",$id);

               $comments->delete();
               return successResponseJson(['data' =>true],trans('admin.deleted'));

            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $comments = Comment::find($id);
	            	if(is_null($comments) || empty($comments)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("comment",$id);
                    	$comments->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $comments = Comment::find($data);
	            	if(is_null($comments) || empty($comments)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	it()->delete("comment",$data);

                    $comments->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}