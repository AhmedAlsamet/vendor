<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Sms;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Models\User;
use App\Http\Resources\Users;


class ResetPassword extends Controller {

	public function __construct() {

		// $this->middleware('jwt.user:users');
		auth()->setDefaultDriver('api');
		config()->set( 'auth.defaults.guard', 'api' );
		config()->set('jwt.users', 'App\Models\User');
		config()->set('auth.providers.doctors.model', \App\Models\User::class);
	}

	private function auth() {
		return auth()->guard('api');
	}
	public function checkUser() {
		$data = Validator::make(request()->all(),[
			'phone' => 'required|regex:/(05)[0-9]{8}/',
		]);
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));
		}
        $checkUser = User::wherePhone(request()->phone)->first();
        $code =$this->generatePIN();
        // $code = 1111;
		$message = 'كود التحقق هو : ' . $code;

        Sms::send(request()->phone,$message);

        if ($checkUser || ! empty($checkUser) ) {
			$checkUser->code = $code;
			$checkUser->save();

			return successResponseJson(['data' =>true],"ارسالنا كود الى هاتفك");
        } else {
			return errorResponseJson(['data' => false] ,203 ,"تاكد من كتابه رقم الجوال بشكل صحيح");
        }
	}
    public function newpassword() {
		$data = Validator::make(request()->all(),[
			'phone' => 'required|regex:/(05)[0-9]{8}/',
			'password' => 'required',
		]);
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));
		}
        $checkUser = User::wherePhone(request()->phone)->first();
        if ($checkUser || ! empty($checkUser) ) {

            $checkUser->password =  \Hash::make(request()->password);
            $checkUser->save();
			return successResponseJson(['data' =>true],"تم تحديث كلمة المرور بنجاح");
        } else {
			return errorResponseJson(['data' => false] ,203 ,trans('admin.uploadpassworderrorsuccess'));
        }
	}


	function generatePIN($digits = 4){
        $i = 0; //counter
        $pin = ""; //our default pin is blank.
        while($i < $digits){
            //generate a random number between 0 and 9.
            $pin .= mt_rand(0, 9);
            $i++;
        }
        return (int)$pin;
   }




}
