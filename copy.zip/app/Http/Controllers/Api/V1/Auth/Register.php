<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ValidationsApi\V1\Auth\RegisterRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Http\Resources\Users;
use App\Models\Border;
use App\Models\Colors;
use App\Models\Font;
use Illuminate\Support\Facades\Hash;
use Validator;
class Register extends Controller {

	// public function __construct() {

	// 	// $this->middleware('jwt.user:users');
	// 	auth()->setDefaultDriver('api');
	// 	config()->set( 'auth.defaults.guard', 'api' );
	// 	config()->set('jwt.users', 'App\Models\User');
	// 	config()->set('auth.providers.doctors.model', \App\Models\User::class);
	// }
	private function auth() {
		return auth()->guard('api');
	}

	protected function respondWithToken($token) {
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
	}


	public function register() {
		if(request()->phone != 0){
			$data = Validator::make(request()->all(),[
				// 'phone' => 'required|unique:users|regex:/(05)[0-9]{8}/',
				'phone' => 'required|unique:users',
				// 'name' => 'required|min:4|unique:users',
				'password' => 'required||min:4',
				// 'email' => 'email|required',
			]);
	
			if($data->fails()){
				if(count($data->errors()) > 0 ) {
					$erorrs = $data->errors();
	
					foreach($erorrs->all() as $item) {
					return errorResponseJson(['data' => $erorrs ]  ,203 ,$item);
	
					}
				}
			}
		}

        try {
			// $code =$this->generatePIN();

			// $message = 'كود التحقق هو : ' . $code;
				$user = User::query()->select("*")->where("device_id","!=",null)->where("device_id",request()->device_id)->orWhere(function ($query){
					$query->where("fcm_token","!=", null)
						->where("fcm_token",request()->fcm_token);   
				})->first();
				// return successResponseJson(['data' => $user ], trans('auth.failed'));
				if($user != null){
					$user->name = request()->name;
					$user->phone = request()->phone;
					$user->email = request()->email ?? null;
					$user->save();
					$user->token = $this->auth()->login($user);
					return successResponseJson(['user' =>$user],trans('auth.verification_code_sent'));
				}
				$user = new User();
				$user->name = request()->name;
				$user->fcm_token = request()->fcm_token;
				$user->device_id = request()->device_id;
				// if ($user->type != "")
				$user->phone = request()->phone;
				$user->email = request()->email ?? null;

				$user->password = Hash::make(request()->password) ;
				// I change this it
				// $user->password = \Hash::make(request()->password) ;

				// $user->code = $code;
				$user->save();

				// \App\Sms::send(request()->phone,$message);
				$user->token = $this->auth()->login($user);
				if($user->border_id != 0){
					$user->border = Border::find($user->border_id);
				}
				if($user->color_id != 0){
					$user->color = Colors::find($user->color_id);
				}
				if($user->font_id != 0){
					$user->font = Font::find($user->font_id);
				}
				
				$users = array([
                    'otp'=>1111,//$code,
					'user'=>$user,
					// 'id' => $user->id,
					// 'name' => $user->name,
					// 'phone' => $user->phone,
					// 'email' => $user->email ?? null,
					// 'token' => $token,
					'token_type' => 'Bearer',
				]);
				
				$user->user_assistant()->create();

				$data =  Users::collection($users);
				return successResponseJson(['user' =>$user],trans('auth.verification_code_sent'));



        } catch (\Throwable $th) {
            return errorResponseJson(['data' =>  $th->getMessage()] ,203 ,trans('admin.failed'));
        }


	}

	function generatePIN($digits = 4){
        $i = 0; //counter
        $pin = ""; //our default pin is blank.
        while($i < $digits){
            //generate a random number between 0 and 9.
            $pin .= mt_rand(1, 9);
            $i++;
        }
        return $pin;
   }

   public function deleteUser(){
		$id = auth()->user()->id;
		$Users = User::find($id);
		$Users->delete();
		return response()->json(['success'=>true]);
   }
	
   public function updateUserData(){
	$id = auth()->user()->id;
	$user = User::find($id);
	$user->name = request()['name'] ?? $user->name;
	$user->email = request()['email'] ?? $user->email;
	$user->phone = request()['phone'] ?? $user->phone;
	// $user->email_verified_at = request()['email_verified_at'] ?? $user->email_verified_at;
	// $user->password = request()['password'] ?? $user->password;
	// $user->remember_token = request()['remember_token'] ?? $user->remember_token;
	// $user->created_at = request()['created_at'] ?? $user->created_at;
	// $user->updated_at = request()['updated_at'] ?? $user->updated_at;
	$user->contry_id = request()['contry_id'] ?? $user->contry_id;
	$user->fcm_token = request()['fcm_token'] ?? $user->fcm_token;
	$user->type = request()['type'] ?? $user->type;
	$user->code = request()['code'] ?? $user->code;
	$user->age = request()['age'] ?? $user->age;
	$user->city = request()['city'] ?? $user->city;
	$user->job = request()['job'] ?? $user->job;
	$user->gender = request()['gender'] ?? $user->gender;
	$user->device_id = request()['device_id'] ?? $user->device_id;
	$user->connection_state = request()['connection_state'] ?? $user->connection_state;
	$user->last_connection = request()['last_connection'] ?? $user->last_connection;
	// $user->is_blocked = request()['is_blocked'] ?? $user->is_blocked;
	// $user->xp_points = request()['xp_points'] ?? $user->xp_points;
	// $user->last_task = request()['last_task'] ?? $user->last_task;
	// $user->roll_date = request()['roll_date'] ?? $user->roll_date;
	// $user->roll_count = request()['roll_count'] ?? $user->roll_count;
	// $user->win_points = request()['win_points'] ?? $user->win_points;
	$user->wallet = request()['wallet'] ?? $user->wallet;
	$user->border_id = request()['border_id'] ?? $user->border_id;
	$user->color_id = request()['color_id'] ?? $user->color_id;
	$user->font_id = request()['font_id'] ?? $user->font_id;
	$user->wisdom_count = request()['wisdom_count'] ?? $user->wisdom_count; 
	$user->save();
	$user->token = $this->auth()->login($user);

	if($user->border_id != 0){
		$user->border = Border::find($user->border_id);
	}
	if($user->color_id != 0){
		$user->color = Colors::find($user->color_id);
	}
	if($user->font_id != 0){
		$user->font = Font::find($user->font_id);
	}
	
	return response()->json(['success'=>true,'data'=>$user]);
}

}
