<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ValidationsApi\V1\Auth\ChangePasswordRequest;
use App\Http\Controllers\ValidationsApi\V1\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Validator;
use App\Models\Winner;
use App\Models\Post;

use App\Http\Resources\Users;
use App\Mail\AccountDelete;
use App\Models\Border;
use App\Models\Colors;
use App\Models\Font;
use App\Models\Setting;
use Illuminate\Support\Facades\Mail;
use Laravel\Sanctum\NewAccessToken;

class AuthAndLogin extends Controller {

	public function __construct() {

		$this->middleware('jwt.user:users' , ['except' => ['login', 'loginWithDeviceId' , 'otp' , 'checkotp','terms']]);
		auth()->setDefaultDriver('api');
		config()->set( 'auth.defaults.guard', 'api' );
		config()->set('jwt.users', 'App\Models\User');
		config()->set('auth.providers.users.model', \App\Models\User::class);
	}

	function generatePIN($digits = 4)
	{
		$i = 0; //counter
		$pin = ""; //our default pin is blank.
		while ($i < $digits) {
			//generate a random number between 0 and 9.
			$pin .= mt_rand(0, 9);
			$i++;
		}
		return $pin;
	}


	private function auth() {
		return auth()->guard('api');
	}

	protected function respondWithToken($token) {
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
	}


	public function me() {
		$user  =$this->auth()->user();
		if (!$user) {
			return errorResponseJson(['data' => null], 203 , trans('admin.error_loggedin'));
		}
		if (! empty( request()->name)  || request()->has('name') )  {
			$user->name = request()->name;
			$user->update();
		}
		if (! empty( request()->email)  || request()->has('email') )  {
			$user->email = request()->email;
			$user->update();
		}
		if (! empty( request()->phone)  || request()->has('phone') )  {
			$user->phone = request()->phone;
			$user->update();
		}

		if (! empty( request()->fcm_token)  || request()->has('fcm_token') )  {
			$user->fcm_token = request()->fcm_token;
			$user->save();
		}



		$posts = Post::where("user_id" , $user->id)->get()->count();
		$winners = Winner::where("user_id" , $user->id)->get()->count();
		$users = array([
			'id' => $user->id,
			'name' => $user->name,
			'phone' => $user->phone,
			'email' => $user->email ?? null,
			'winners' => $winners ?? null,
			'posts' => $posts ?? null,
		]);
		// $data =  Users::collection($users);
		return successResponseJson(['data' =>$users],trans('admin.infosuccess'));
	}

	public function logout() {
		$this->auth()->logout();
		return successResponseJson(['data' =>null ] , 'Successfully logged out');
	}

	public function terms($id = 0) {
		if($id == 0){
			return successResponseJson(['data' => [
				'content' => Setting::all()
			] ] , 'Successfully logged out');
		}
		return successResponseJson(['data' => [
			'content' => Setting::where('id',$id)->first()->system_message
		] ] , 'Successfully logged out');
	}

	public function update_profile()
	{
		$user = User::find(auth()->user()->id);
		if (request()->name  || request()->name != null ) {
			$user->name = request()->name;

		}
		if (request()->phone  || request()->phone != null ) {
			$user->phone = request()->phone;

		}
		if (request()->contry_id  || request()->contry_id != null ) {
			$user->contry_id = request()->contry_id;

		}
		if (request()->password  || request()->password != null ) {
			$user->password = \Hash::make(request()->password);

		}
		if (request()->fcm_token  || request()->fcm_token != null ) {
			$user->fcm_token = request()->fcm_token;

		}
		$user->update();
		return successResponseJson(['data' =>true],trans('admin.Updatesuccessfully'));



	}


	public function checkotp() {
		$data = Validator::make(request()->all(),[
			'phone' => 'required|regex:/(05)[0-9]{8}/',
			'code' => 'required',
			'verification' =>'boolean'
		]);
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));
		}
		$checkUser = User::where(["phone"  => request()->phone ,"code"  => request()->code ])->first();
		if ($checkUser || ! empty($checkUser) ) {
			if (request()->verification) {
				$checkUser->email_verified_at = now();
				$checkUser->save();
			}
			$token = $this->auth()->login($checkUser);
			$users = array([
                'otp'=>$checkUser->code,
				'id' => $checkUser->id,
				'name' => $checkUser->name,
				'phone' => $checkUser->phone,
				'email' => $checkUser->email ?? null,
				'token' => $token,
				'token_type' => 'Bearer',
			]);
      
			$data =  Users::collection($users);
			return successResponseJson(['data' =>$data],trans('admin.registersuccess'));
			// return successResponseJson(['data' =>true] ,"تم تحديث كلمة المرور بنجاح");
		} else {
			return errorResponseJson(['data' => false] ,203 ,'كود المصادفة خطا تاكد من كتابة بشكل صحيح');
		}
	}



	public function refresh() {
		return successResponseJson(['data' => $this->respondWithToken($this->auth()->refresh())]);
	}

	public function account() {
		return successResponseJson(['data' => $this->auth()->user()]);
	}

	public function delete_account(){
		$user=$this->auth()->user();
		Mail::to('shummry@gmail.com')->send(new AccountDelete($user));
		return successResponseJson([],trans('auth.account_deletion_request_received'));
	}

	public function login() {
		$validation = Validator::make(request()->all(),[
			'phone' => 'required|regex:/(05)[0-9]{8}/',
			'password' => 'required',
		]);

		if($validation->fails()){

			if(count($validation->errors()) > 0 ) {
				$erorrs = $validation->errors();

				foreach($erorrs->all() as $item) {
				return errorResponseJson(['data' => $erorrs->all()]  ,203 ,$item);

				}
			}
		}


			$credentials = request(['phone', 'password' ]);
			$token = $this->auth()->attempt($credentials);



		if (!$token) {
			return errorResponseJson(['data' => [] ],203, trans('auth.failed'));
		}
		// $user  = Auth::guard("client")->user();
		// $credentials = request(['phone', 'password']);
		// try {
		// 	if (!$token = $this->auth()->attempt($credentials)) {
		// 		return errorResponseJson(['data' => 'Unauthorized', 'message' => trans('auth.failed')]);
		// 	}
		// } catch (JWTException $e) {
		// 	return errorResponseJson(['data' => 'Unauthorized', 'message' => 'Could not create token']);
		// }
		$user  = $this->auth()->user();


        //  $code = null;
		// if($user->email_verified_at==null){
		// 	$code = $this->generatePIN();
		// 	$message = 'كود التحقق هو : ' . $code;
		// 	$user->code = $code;
		// 	$user->save();
		// 	// generate code and keep it in DB
		// 	\App\Sms::send(request()->phone, $message);
		// 	return errorResponseJson(['otp'=>$code],202, 'auth.verification_code_sent');
		// }
		$user->token = $token;
        if($user->border_id != 0){
            $user->border = Border::find($user->border_id);
        }
        if($user->color_id != 0){
            $user->color = Colors::find($user->color_id);
        }
        if($user->font_id != 0){
            $user->font = Font::find($user->font_id);
        }
		$users = array([
            'otp'=>1111,
			'user'=>$user,
			// 'id' => $user->id,
			// 'name' => $user->name,
			// 'phone' => $user->phone,
			// 'email' => $user->email ?? null,
			// 'token' => $token,
			'token_type' => 'Bearer',
		]);
		$data =  Users::collection($users);
		return successResponseJson(['user' =>$user],trans('admin.loginsuccess'));

		// return successResponseJson(['data' =>$this->respondWithToken($token)]);
	}

	public function loginWithDeviceId() {
		$user = User::query()->select("*")->where("device_id","!=",null)->where("device_id",request()->device_id)->orWhere(function ($query){
			$query->where("fcm_token","!=", null)
				->where("fcm_token",request()->fcm_token);   
		})->first();
		// return successResponseJson(['data' => $user ], trans('auth.failed'));
		if($user == null){
			return errorResponseJson(['data' => [] ],203, trans('auth.failed'));
		}
		$user->token = $this->auth()->login($user);
		if($user->border_id != 0){
            $user->border = Border::find($user->border_id);
        }
        if($user->color_id != 0){
            $user->color = Colors::find($user->color_id);
        }
        if($user->font_id != 0){
            $user->font = Font::find($user->font_id);
        }
	
		return successResponseJson(['user' =>$user,'token_type' => 'Bearer'],trans('admin.loginsuccess'));
	}

	public function change_password(ChangePasswordRequest $changepassword) {
		User::where('id', $this->auth()->user()->id)->update([
			'password' => bcrypt(request('new_password')),
		]);
		return successResponseJson([
			'message' => trans('main.password_changed'),
		]);
	}

}
