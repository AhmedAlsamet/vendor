<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\QuestionAssistants;
use App\Models\Compitetion;
use Illuminate\Support\Carbon;
use App\Models\Post;

class QuestionAssistantsApi extends Controller
{
    public function index() {
        $assistant = Auth::user()->user_assistant;

        if(!$assistant){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لا يوجد مساعدات للمستخدم' ,
                'data' => '',
            ], 202);
        }

        return response()->Json([
            'status' => true,
            'code' => 200,
            'message' => 'مساعدات الأسئلة المتاحة للمستخدم' ,
            'data' =>  $assistant,
        ], 200);
    }

    public function update(Request $request) {
        $assistant = Auth::user()->user_assistant;

        if(!$assistant){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لا يوجد مساعدات للمستخدم' ,
                'data' => '',
            ], 202);
        }
        if($request->type == 'time_assistant' && $assistant->time_assistant != 0){
            $assistant->time_assistant = $assistant->time_assistant -1;
            $assistant->save();
            return response()->Json([
                'status' => true,
                'code' => 200,
                'message' => 'تم استخدام مساعدة الوقت بنجاح'
            ], 200);
        }elseif($request->type == 1 && $assistant->time_assistant == 0){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لقد استنفذت محاولات مساعدة الوقت'
            ], 202);
        }

        if($request->type == 'delete_two_answers_assistant' && $assistant->delete_two_answers_assistant != 0){
            
            if($assistant->question_id != null && $assistant->question_id == $request->question_id){
                return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لا يمكنك استخدام مساعدة حذف اجابتين لنفس السؤال'
            ], 202);
            }
            
            $assistant->delete_two_answers_assistant = $assistant->delete_two_answers_assistant -1;
            $assistant->question_id = $request->question_id;
            $assistant->save();
            
            return response()->Json([
                'status' => true,
                'code' => 200,
                'message' => 'تم استخدام مساعدة حذف اجابتين بنجاح'
            ], 200);
        }elseif($request->type == 'delete_two_answers_assistant' && $assistant->delete_two_answers_assistant == 0){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لقد استنفذت محاولات مساعدة حذف اجابتين'
            ], 202);
        }

        if($request->type == 'skip_assistant' && $assistant->skip_assistant != 0){
            $assistant->skip_assistant = $assistant->skip_assistant -1;
            $assistant->save();
            return response()->Json([
                'status' => true,
                'code' => 200,
                'message' => 'تم استخدام مساعدة تخطي السؤال'
            ], 200);
        }elseif($request->type == 'skip_assistant' && $assistant->skip_assistant == 0){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لقد استنفذت محاولات مساعدة تخطي السؤال'
            ], 202);
        }
        
    }
    
    public function wheel(Request $request) {
        $compitetions = Compitetion::where('start_date','<=',now())
                    ->where('end_date','>=',now())->first();
                    $today = Carbon::now()->format('Y-m-d');
                    if ( $compitetions == null) {
                        return errorResponseJson(['data' => null], 202 , "لا يمكنك استخدام دولاب الحظ لعدم وجود مسابقات اليوم");
                    }elseif($today == date('Y-m-d', strtotime($compitetions->end_date))){
                        return errorResponseJson(['data' => null], 202 , "لا يمكنك استخدام دولاب الحظ لعدم وجود مسابقات اليوم");
                    }

                    $post = Post::where('compitetion_id' , $compitetions->id)->where('user_id', Auth::user()->id)->first();
                    if(!$post){
                        return response()->Json([
                            'status' => false,
                            'code' => 202,
                            'message' => 'يجب دخول المسابقة قبل استخدام دولاب الحظ' ,
                            'data' => '',
                        ], 202);
                    }
                    $post->update([
                        'mark' => $post->mark + $request->point
                    ]);
                     
        if(!$request->point){
            return response()->Json([
                'status' => false,
                'code' => 202,
                'message' => 'لا يوجد دولاب حظ لهذا اليوم' ,
                'data' => '',
            ], 202);
        }

        return response()->Json([
            'status' => true,
            'code' => 200,
            'message' => 'تم تدوير دولاب الحظ بنجاح' ,
            'data' =>  '',
        ], 200);
    }
}
