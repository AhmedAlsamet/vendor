<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Winner;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\WinnersRequest;
use App\Http\Resources\WinnerResource;
use App\Models\Compitetion;

// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class WinnersApi extends Controller{
	protected $selectColumns = [
		"winners.id",
		"winners.user_id",
		"winners.time",
        "winners.mark",
        "winners.created_at"

	];

    protected function getSelectString()
    {
        return "winners.id,winners.user_id,winners.time,winners.mark,winners.created_at,(select count(*) from winners w where id<=winners.id and compitetion_id=compitetions.id) as index_count";
    }

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
                return ['user_id'];
            }
            public function index()
            {
                        $today = Carbon::now()->format('Y-m-d');

                 $compitetions = Compitetion::where('start_date','<=',now())
                        ->whereDate('end_date','=',$today)->first();

                if ( $compitetions == null) {
                        return errorResponseJson(['data' => null], 202 , "لا يوجد مسابقات اليوم");
                    }
                $data = WinnerResource::collection(Winner::where('compitetion_id',$compitetions->id)->take(3)->orderBy("mark","DESC")->orderBy("time","ASC")->orderBy("id","ASC")->get());
                return response()->json(['data'=>$data,'success'=>true,'code'=>200,'message'=>'ok']);

            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
    public function store(WinnersRequest $request)
    {
    	$data = $request->except("_token");

        $Winner = Winner::create($data);

		  $Winner = Winner::with($this->arrWith())->find($Winner->id,$this->selectColumns);
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$Winner
        ]);
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Winner = Winner::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Winner) || empty($Winner)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Winner
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new WinnersRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(WinnersRequest $request,$id)
            {
            	$Winner = Winner::find($id);
            	if(is_null($Winner) || empty($Winner)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();

              Winner::where("id",$id)->update($data);

              $Winner = Winner::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Winner
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $winners = Winner::find($id);
            	if(is_null($winners) || empty($winners)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("winner",$id);

               $winners->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $winners = Winner::find($id);
	            	if(is_null($winners) || empty($winners)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("winner",$id);
                    	$winners->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $winners = Winner::find($data);
	            	if(is_null($winners) || empty($winners)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("winner",$data);

                    $winners->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }


}
