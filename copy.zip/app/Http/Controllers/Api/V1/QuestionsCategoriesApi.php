<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\UserQuestionCategory;
use Illuminate\Http\Request;

class QuestionsCategoriesApi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }
    public function storeMulti(Request $request)
    {
        $data = $request->except("_token");
        $old = UserQuestionCategory::all()->where("user_id",auth()->user()->id);
        for ($i=0; $i < count($old); $i++) { 
            $old[$i]->delete();
        }
        $data['list'] = str_replace("[", "", $data['list']);
        $data['list'] = str_replace("]", "", $data['list']);
        $array = explode(',', $data['list']);

        for ($i=0; $i < count($array); $i++) { 
            $u = new UserQuestionCategory();
            $u->user_id = auth()->user()->id;
            $u->question_category_id = $array[$i];
            $u->save();
            // UserQuestionCategory::create($u);
        }
        return successResponseJson([
            "message"=> trans("admin.added"),
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
