<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Animal;
use App\Models\Auction;
use App\Models\AnimalPhoto;
use App\Models\Type;
use App\Models\Catagory;
use App\Models\Like;
use App\Models\Favorite;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\AnimalsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class AnimalsApi extends Controller{
	protected $selectColumns = [
		"id",
        "animal_name_ar",
		"animal_name_en",
		"animal_price",
		"animal_photo",
		"animal_gender",
		"animal_phone",
		"animal_type",
		"animal_area",
		"animal_city",
		"animal_latitude",
		"animal_longitude",
		"animal_details",
		"animal_user_id",
		"animal_catagory",
    'animal_day',
    'animal_month',
    'animal_year',
    'animal_weight',
    'animal_car_brand' ,
    'animal_car_kilometers' ,
    'animal_car_color',
    'animal_car_connection_types',
    'animal_car_status' ,
    'animal_car_engine_capacities',
    'animal_car_motion_vectors',
    'animal_car_payment_methods' ,
    'animal_car_fuel_types' ,
    'animal_car_body_types',
    'manufacturing_years'
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
                return [
                'animal_type',
                'animal_area',
                'animal_city',
                'animal_user_id',
                'animal_catagory',
                'images' ,
                'auction' ,
                'animal_car_brand' ,
                'animal_car_kilometers' ,
                'animal_car_color',
                'animal_car_connection_types',
                'animal_car_status' ,
                'animal_car_engine_capacities',
                'animal_car_motion_vectors',
                'animal_car_payment_methods' ,
                'animal_car_fuel_types' ,
                'animal_car_body_types',
                'manufacturing_years'
              ];
            }
            public function checkLike($id)
            {
              $like = Like::where(['like_user' =>  auth()->guard('api')->user()->id, 'like_animal' => $id])->first();
              $count = Like::where([ 'like_animal' => $id])->count();
              if ($like != null ) {
                return successResponseJson([
                  "data"=> array([
                      'is_like' => true,
                      'like_count' => $count
                  ])
                  ]); 
              } else {
                return successResponseJson([
                  "data"=> array([
                    'is_like' => false,
                    'like_count' => $count
                ])
                  ]); 
              }
            }
            public function checkFav($id)
            {
              $Favorite = Favorite::where(['favorite_user_id' =>  auth()->guard('api')->user()->id, 'favorite_type_id' => $id])->first();
              if ($Favorite != null) {
                return successResponseJson([
                  "data"=> true
                  ]); 
              } else {
                return successResponseJson([
                  "data"=> false
                  ]); 
              }
              
            }
            public function getcountLike($id)
            {
              // validtions  on id animal 
              $like = Like::where([ 'like_animal' => $id])->get()->count(); 
                return successResponseJson([
                  "data"=> $like ?? 0
                ]); 
              
            }

            public function index()
            {


                $Animal = Animal::query()->with($this->arrWith());
                if (request()->type_status == "true" || request()->type_status == true) {
                  /// type


                } else {
                  // no type 
                }
                if (request()->catagory == 10) {
                  $Animal->where("animal_catagory",request()->catagory );
                  if(request()->type &&  request()->type != null) {
                    $Animal->where("animal_type",request()->type );
                  } 

                  if(request()->car_brand &&  request()->car_brand != null) {
                    $Animal->where("animal_car_brand",request()->car_brand );
                  }
                  if(request()->car_kilometers &&  request()->car_kilometers != null) {
                    $Animal->where("animal_car_kilometers",request()->car_kilometers );
                  }
                  if(request()->car_status &&  request()->car_status != null) {
                    $Animal->where("animal_car_status",request()->car_status );
                  }
                  if(request()->engine_capacities &&  request()->engine_capacities != null) {
                    $Animal->where("animal_car_engine_capacities",request()->engine_capacities );
                  }
                  if(request()->car_motion_vectors &&  request()->car_motion_vectors != null) {
                    $Animal->where("animal_car_motion_vectors",request()->car_motion_vectors );
                  }
                  if(request()->car_payment_methods &&  request()->car_payment_methods != null) {
                    $Animal->where("animal_car_payment_methods",request()->car_payment_methods );
                  }
                  if(request()->car_fuel_types &&  request()->car_fuel_types != null) {
                    $Animal->where("animal_car_fuel_types",request()->car_fuel_types );
                  }
                  if(request()->car_color &&  request()->car_color != null) {
                    $Animal->where("animal_car_color",request()->car_color );
                  }
                  if(request()->car_body_types &&  request()->car_body_types != null) {
                    $Animal->where("animal_car_body_types",request()->car_body_types );
                  }
                  if(request()->car_connection_types &&  request()->car_connection_types != null) {
                    $Animal->where("animal_car_connection_types",request()->car_connection_types );
                  }
                } else if (request()->catagory == 18) {
                  if (request()->catagory && request()->catagory != null) {

                    $Animal->where("animal_catagory",request()->catagory );
                  }
                  if(request()->type &&  request()->type != null) {
                    $Animal->where("animal_type",request()->type );
                  } 

                  if (request()->start_price && request()->start_price != null) {
                    $Animal->where('animal_price', '>=' , request()->start_price);
                  }
      
                  if (request()->end_price && request()->end_price != null) {
                    $Animal->where('animal_price', '>=' , request()->end_price);
                  }
      
                  if (request()->city && request()->city != null ) {
                    $Animal->where('animal_city', request()->city);
                  }
                  if (request()->gender && request()->gender != null ) {
                    $Animal->where('animal_gender', request()->gender);
                  }
                }
                else {


                  if (request()->catagory && request()->catagory != null) {

                    $Animal->where("animal_catagory",request()->catagory );
                  }
                  if(request()->type &&  request()->type != null) {
                    $Animal->where("animal_type",request()->type );
                  } 
                  
                  
                }

  
              return successResponseJson([
                "data"=> $Animal->get() ?? []
                ]); 
  
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
            public function store(AnimalsRequest $request)
            {

              $data = $request->except("_token");
              // dd($data);
                        $data["animal_photo"] = "";
                        $data["animal_user_id"] = auth()->guard('api')->user()->id;
                        

                $Animal = Animal::create($data); 

                       if(request()->hasFile("animal_photo")){
                      $Animal->animal_photo = it()->upload("animal_photo","animals/".$Animal->id);
                      $Animal->save();
                      }


                        /// add images
                      if ( $request->images != null)  {
                          foreach ($request->images as $item) {
                            $AnimalPhoto = new AnimalPhoto();
                            $AnimalPhoto->animal_photo_type_id = $Animal->id;
                            // if(request()->hasFile("animal_img")){
                              $AnimalPhoto->animal_img = it()->upload($item,"animalphotos/".$AnimalPhoto->id);
                              $AnimalPhoto->save();
                            // }
                          }
                      }

                      if ($request->animal_catagory == "12" || $request->animal_catagory == 12 ) {
                       $auction =  new Auction();
                       $auction->auction_animal = $Animal->id;
                       $auction->auction_opening_price = $request->opening_price;
                       $auction->auction_end_price = 0;
                       $auction->auction_status = 'active';
                       $auction->save();
                       
                      }
                      

              $Animal = Animal::with($this->arrWith())->find($Animal->id,$this->selectColumns);

                  return successResponseJson(["data"=>$Animal], trans("admin.added"));
            }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Animal = Animal::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Animal) || empty($Animal)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Animal
              ]);  ;
            }
            public function getAnimalbytype($id)
            {
                $type = Type::find($id);
                 return successResponseJson([
              "data"=> $type->Animal ?? []
              ]); 
             
            }

            public function getAnimalbyCatagory($id)
            {
              $catagory = Catagory::find($id);
                 return successResponseJson([
              "data"=> $catagory->Animal ?? []
              ]); 
             
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new AnimalsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(AnimalsRequest $request,$id)
            {
            	$Animal = Animal::find($id);
            	if(is_null($Animal) || empty($Animal)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();

                $data["animal_user_id"] = auth()->guard('api')->user()->id;

                if(request()->hasFile("animal_photo")){
               it()->delete($Animal->animal_photo);
               $data["animal_photo"] = it()->upload("animal_photo","animals/".$Animal->id);
                }
              Animal::where("id",$id)->update($data);

              $Animal = Animal::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Animal
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $animals = Animal::find($id);
            	if(is_null($animals) || empty($animals)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


              if(!empty($animals->animal_photo)){
               it()->delete($animals->animal_photo);
              }
               it()->delete("animal",$id);

               $animals->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $animals = Animal::find($id);
	            	if(is_null($animals) || empty($animals)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	if(!empty($animals->animal_photo)){
                    	it()->delete($animals->animal_photo);
                    	}
                    	it()->delete("animal",$id);
                    	$animals->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $animals = Animal::find($data);
	            	if(is_null($animals) || empty($animals)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	if(!empty($animals->animal_photo)){
                    	it()->delete($animals->animal_photo);
                    	}
                    	it()->delete("animal",$data);

                    $animals->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}