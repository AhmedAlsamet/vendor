<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Support;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\SupportsRequest;
// Auto Controller Maker By Baboon Script
// Baboon Maker has been Created And Developed By  [it v 1.6.33]
// Copyright Reserved  [it v 1.6.33]
class SupportsApi extends Controller{
	protected $selectColumns = [
		"id",
		"support_username",
		"support_email",
		"support_phone",
		"support_msg",
	];

            /**
             * Display the specified releationshop.
             * Baboon Api Script By [it v 1.6.33]
             * @return array to assign with index & show methods
             */
            public function arrWith(){
               return [];
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Display a listing of the resource. Api
             * @return \Illuminate\Http\Response
             */
            public function index()
            {
            	$Support = Support::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->paginate(15);
               return successResponseJson(["data"=>$Support]);
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * Store a newly created resource in storage. Api
             * @return \Illuminate\Http\Response
             */
            private function auth() {
                return auth()->guard('api');
            }
    public function store(SupportsRequest $request)
    {
    	$data = $request->except("_token");
        $data['support_username'] = auth()->user()->name ;
        $data['support_email']    = auth()->user()->email;
        $data['support_phone']    = auth()->user()->phone;
        $Support = Support::create($data); 

		  $Support = Support::with($this->arrWith())->find($Support->id,$this->selectColumns);
        return successResponseJson([
            "data"=>$Support
        ],trans("admin.added"),
    );
    }
    public function storeWithoutToken(SupportsRequest $request)
    {
        $data = $request->except("_token");
        $data['support_username'] = isset($request['support_username']) ? $request['support_username'] : "Unknown" ;
        $data['support_email'] = isset($request['support_email']) ? $request['support_email'] : "Unknown" ;
        $data['support_phone'] = isset($request['support_phone']) ? $request['support_phone'] : "Unknown" ;
        $Support = Support::create($data); 

		  $Support = Support::with($this->arrWith())->find($Support->id,$this->selectColumns);
        return successResponseJson([
            "data"=>$Support
        ],trans("admin.added"),
    );
    }


            /**
             * Display the specified resource.
             * Baboon Api Script By [it v 1.6.33]
             * @param  int  $id
             * @return \Illuminate\Http\Response
             */
            public function show($id)
            {
                $Support = Support::with($this->arrWith())->find($id,$this->selectColumns);
            	if(is_null($Support) || empty($Support)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}

                 return successResponseJson([
              "data"=> $Support
              ]);  ;
            }


            /**
             * Baboon Api Script By [it v 1.6.33]
             * update a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function updateFillableColumns() {
				       $fillableCols = [];
				       foreach (array_keys((new SupportsRequest)->attributes()) as $fillableUpdate) {
  				        if (!is_null(request($fillableUpdate))) {
						  $fillableCols[$fillableUpdate] = request($fillableUpdate);
						}
				       }
  				     return $fillableCols;
  	     		}

            public function update(SupportsRequest $request,$id)
            {
            	$Support = Support::find($id);
            	if(is_null($Support) || empty($Support)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
  			       }

            	$data = $this->updateFillableColumns();
                 
              Support::where("id",$id)->update($data);

              $Support = Support::with($this->arrWith())->find($id,$this->selectColumns);
              return successResponseJson([
               "message"=>trans("admin.updated"),
               "data"=> $Support
               ]);
            }

            /**
             * Baboon Api Script By [it v 1.6.33]
             * destroy a newly created resource in storage.
             * @return \Illuminate\Http\Response
             */
            public function destroy($id)
            {
               $supports = Support::find($id);
            	if(is_null($supports) || empty($supports)){
            	 return errorResponseJson([
            	  "message"=>trans("admin.undefinedRecord")
            	 ]);
            	}


               it()->delete("support",$id);

               $supports->delete();
               return successResponseJson([
                "message"=>trans("admin.deleted")
               ]);
            }



 			public function multi_delete()
            {
                $data = request("selected_data");
                if(is_array($data)){
                    foreach($data as $id){
                    $supports = Support::find($id);
	            	if(is_null($supports) || empty($supports)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}

                    	it()->delete("support",$id);
                    	$supports->delete();
                    }
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }else {
                    $supports = Support::find($data);
	            	if(is_null($supports) || empty($supports)){
	            	 return errorResponseJson([
	            	  "message"=>trans("admin.undefinedRecord")
	            	 ]);
	            	}
 
                    	it()->delete("support",$data);

                    $supports->delete();
                    return successResponseJson([
                     "message"=>trans("admin.deleted")
                    ]);
                }
            }

            
}