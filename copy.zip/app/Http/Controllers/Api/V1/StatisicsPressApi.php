<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\PressStatistic;
use Illuminate\Http\Request;
use Phpanonymous\It\Controllers\Baboon\Statistics;

class StatisicsPressApi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->except("_token");
		$statistic = PressStatistic::where("user_id",auth()->user()->id)->where("type",$data["type"])->get()->first();
        if($statistic != null){
            $statistic->count += 1;
            $statistic->save();
            return successResponseJson([
                "message"=>trans("admin.added"),
                "data"=>$statistic
            ]);
        }
        $friend = new PressStatistic();
        $friend->count = 1;
        $friend->user_id = auth()->user()->id;
        $friend->type  = $data["type"];

        $friend = $friend->save();
        
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$friend
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
