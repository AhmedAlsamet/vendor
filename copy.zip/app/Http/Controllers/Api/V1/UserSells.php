<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDoneTask;
use App\Models\UserSell;
use Illuminate\Http\Request;

class UserSells extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userSell = new UserSell();
        $userSell->user_id = auth()->user()->id;
        $userSell->type = $request->type;
        $userSell->price = $request->price;
        $userSell->item_id = $request->item_id;
        $userSell->save();
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$userSell
        ]);
    }
    public function buy_wisdom(Request $request)
    {
        $userSell = new UserSell();
        $userSell->user_id = auth()->user()->id;
        $userSell->type = $request->type;
        $userSell->price = $request->price;
        $userSell->item_id = $request->item_id;
        $userSell->save();
        $user = User::find(auth()->user()->id);
        if($request->type != "ALL"){
            $user->wisdom_count = $request->type;
        }
        $user->save();
        if($request->type == "ALL"){
            $maxDays=date('t');
            for ($i=0; $i < $maxDays; $i++) { 
                $taskDone = new UserDoneTask();
                $taskDone->user = auth()->user()->id;
                $taskDone->date = date('Y-m-'.($i+1).' H:i:s');
                $taskDone->type = "WISDOM";
                $taskDone->save();
            }
        }
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$userSell
        ]);
    }
    public function exchange_wisdom(Request $request)
    {
        $taskDone = new UserDoneTask();
        $taskDone->user = auth()->user()->id;
        $taskDone->date = date('Y-m-'.($request->number).' H:i:s');
        $taskDone->type = "WISDOM";
        $taskDone->save();
        $user = User::find(auth()->user()->id);
        $user->wisdom_count = "";
        $user->save();
        return successResponseJson([
            "message"=>trans("admin.added"),
            "data"=>$user
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
