<?php

namespace App\Http\Controllers\Api\V1\Auth;

use Laravel\Socialite\Facades\Socialite;

use App\Http\Controllers\Controller;
use Laravel\Socialite\Two\InvalidStateException;
use Tymon\JWTAuth\JWTAuth;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Exceptions\JWTException;
class SocialLoginController extends Controller
{
    protected $auth;

    public function __construct(JWTAuth $auth)
    {
        $this->auth = $auth;
        $this->middleware(['social', 'web']);
    }

    public function redirect($service)
    {
        return Socialite::driver($service)->redirect();
    }

    public function callback($service , $token)
    {
        try {
            $user = Socialite::driver($service)->userFromToken($token);

        } catch (\GuzzleHttp\Exception\ClientException $exception) {
                return errorResponseJson(['data' => null ] ,203 ,trans('admin.tokenError'));	
        }
    
        try {
            // $user = Socialite::driver($service)->user();
            // $token = Socialite::driver($service)->user()->token;
            if ($user == null || is_null($user) ) {
                return errorResponseJson(['data' => null ] ,203 ,trans('admin.tokenError'));	
            } 
            $finduser = User::where('email', $user->getEmail())->first();

            if($finduser){
                $token = Auth::login($finduser);
                $data = [
                    'name' => $finduser->name,
                    'email' => $finduser->email,
                    'photo' => $user->getAvatar(),
                    'phone' =>  $finduser->phone,
                    'type'=> $service,
                    'token' => $token
                ];

                return successResponseJson(['data' =>$data]);

            }else{
                $newUser = User::create([
                    'name' => $user->getName(),
                    'email' => $user->getEmail(),
                    'photo' => $user->getAvatar(),
                    'phone' => null,
                    'type'=> $service,
                    'password' => bcrypt('123456')
                ]);
                $token = Auth::login($newUser);
                $data = [
                    'name' => $newUser->name,
                    'email' => $newUser->email,
                    'photo' => $user->getAvatar(),
                    'phone' =>  $newUser->phone,
                    'type'=> "google",
                    'token' => $token
                ];

                return successResponseJson(['data' =>$data]);

            }
    
        } catch (Exception $e) {
            dd($e->getMessage());
        }
        // try {
        //     $serviceUser = Socialite::driver($service)->user();

        //     if ($service != 'google') {
        //         $email = $serviceUser->getId() . '@' . $service . '.local';
        //     } else {
        //         $email = $serviceUser->getEmail();
        //     }
    
        //     $user = $this->getExistingUser($serviceUser, $email, $service);
        //     $newUser = false;

        //     if (!$user) {
        //         $newUser = true;
        //         $user = User::create([
        //             'name' => $serviceUser->getName(),
        //             'email' => $email,
        //             'password' => ''
        //         ]);

        //     }
        //     // dd($serviceUser);

    
        //     if ($this->needsToCreateSocial($user, $service)) {
        //         UserSocial::create([
        //             'user_id' => $user->id,
        //             'social_id' => $serviceUser->getId(),
        //             'service' => $service
        //         ]);
        //     }

        // } catch (\Exception $e) {
        //                 // dd($e);

        //     // return redirect(env('CLIENT_BASE_URL') . '/api/v1/login/google/callback?error=Unable to login using ' . $service . '. Please try again' . '&origin=login');
        // }

    

    }

    public function needsToCreateSocial(User $user, $service)
    {
        return !$user->hasSocialLinked($service);
    }

    public function getExistingUser($serviceUser, $email, $service)
    {
        if ($service != 'google') {
            $userSocial = UserSocial::where('social_id', $serviceUser->getId())->first();
            dd($userSocial);
            return $userSocial ? $userSocial->user : null;
        }
        return User::where('email', $email)->orWhereHas('social', function($q) use ($serviceUser, $service) {
            $q->where('social_id', $serviceUser->getId())->where('service', $service);
        })->first();
    }
}