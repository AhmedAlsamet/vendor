<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ValidationsApi\V1\Auth\RegisterRequest;
use App\Models\User;
use App\Models\QuestionAssistants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Http\Resources\Users;

use Validator;
class Register extends Controller {

	private function auth() {
		return auth()->guard('api');
	}

	protected function respondWithToken($token) {
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
	}


	public function register() {
		$data = Validator::make(request()->all(),[ 
			'phone' => 'required|min:8|unique:users',
			'name' => 'required|min:4',
			'password' => 'required',
			'email' => '',
			'fcm_token' => 'required',
			'contry_id' => 'required',
		]);
	
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));	
		}

        try {
            $user = new User();
            $user->name = request()->name;
            $user->phone = request()->phone;
            $user->email = request()->email ?? null;
            $user->fcm_token = request()->fcm_token;
            $user->contry_id = request()->contry_id;
            $user->type = request()->type;
            $user->password = \Hash::make(request()->password) ;
            $user->save();
			$token = $this->auth()->login($user);
			$users = array([
				'id' => $user->id,
				'name' => $user->name,
				'phone' => $user->phone,
				'email' => $user->email ?? null,
				'contry_id' => $user->contry_id,
				'type' => $user->type,
				'token' => $token,
				'token_type' => 'Bearer',
			]);
	        
			$data =  Users::collection($users);	
			return successResponseJson(['data' =>$data],trans('admin.registersuccess'));
	
			return successResponseJson(['data' =>$this->respondWithToken($token)],trans('admin.registersuccess'));
			
        } catch (\Throwable $th) {
            return errorResponseJson(['data' =>  $th->getMessage()] ,203 ,trans('admin.failed'));	
        }
		

	}

}