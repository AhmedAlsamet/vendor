<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Models\User;
use App\Http\Resources\Users;


class ResetPassword extends Controller {

	public function __construct() {
	}
	private function auth() {
		return auth()->guard('api');
	}
	public function checkUser() {
		$data = Validator::make(request()->all(),[
			'phone' => 'required|min:8|numeric',
		]);
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));
		}
        $checkUser = User::wherePhone(request()->phone)->first();

        if ($checkUser || ! empty($checkUser) ) {
			return successResponseJson(['data' =>true],trans('admin.here_reset_link'));
        } else {
			return errorResponseJson(['data' => false] ,203 ,trans('admin.resetpassword'));
        }
	}
    public function newpassword() {
		$data = Validator::make(request()->all(),[
			'phone' => 'required|min:8',
			'password' => 'required',
		]);
		if($data->fails()){
			return errorResponseJson(['data' =>  $data->errors()] ,203 ,trans('admin.error_loggedin'));
		}

        $checkUser = User::wherePhone(request()->phone)->first();

        if ($checkUser || ! empty($checkUser) ) {
            $checkUser->password =  \Hash::make(request()->password);
            $checkUser->save();
			return successResponseJson(['data' =>true],trans('admin.uploadpasswordsuccess'));
        } else {
			return errorResponseJson(['data' => false] ,203 ,trans('admin.uploadpassworderrorsuccess'));
        }
	}




}
