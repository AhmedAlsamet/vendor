<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class packageRequest extends FormRequest {


	public function authorize() {
		return true;
	}


	protected function onCreate() {
		return [
			'title' => 'required|string',
            // 'days' => 'required',
			'price' => 'required|regex:/^[0-9]+(\.[0-9][0-9]?)?$/',

		];
	}

	protected function onUpdate() {
		return [
			'title' => 'required|string',
            // 'days' => 'required',
			'price' => 'required|regex:/^[0-9]+(\.[0-9][0-9]?)?$/',

		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	public function attributes() {
		return [
			'title' => trans('admin.package name'),
            'days' => trans('admin.day sPackage'),
            'price' => trans('admin.package_price'),

		];
	}


	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 203,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 203) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}
