<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class FriendRequest extends FormRequest {


	public function authorize() {
		return true;
	}


	protected function onCreate() {
		return [
			'user_id' => 'required|numeric',
		];
	}

	protected function onUpdate() {
		return [
			// "state" =>"required|string"
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	public function attributes() {
		return [
			'user_id' => 'رقم الصديق مطلوب',
			"state" =>"الحالة مطلوبة"
		];
	}


	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 203,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 203) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}
