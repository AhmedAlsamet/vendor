<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class borderRequest extends FormRequest {


	public function authorize() {
		return true;
	}


	protected function onCreate() {
		return [
			'color' => 'required|string',
			'price' => 'required|numeric',
			'title' => 'required|string',
		];
	}

	protected function onUpdate() {
		return [
			'color' => 'required|string',
			'price' => 'required|numeric',
			'title' => 'required|string',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	public function attributes() {
		return [
			'color' => trans('admin.color'),
			'title' => trans('admin.name'),
			'price' => trans('admin.price'),
			'border_image' => "صورة الإطار",
		];
	}


	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 203,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 203) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}
