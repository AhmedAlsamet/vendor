<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class NotificationsRequest extends FormRequest {

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
             'Notification_title'=>'required',
             'Notification_body'=>'required',
            //  'Notification_resever'=>'required|in:post,winner',
		];
	}

	protected function onUpdate() {
		return [
             'Notification_title'=>'required',
             'Notification_body'=>'required',
            //  'Notification_resever'=>'required|in:post,winner',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * Baboon Script By [it v 1.6.33]
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
             'Notification_title'=>trans('admin.Notification_title'),
             'Notification_body'=>trans('admin.Notification_body'),
             'Notification_title_lat'=>trans('admin.Notification_title_lat'),
             'Notification_body_lat'=>trans('admin.Notification_body_lat'),
             'Notification_for'=>trans('admin.Notification_for'),
            //  'Notification_resever'=>trans('admin.Notification_resever'),
		];
	}

	/**
	 * Baboon Script By [it v 1.6.33]
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}