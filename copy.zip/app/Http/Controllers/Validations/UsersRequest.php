<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UsersRequest extends FormRequest {


	public function authorize() {
		return true;
	}



	protected function onCreate() {
		return [
			'name' => 'required|string',
			'password' => 'required|max:255|min:6',
			'email' => 'email|unique:users',
			'phone' => 'required|numeric|unique:users',
			'type' => 'required',
			'age' => 'numeric',
			'city' => '',
			'job' => '',
			'gender' => 'numeric',
			'device_id' => '',
			'connection_state' => '',
			'last_connection' => '',
			'is_blocked' => '',
		];
	}

	protected function onUpdate() {
		
		return [
			'name' => 'string',
			'password' => '',
			'type' => 'required',
			'email' => 'required|email',
			'phone' => 'required|unique:users,phone,' . request()->segment(3),
			'age' => 'numeric',
			'city' => '',
			'job' => '',
			'gender' => 'numeric',
			'device_id' => '',
			'connection_state' => '',
			'last_connection' => '',
			'is_blocked' => '',

		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	public function attributes() {
		return [
			'name' => trans('admin.name'),
			'password' => trans('admin.password'),
			'phone' => trans('admin.phone'),
			'email' => trans('admin.email'),
			'type' => trans('admin.type'),
			'age' => trans('admin.age'),
			'city' => trans('admin.city'),
			'job' => trans('admin.job'),
			'gender' => trans('admin.gender'),
			'device_id' => trans('admin.device_id'),
			'connection_state' => trans('admin.connection_state'),
			'last_connection' => trans('admin.last_connection'),
			'is_blocked' => trans('admin.is_blocked'),
		];
	}


	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 203,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 203) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}