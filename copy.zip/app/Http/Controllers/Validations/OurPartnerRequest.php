<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class OurPartnerRequest extends FormRequest {


	public function authorize() {
		return true;
	}


	protected function onCreate() {
		return [
			'name' => 'required|string',
			// 'logo' => 'required',
		];
	}

	protected function onUpdate() {
		return [
			'name' => 'required|string',
			// 'logo' => 'required',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	public function attributes() {
		return [
			'name' => "أسم الشريك",
			'logo' => "الشعار",
		];
	}


	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 203,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 203) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}
