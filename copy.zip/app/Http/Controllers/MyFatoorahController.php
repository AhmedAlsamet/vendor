<?php

namespace App\Http\Controllers;

use App\Models\AddPackage;
use App\Models\Client;
use App\Models\Package;
use App\Models\PaymentInvoice;
use Basel\MyFatoorah\MyFatoorah;
use Exception;
use Illuminate\Http\Request;

class MyFatoorahController extends Controller
{
    public $myfatoorah;

    public function __construct()
    {
        $type = payment_setting()->account_type ? false : true;

        $this->myfatoorah = MyFatoorah::getInstance($type);
    }


    public function index($id)

    {
        try {

            $item_arr = [];

                $order = AddPackage::find($id);

                $price = optional($order->package_info)->price ?? 0;
                $email = optional($order->user_info)->email ?? 'package@yahoo.com';
                $name =  optional($order->user_info)->name ?? 'Customer';
                $phone =  optional($order->user_info)->phone ?? '56562123544';
                $result = $this->myfatoorah->sendPayment(
                    $name,
                    $price,
                    [
                        //     'MobileCountryCode',
                        'CustomerMobile' =>  $phone,
                            'CustomerEmail'=> $email,
                        //     'Language' =>"AR",
                        'CustomerReference' => $order->id,  //orderID
                        // 'CustomerCivilId' => "321",
                        'UserDefinedField' =>  '3241', //clientID

                        //     'ExpireDate',
                            // 'CustomerAddress'=> 'test',

                    ]
                );

            if ($result && $result['IsSuccess'] == true) {
                return redirect($result['Data']['InvoiceURL']);
            }


        } catch (Exception $e) {
            return response()->json(['success' => false, 'Error'=>__('حذت خطأ ما  ! حاول فى وقت لاحق'), 'code'=>200]);

            // echo $e->getResponse()->getBody()->getContents();

            //    dd($e  ,$e->getResponse()->getBody()->getContents() );
        }
    }

    public function successCallback(Request $request)
    {
        //  "paymentId" => "060641960331928262"
        //   "Id" => "060641960331928262"

        if (array_key_exists('paymentId', $request->all())) {
            $result = $this->myfatoorah->getPaymentStatus('paymentId', $request->paymentId);

            if ($result && $result['IsSuccess'] == true && $result['Data']['InvoiceStatus'] == "Paid") {

                $add_package = AddPackage::find($result['Data']['CustomerReference']);
                    if ($add_package->show_payemnt == 0) {
                        $package = Package::find($add_package->package);
                        $today =date('Y-m-d');
                        $add_package->approve = 1;
                        if($add_package->for_ever ==0){
                            // you are supscribe package not forever
                            $days =date("Y-m-d", strtotime("$today +$package->days day"));
                            $add_package->expired = $days;
                        }
                        $add_package->save();
                        // Logic after success
                        $this->createInvoice($result['Data']);
                        return response()->json(['success' => true, 'message'=>'success', 'code'=>200]);
                    }else{
                        return response()->json(['success' => true, 'message'=>'انت بالفعل قمت بالاشتراك فى هذه الباقة', 'code'=>200]);

                    }

                }

            }
        }

    public function failCallback(Request $request)
    {

        if (array_key_exists('paymentId', $request->all())) {
            $result = $this->myfatoorah->getPaymentStatus('paymentId', $request->paymentId);

            if ($result && $result['IsSuccess'] == true && $result['Data']['InvoiceStatus'] == "Pending") {

                // Logic after fail
                $error = end($result['Data']['InvoiceTransactions'])['Error'];
                return response()->json(['success' => false, 'Error'=>$error, 'code'=>200]);

            }
        }
    }

    public function createInvoice($request)
    {
        $paymentarray = array_merge($request, end($request['InvoiceTransactions']));
        $paymentarray['order_id'] = $paymentarray['CustomerReference'];
        $paymentarray['client_id'] = $paymentarray['UserDefinedField'];

        $PaymentInvoice = PaymentInvoice::create($paymentarray);
    }
}
