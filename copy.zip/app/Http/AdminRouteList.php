<?php
/*
* To implement in admingroups permissions
* to remove CRUD from Validation remove route name
* CRUD Role permission (create,read,update,delete)
* [it v 1.6.33]
*/
return [
	"notifications"=>["create","read","update","delete"],
	"winners"=>["create","read","update","delete"],
	"posts"=>["create","read","update","delete"],
	"supports"=>["create","read","update","delete"],
	"compitetions"=>["create","read","update","delete"],
	"questions"=>["create","read","update","delete"],
	"Social"=>["create","read","update","delete"],
	"admins"=>["create","read","update","delete"],
	"admingroups"=>["create","read","update","delete"],
    "TodayWisdoms"=>["create","update","read","update","delete"],
    "GoldWisdoms"=>["create","update","read","update","delete"],
	"border"=>["create","read","update","delete"],
	"package"=>["create","read","update","delete"],
	"users"=>["create","read","update","delete"],
	"payment"=>["create","read","update","delete"],
	"questionCategories"=>["create","read","update","delete"],
	"cities"=>["create","read","update","delete"],
	"jobs"=>["create","read","update","delete"],
	"font"=>["create","read","update","delete"],
	"levels"=>["create","read","update","delete"],
	"colors"=>["create","read","update","delete"],
	"appQuestions"=>["create","read","update","delete"],
	"ourPartners"=>["create","read","update","delete"],
];
