<?php
namespace App\Http\Middleware;

use Closure;

class ApiLang {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @param  string|null  $guard
	 * @return mixed
	 */
	public function handle($request, Closure $next, $guard = null) {

		// dd(request()->header('lang'));
		if (request()->header('lang') && in_array(request()->header('lang'), ['ar', 'en'])) {
			app()->setlocale(request()->header('lang'));
		} else {
			app()->setlocale('ar');
		}

		return $next($request);

	}
}
