<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Country extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => app()->getlocale() == "ar" ? $this->Country_name : $this->Country_name_en,
            'code' => $this->Country_code,
            'currency' => app()->getlocale() == "ar" ? $this->Country_currency : $this->Country_currency_en ,
            'image' => it()->url($this->Country_flag)
        ];
    }
}
