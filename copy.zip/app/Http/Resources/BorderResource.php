<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BorderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return[
            'id'=>$this->id,
            'title'=>$this->title,
            'title_lat'=>$this->title_lat,
            'border_image'=>$this->	border_image,
            'price'=>$this->price,
            'type'=>$this->type,
            'color'=>$this->color,
        ];
    }
}
