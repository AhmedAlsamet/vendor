<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TypesResourse extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this['id'],
            'name' => app()->getlocale() == "ar" ? $this['type_name_ar'] : $this['type_name_en'] ,
            'photo' =>$this['type_photo']
        ];
    }
}
