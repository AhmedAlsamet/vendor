<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PackageLineResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return[
            'id'=>$this->id,
            'package_name'=>$this->title,
            'package_days'=>$this->days,
            'package_price'=> (string) $this->price,
            'line'=>optional($this->line_info)->title ?? null,
            'line_id'=>optional($this->line_info)->id ?? null,
            'package_type'=>$this->type,
            'for_ever'=>(bool)$this->for_ever,


          ];
    }
}
