<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PackageGoldWisdomResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
      return[
        'id'=>$this->id,
        'package_name'=>$this->title,
        'package_days'=>$this->days,
        'for_ever'=>(bool)$this->for_ever,
        'package_price'=> (string) $this->price,
        'package_type'=>$this->type,
        'for_ever'=>(bool)$this->for_ever,

      ];
    }
}
