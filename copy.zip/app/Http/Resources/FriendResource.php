<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class FriendResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $result = [
            'f_id'=>$this->id,
            'user_id'=>$this->user_id,
            'id'=>$this->user_friend_id ,
            'created_at' =>$this->created_at,
            'updated_at' =>$this->updated_at,
            'name' => $this['name'],
            'gender' => $this['gender'],
            'phone' => $this['phone'],
            'email' => $this['email'] ?? null,
            'state'=>$this->state,
            'border_id'=>$this->border_id,
            'font_id'=>$this->font_id,
            'border'=>$this->border,
            'font'=>$this->font,
        ];
        // if($this->border_id != 0)
        //     $result["border"] = [            
        //     'id'=>$this->border_id,
        //     'title'=>$this->border_title,
        //     'title_lat'=>$this->border_title_lat,
        //     'border_image'=>$this->border_image,
        //     'price'=>$this->border_price,
        //     'type'=>$this->border_type,
        //     'color'=>$this->border_color,];
        // if($this->font_id != 0)
        //     $result["font"] = [     
        //         'id'=>$this->font_id,
        //         'name'=>$this->font_name,
        //         'name_lat'=>$this->font_name_lat,
        //         'photo'=>$this->font_photo,
        //         'price'=>$this->font_price,
        //         'link'=>$this->font_link
        //     ];
        return $result;
    }
}
