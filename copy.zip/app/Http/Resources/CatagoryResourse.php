<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CatagoryResourse extends JsonResource
{

    public function toArray($request)
    {
        // dd($this);
        // 'Catagory_count' =>  $Catagory->count(),
        // 'type_count' =>  $Catagory->type->count(),
        return [
            'id' => $this['id'],
            'name' => app()->getlocale() == "ar" ? $this['catagory_name_ar'] : $this['catagory_name_en'] ,
            'type_count' =>  $this->type->count(),
            'image' => app()->getlocale() == "ar" ? $this['catagory_photo'] : $this['catagory_photo_en']
        ];
    }
}
