<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class WinnerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $i = 1;
        $i ++;
        return [
            'id'=>$this->id,
            'time'=>$this->time,
            'mark'=>$this->mark,
            'user_id'=>new Users($this->user_info),
            'created_at'=>date('Y-m-d',strtotime($this->created_at)),
             'index_count'=>$this->index_count
        ];
    }
}
