<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MyPackageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $account_type = null;
        if($this->type == 1){
            $account_type = 'باقات بدون اعلانات';
        }elseif($this->type == 2){
            $account_type = 'باقات الاطارات';
        }elseif($this->type == 3){
            $account_type = 'باقات الخطوط';
        }elseif($this->type == 4){
            $account_type = 'باقات الحكمة الذهبية';
        }
       return[
        'id'=>$this->id,
        'package'=>optional($this->package_info)->title ?? null,
        'account_type'=> $account_type,
        'type'=>$this->type,
        'expired'=> $this->expired ? date('Y-m-d', strtotime($this->expired )) : null,
        'for_ever'=>(bool) $this->for_ever
       ];
    }
}
