<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Users extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(isset($this['token']) && isset($this['token_type'])) {
            return [
                'otp' => $this['otp'],
                'id' => (int)$this['id'],
                'name' => $this['name'],
                'phone' => $this['phone'],
                'email' => $this['email'] ?? null,
                'token' => $this['token'] ,
                'token_type' => $this['token_type'],
            ];
        } else {
            return [
                'otp' => $this['otp'],
                'id' => (int)$this['id'],
                'name' => $this['name'],
                'phone' => $this['phone'],
                'email' => $this['email'] ?? null,

            ];
        }

    }
}
