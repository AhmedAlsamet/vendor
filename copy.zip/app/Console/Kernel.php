<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
        Commands\compitetions::class,

    ];


    protected function schedule(Schedule $schedule)
    {
        $schedule->command('compitetions:create')->dailyAt("23:00");
        $schedule->command('wisdom:expired')->daily();
        $schedule->command('winners:compitetions')->dailyAt("1:00");
        // $schedule->command('wisdom:expired')->everyMinute();
        // $schedule->command('wisdom:renew')->monthly();
        // $schedule->command('wisdom:renew')->monthlyOn(31,"23:59");
        $schedule->command('wisdom:renew')->dailyAt("23:59");
        // $schedule->command('wisdom:renew')->everyMinute();
        // $schedule->command('session:change_state')->everyMinute();

    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
