<?php

namespace App\Console\Commands;

use App\Jobs\DoctorNotyJob;
use App\Jobs\WinnersCompetionJob;
use Illuminate\Console\Command;

class winersCompitetions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'winners:compitetions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Winners To Competion ';

    /**
     * Create a new command instance.
     *
     * @return void
     */


    /**
     * Execute the console command.
     *
     * @return int
     */

    public function handle()
    {
        dispatch(new WinnersCompetionJob());
    }
}
