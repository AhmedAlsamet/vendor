<?php

namespace App\Console\Commands;

use App\Models\TodayWisdom;
use Illuminate\Console\Command;
use DB;
use Carbon\Carbon;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Log;


class wisdom_renew extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wisdom:renew';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run All Fist day of month to add wisdom';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $TodayWisdom = TodayWisdom::query()->select("today_wisdoms.*")->where('type',1)->orderBy('month_wisdom','asc')->first();
        $TodayWisdom->month_wisdom +=1;
        $TodayWisdom->save();
        $TodayWisdom = TodayWisdom::query()->select("today_wisdoms.*")->where('type',0)->orderBy('month_wisdom','asc')->first();
        $TodayWisdom->month_wisdom +=1;
        $TodayWisdom->save();
         return Command::SUCCESS;

        // $maxDays=date('t');
        // $TodayWisdoms = TodayWisdom::query()->select("today_wisdoms.*")->where('type',1)->orderBy('month_wisdom','asc')->take($maxDays)->get();
        // if(count($TodayWisdoms) > 0)
        // {
        //     foreach ($TodayWisdoms as $key => $TodayWisdom) {
        //         $TodayWisdom->month_wisdom +=1;
        //         $TodayWisdom->save();
        //     }
        // }
        //  return Command::SUCCESS;

    //     $startDate = Carbon::now(); //returns current day
    //     $firstDay = $startDate->firstOfMonth()->format('Y-m-d');
    //     $year =date('Y');
    //     $month = date('m');
    //     $dt = Carbon::parse($year.'-'.$month);
    //     $days = Carbon::parse($dt->format('Y-m-d'))->daysInMonth;
    //    $TodayWisdom = TodayWisdom::where('month_wisdom',0)->where('type',0)->take($days)->get();
    //    if($days == count($TodayWisdom)){
    //         foreach($TodayWisdom as $i=>$section){

    //             if ($i == 0) {
    //                 $day = date('Y-m-d', strtotime($firstDay));
    //            }else{
    //                $day = date('Y-m-d', strtotime($firstDay .'+'.$i.' day'));

    //            }
    //             $section->month_wisdom = 1;
    //             $section->start_at = $day;
    //             $section->save();
    //         }

    //         Log::info('TodayWisdom Transport Success');

    //    }else{
    //     Log::info('عدد الحكم اقل من عدد ايام الشهر يجب ان يكون الحكم يساوى عدد حكم فى الحكم العادية');

    //    }

    //      //GOld
    //      $GoldWisdom = TodayWisdom::where('month_wisdom',0)->where('type',1)->take($days)->get();
    //      if($days == count($GoldWisdom)){
    //           foreach($GoldWisdom as $i=>$gold){

    //               if ($i == 0) {
    //                   $day = date('Y-m-d', strtotime($firstDay));
    //              }else{

    //                  $day = date('Y-m-d', strtotime($firstDay .'+'.$i.' day'));

    //              }

    //               $gold->month_wisdom = 1;
    //               $gold->start_at = $day;
    //               $gold->save();
    //           }

    //           Log::info('GoldWisdom Transport Success');

    //      }else{
    //       Log::info('عدد الحكم اقل من عدد ايام الشهر يجب ان يكون الحكم يساوى عدد حكم الشعر الحمم الذهبية');


    //     }



    //     return Command::SUCCESS;
    }
}
