<?php

namespace App\Console\Commands;

use App\Models\TodayWisdom;
use Illuminate\Console\Command;
use DB;
use Carbon\Carbon;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Log;

class expired_wisdom extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wisdom:expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Wisdom Expired';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $today = date('Y-m-d');
        $sections = TodayWisdom::where('month_wisdom',1)->where('start_at','<',$today)->get();
        if(count($sections) > 0){

            foreach ($sections as $section) {
               $section->month_wisdom = 2;
               $section->save();
            }
            Log::info('TodayWisdom Success Transport in '.$today);
        }else{
            Log::info('NO yWisdom in this Day '.$today);

        }


    }
}
