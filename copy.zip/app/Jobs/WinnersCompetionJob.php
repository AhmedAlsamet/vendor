<?php

namespace App\Jobs;

use App\Models\Compitetion;
use App\Models\Winner;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class WinnersCompetionJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $today = Carbon::now()->format('Y-m-d');
        $compitetions = Compitetion::where('start_date','<=',now())
        ->whereDate('end_date','=',$today)->first();

        if ( $compitetions == null) {
            Log::info('لا يوجد مسابقه اليوم');
        }elseif($today == date('Y-m-d', strtotime($compitetions->end_date))){
             $winners = Winner::where('compitetion_id',$compitetions->id)->count();
             if($winners >= 3){
                 Log::info('تم اضافه المستخدمين بالفعل فى المسابقة رقم '.$compitetions->id);
             }else{
                 if(count($compitetions->top_three_anwer) >0){

                     foreach($compitetions->top_three_anwer as $posts){
                         $winner = new Winner();
                         $winner->user_id = $posts->user_id;
                         $winner->compitetion_id = $posts->compitetion_id;
                         $winner->time = $posts->time;
                         $winner->mark = $posts->mark;
                         $winner->save();
                         $posts->delete();
                         Log::info('تم اضافه المستخدمين الى الفائزين فى لمسابقة رقم '.$compitetions->id);
                     }
                 }else{

                     Log::info('لا يوجد مستخدمين جابوا ع المسابقة رقم  '.$compitetions->id);

                 }

             }


        }else{
            Log::info('لا يوجد مسابقه تنتهى اليوم');
        }


    }
}
