<?php
return [

	///// Configuration Database Constraints and other environment /////////
	'ForeignKeyConstraints'     => 'enable', // enable | disable
	'SchemadefaultStringLength' => '191', // 1 to more than
	///// Configuration Database Constraints and other environment /////////
];